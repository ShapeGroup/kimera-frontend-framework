
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-inc" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: includer</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						It is a modest system for include file by javascript and not by php. This super class picks up the content of a php or html files from a url and "include" in a target container choice ... It's simple.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                        <div class="fillLimits">
								<a class="include_includehere_http://localhost/kimera/tester/resource/includerFile.php pad-20"> include exemple now </a>
								<div class="includehere pad-20">
								   Click to load exemple content...
								</div>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 