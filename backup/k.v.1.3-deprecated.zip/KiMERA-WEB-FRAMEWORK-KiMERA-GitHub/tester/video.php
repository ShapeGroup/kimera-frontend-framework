<?php include("../tester/resource/head.php") ?>  
<a id="page-viid" href="#"></a>



		<?php include("../tester/resource/topDeskr.php") ?>

				<h3 c>ELEMENTS :: bkgVid</h3>
				<p>
					<sub>PRIMARY CLASS - FREE STRUCTURE - CSS & JS</sub>
				</p>
				<p>
					It's a preset for including the new html5 videos into the page.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

		<?php include("../tester/resource/bottomDeskr.php") ?>



		<?php include("../tester/resource/topcnt.php") ?>

			<div class="inBlock pad-40 centered" style="max-width:400px; ">
					<p>
					   This element is a page bacground (fixed background)
					</p>
					<video 	autoplay loop muted
							class="videoType-screen"
							src="../kimera/theme/video/videoloop.mp4" type="video/mp4" >
							<img src="../kimera/theme/image/backgroundClear.jpg" />
					</video>
					
			</div>

		<?php include("../tester/resource/bottomcnt.php") ?>
		<?php include("../tester/resource/topcnt.php") ?>

						<div class="inBlock pad-40 centered" style="max-width:400px; ">
								<p>
								   This element is box background (absolute background)
								</p>
								<video	autoplay loop muted
										class="videoType-background"
										src="../kimera/theme/video/videoloop.mp4">
										<img src="../kimera/theme/image/backgroundClear.jpg" />
								</video>
								
						</div>


		<?php include("../tester/resource/bottomcnt.php") ?>
		<?php include("../tester/resource/topcnt.php") ?>


            		<div class="gridBox gSpace-20">
	            		<!-- video player local -->
            			<div class="gBox dsk-33 mbl-33 cmp-100">

								<video  class="videoType-player"
										src="../kimera/theme/video/videologo.mp4"
										poster="yourPosterImage">
										<img src="../kimera/theme/image/backgroundClear.jpg" />
								</video>

            			</div>

	            		<!-- video player vimeo -->
            			<div class="gBox dsk-33 mbl-33 cmp-100">
								<video 	class="videoType-player"
										src="https://vimeo.com/174231395"
										poster="yourPosterImage">
										<img src="../kimera/theme/image/backgroundClear.jpg" />
								</video>
            			</div>

	            		<!-- video player vimeo -->
            			<div class="gBox dsk-33 mbl-33 cmp-100">
								<video  class="videoType-player"
										src="https://www.youtube.com/watch?v=1_5n1EfcWyM"
										poster="yourPosterImage">
										<img src="../kimera/theme/image/backgroundClear.jpg" />
								</video>
            			</div>
            		</div>



		<?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 