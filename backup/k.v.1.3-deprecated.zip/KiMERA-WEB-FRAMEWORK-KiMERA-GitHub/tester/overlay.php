
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-ovlay" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: overlay systems</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						It is a modest system for include file by javascript and not by php. This super class picks up the content of a php or html files from a url and "include" in a target container choice ... It's simple.
					</p>
					<p>
						NB: the overlay can be load only image, file and url (iframe).
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

            		<div class="fillLimits">

							<div class="gridBox gSpace-20">
								<div class="gBox desktop-25 mobile-50 compact-100">
									<div class="panel-dash pad-10">
										<a class="overlay-loadFile" href="http://localhost/kimera/tester/resource/overlayTest_1.php">OVERLAY-LOADFILE Yscrolled</a>
									</div>
								</div>
								<div class="gBox desktop-25 mobile-50 compact-100">
									<div class="panel-dash pad-10">
										<a class="overlay-loadFile" href="http://localhost/kimera/tester/resource/overlayTest_2.php">OVERLAY-LOADFILE Xscrolled</a>
									</div>
								</div>
								<div class="gBox desktop-25 mobile-50 compact-100">
									<div class="panel-dash pad-10">
										<a class="overlay-loadFile" href="http://localhost/kimera/tester/resource/overlayTest_3.php">OVERLAY-LOADFILE centered</a>
									</div>
								</div>
								<div class="gBox desktop-25 mobile-50 compact-100">
									<div class="panel-dash pad-10">
										<a class="overlay-custom_MyFunctionName">OVERLAY CUSTOM&nbsp;FUNCTION</a>
									</div>
								</div>

								<div class="clearAll"></div>

								<div class="gBox desktop-33 mobile-33 compact-100">
									<div class="panel-dash" style="height: 150px; overflow: hidden;">
										<img class="overlay-galleryBox socialbox" style="margin-top: -35px;" src="../kimera/theme/image/AA.jpg" alt=""/>
									</div>
								</div>
								<div class="gBox desktop-33 mobile-33 compact-100">
									<img class="overlay-galleryBox socialbox caged-zoomIn" src="../kimera/theme/image/BB.jpg" height="150" alt=""/>
								</div>
								<div class="gBox desktop-33 mobile-33 compact-100">
									<div class="overlay-galleryBox socialbox thumbed">
										<img class="caged-zoomIn" rel="zoomIn" src="../kimera/theme/image/CC.jpg" height="150" alt="" />
										<div class="tmbContent textCenter" style="background: rgba(0,0,0,0.5); color:#fff;">
											<div class="centry">
													<i class="ico-search-6 centered" style="padding:10px; background:white; color:black;"></i>
											</div>
										</div>
										<a class="tmbRef" href="https://www.w3.org/"></a>
									</div>
								</div>
								<div class="gBox desktop-50 mobile-50 compact-50">
									<div class="panel-dash">
										<a class="overlay-galleryBox inBlock" href="https://www.youtube.com/embed/zSUtUG3y3b4">
											<img class="caged-zoomIn" height="150"  src="../kimera/theme/image/youtube.jpg" alt="apri video" />
										</a>
										<!-- oppure anche come social link >> <a class="overlay-galleryBox" href="http://youtu.be/rzgjqbZhzTQ"><img src="http://www.brandonturpin.com/wp-content/uploads/2014/08/youtube-embedded-video.jpg" alt="apri" /></a> -->
										<!--
											Quello che risulterà in finale sarà questo:
											<iframe class="fillRatio type-16:9" src="//www.youtube.com/embed/0BYovvLhy7A"></iframe>
										-->
									</div>
								</div>
								<div class="gBox desktop-50 mobile-50 compact-50">
									<div class="panel-dash">
										<a class="overlay-galleryBox inBlock" href="https://www.mozilla.org/it/firefox/new/?gclid=CPujnsXZidECFWEz0wodMNwBMg&utm_campaign=sem2015Q4&utm_medium=paidsearch&utm_source=google">
											<img class="caged-zoomIn" height="150" src="../kimera/theme/image/frame.jpg" alt="apri" />
										</a>
										<!--
											Quello che risulterà in finale sarà questo:
											<iframe class="overlay-galleryBox" src="http://www.w3schools.com/website/"></iframe>
										-->
									</div>
								</div>
								<div class="clearAll"></div>
							</div>

					</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 

	<!--custom function-->
	<script type="text/javascript">
		function MyFunctionName(){
			alert("custom function start...");
			$(".ovrBoxContent").append('<div class="boxBlock centered pad-30" style="width: 900px !important; max-width: 900px !important;"><div class="panel pad-30" style="background:white; min-height:80%;"><p>entered text, active function</p><p>>>> completed custom function. <<<</p><hr/><p>The function is present on the bottom of this same page.</p></div></div>');
		};
	</script>

