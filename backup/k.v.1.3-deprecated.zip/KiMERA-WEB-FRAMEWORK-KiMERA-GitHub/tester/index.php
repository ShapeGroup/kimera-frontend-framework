<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>KiMERA | TESTER</title>
	</head>

	<body class="loaderOn">
	<a id="page-home" href="#"></a>

		<div class="fitScreenFull" style="overflow: hidden;">

			<video 	autoplay loop muted
					class="videoType-screen"
					src="../kimera/theme/video/videoloop.mp4" type="video/mp4" >
					<img src="../kimera/theme/image/backgroundClear.jpg" />
			</video>

			<div class="centry" style="width: 600px;">
				<img src="../kimera/theme/image/KimeraWhite.png" align="KiMERA" style="max-width: 400px;">
				<div class="boxText textCenter" >
					<p class="spaceAfter-50" style="color:white;">
						Welcome on the test zone of the Kimera 1.x<br />
						From here you can examine each elements of Kimera and your theme.
					</p>
					<a target="_top" href="loader.php" class="btn">START NOW</a>
				</div>
			</div>

		</div>

	</body>
	<?php include("../tester/resource/foot.php") ?>  

</html>