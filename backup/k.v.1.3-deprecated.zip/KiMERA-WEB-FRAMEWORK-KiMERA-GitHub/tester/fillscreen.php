
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-fillscreen" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>FILL DESING :: fillScreen</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS ONLY</sub><br/>
						Standard Box formatted to retrieve and apply the size of a window element. And 'the perfect full screen and its variants are: "fillScreen or fillScreen-full, fillScreen-height and fillScreen-width".
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

				<!--SITE CONTENT-->
				<div class="fillScreen panel-dash" style="background: gray;">
					<div class="pad-30">
						<h3 class="pad-10" style="margin-top: 30px;">TEST - fillScreen</h3>
						<p class="spaceAfter-20" style="padding:0 20px 20px 20px;">
							The gray box is formatted to the maximum of the width and height of the window.<br/>
							remember:  the reference to fillScreen is the screen... not the father.
						</p>
					</div>
				</div>


<?php include("../tester/resource/foot.php") ?> 

