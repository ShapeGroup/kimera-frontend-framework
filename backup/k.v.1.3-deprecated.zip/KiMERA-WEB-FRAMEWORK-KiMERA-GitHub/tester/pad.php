
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-pad" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: pad</h3>
					<p>
						<sub>SECONDARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						"Pad" allows you to create a space between the elements and to guarantee the right to breath layout.<br />
						The values ​​for the padding can be, up to 100px. If you want to set a padding to "999999" you can use full-pad. 
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

			<div class="fillLimits">

						<div class="pad-40 panel-dash centered">
								<p>
									THIS BOX HAVE A pad-40 (padding: 40px)
								</p>
						</div>

						<div class="spaceAfter-5 spaceBefore-5">&nbsp;</div>

						<div class="dskPad-40 mblPad-20 cmpPad-10 panel-dash  centered">
								<p>
									THIS BOX HAVE A dynamic pad.<br />
									dskPad-40 mblPad-20 cmpPad-10
								</p>
						</div>

			</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 