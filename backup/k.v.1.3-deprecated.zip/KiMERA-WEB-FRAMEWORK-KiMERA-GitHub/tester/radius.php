
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-radius" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: radius</h3>
					<p>
						<sub>SECONDARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						Radius is a simple attribute class that has a combined presets rounded corners ... <br />
						radiusSIZE-ORIGIN-ORIGIN-... or radiusMicro,Small,Medium,Big,Large
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


						<div class="centered spaceAfter-30" style="min-width: 400px; max-width: 800px;">
							<div class="pad-20 radiusLarge" style="width: 100%; border: 1px solid #006699;">
								<div class="pad-20 radiusBig" style="width: 100%; border: 1px solid #006699;">
									<div class="pad-20 radiusMedium" style="width: 100%; border: 1px solid #006699;">
										<div class="pad-20 radiusSmall" style="width: 100%; border: 1px solid #006699;">
											<div class="pad-20 radiusMicro" style="width: 100%; border: 1px solid #006699;">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>
        <?php include("../tester/resource/topcnt.php") ?>

					<div class="centered textCenter pad-40" style="width: 300px;">
						<div class="radiusFull pad-10" style="background: #ccc;">
							<div class="radiusFull  pad-30" style="background: #fff; border: 1px solid #333;">
								<div class="radiusFull  pad-4" style="background: #fff; border: 1px solid #4d4d4d;">
								</div>
							</div>
						</div>
					</div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 



