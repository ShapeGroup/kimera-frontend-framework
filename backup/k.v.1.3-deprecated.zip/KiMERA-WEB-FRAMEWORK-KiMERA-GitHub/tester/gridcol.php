
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-gridcol" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>GRID SYSTEMS :: gridCol</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						The super class gridCol serves to create a kind of layout; to be exact the same as you can see in the company "pinteres".
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p> 

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

				<div class="gridCol-3 colSpace-10">
					<div class="cBox other class">
						<div style="background: #ccc;  padding:10px 10px 100px 10px; order:1">
							Content 01
						</div>
					</div>
					<div class="cBox other class">
						<div style="background: #ccc;  padding:10px 10px 50px 10px; order:2">
							Content 02
						</div>
					</div>
					<div class="cBox other class">
						<div style="background: #ccc;  padding:10px 10px 80px 10px; order:3">
							Content 03
						</div>
					</div>
					<div class="cBox other class">
						<div style="background: #ccc;  padding:10px 10px 120px 10px; order:4">
							Content 04
						</div>
					</div>
					<div class="cBox other class">
						<div style="background: #ccc;  padding:10px 10px 100px 10px; order:5">
							Content 05
						</div>
					</div>
					<div class="cBox other class">
						<div style="background: #ccc;  padding:10px 10px 40px 10px; order:5">
							Content 06
						</div>
					</div>
					<div class="cBox other class">
						<div style="background: #ccc;  padding:10px 10px 60px 10px; order:5">
							Content 07
						</div>
					</div>
					<div class="cBox other class">
						<div style="background: #ccc;  padding:10px 10px 110px 10px; order:5">
							Content 08
						</div>
					</div>
				</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 


