
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-ellipsis" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: ellipsis, ellipsis-child</h3>
                    <p>
                        <sub>SECONDARY CLASS - FREE STRUCTURE - CSS ONY</sub>
                    </p>
                    <p>
                        The class ellipsis is a simple and practical method for generating ellipsis directly...
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                    <div class="fillLimits">

                        <div class="fillLine">
                            <p class="ellipsis">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                            </p>
                            <p class="spaceBefore-20">
                                NOT ELLIPSIS;<br />
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                            </p>
                        </div>

                    </div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 

