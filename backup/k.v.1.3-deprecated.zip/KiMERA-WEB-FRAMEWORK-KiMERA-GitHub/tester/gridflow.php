
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-gridflow" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>GRID FLOW :: gridFlow</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						UNDER COSTRUCTION...
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

						<div class="pad-40 centered">
								<p>
									UNDER COSTRUCTION...
								</p>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 