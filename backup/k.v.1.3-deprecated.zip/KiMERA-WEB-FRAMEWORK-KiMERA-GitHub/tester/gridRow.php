
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-gridRow" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ROW SYSTEMS :: gridRow</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						The superclass gridRow allows all the classic responsive layouts of web 2.0.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


					<div class="gridRow">
						<div class="rBox">
							<div class="dsk-12 mbl-12 cmp-12">
								<p class="pad-30">resolution for x parts of 12 total parts<br /><i>the bootstrap systems</i></p>
							</div>
						</div>
						<div class="rBox">
							<div class="dsk-4 mbl-0 cmp-4" style="border:1px solid #ccc;">
								<p class="pad-30">dsk-4 mbl-0 cmp-4</p>
							</div>
							<div class="dsk-4 mbl-6 cmp-4" style="border:1px solid #ccc;">
								<p class="pad-30">dsk-4 mbl-6 cmp-4</p>
							</div>
							<div class="dsk-4 mbl-6 cmp-4" style="border:1px solid #ccc;">
								<p class="pad-30">dsk-4 mbl-6 cmp-4</p>
							</div>
						</div>
						<div class="rBox">
							<div class="dsk-8 mbl-8 cmp-12" style="border:1px solid #ccc;">
								<p class="pad-30">dsk-8 mbl-8 cmp-12</p>
							</div>
							<div class="dsk-4 mbl-4 cmp-12" style="border:1px solid #ccc;">
								<p class="pad-30">dsk-4 mbl-4 cmp-12</p>
							</div>
						</div>
						<div class="rBox">
							<div class="dsk-3 mbl-6 cmp-12" style="border:1px solid #ccc;">
								<p class="pad-30">dsk-3 mbl-6 cmp-12</p>
							</div>
							<div class="dsk-9 mbl-6 cmp-12" style="border:1px solid #ccc;">
								<p class="pad-30">dsk-9 mbl-6 cmp-12</p>
							</div>
						</div>
					</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 
