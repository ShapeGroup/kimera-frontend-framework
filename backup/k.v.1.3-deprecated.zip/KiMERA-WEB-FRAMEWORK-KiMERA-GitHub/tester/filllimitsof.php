
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-filllimitsof" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>FILL DESING :: fillLimitsOf...</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS ONLY</sub><br/>
						Standard Box formatted to meet one responsive resolution, blocking the other. It is used as fillLimits and its variants are: "fillLimitsOfDesktop, fillLimitsOfMobile, fillLimitsOfCompact".
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
						(the dotted line is the fillLimitsOfMobile)
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

					<div class="fillLimitsOfMobile thelimits">
						<div class="boxLine">
							<img src="../kimera/theme/image/demoimage.jpg" alt="" />
							<p class="pad-12 txtJustify" style="background: #e7fffc;">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
						</div>
					</div>
					<style>
						.thelimits{
							border: 4px dotted red;
						}
						.thelimits::before{
							color: red;
							content: "LIMITED RESPOSIVE";
							top: 5%;
							left: 15%;
							display: block;
							position: absolute;
						}
					</style> 


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 