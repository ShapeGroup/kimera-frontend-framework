
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-gridbox" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>GRID SYSTEMS :: gridBox</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						The superclass gridBox allows all the classic responsive layouts of web 2.0.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


						<div class="gridBox gSpace-10">
							<div class="gBox desktop-50 mobile-25 compact-100">
								<div class="boxLine pad-20" style="background: #E1E1E1;">
									<p>
										desktop-50 (50%)<br />
										mobile-25 (25%)<br />
										compact-100 (100%)
									</p>
								</div>
							</div>
							<div class="gBox desktop-50 mobile-25 compact-100">
								<div class="boxLine pad-20" style="background: #E1E1E1;">
									<p>
										desktop-50 (50%)<br />
										mobile-25 (25%)<br />
										compact-100 (100%)
									</p>
								</div>
							</div>
							<div class="gBox desktop-50 mobile-100 compact-100">
								<div class="boxLine pad-20" style="background: #E1E1E1;">
									<p>
										desktop-50 (50%)<br />
										mobile-100 (100%)<br />
										compact-100 (100%)
									</p>
								</div>
							</div>
							<div class="gBox desktop-50 mobile-100 compact-0">
								<div class="boxLine pad-20" style="background: #E1E1E1;">
									<p>
										desktop-50 (50%)<br />
										mobile-100 (100%)<br />
										compact-0 (invisibile)
									</p>
								</div>
							</div>
						</div>

        <?php include("../tester/resource/bottomcnt.php") ?>
        <?php include("../tester/resource/topcnt.php") ?>


						<div class="gridBox">
							<div class="gBox desktop-33 mobile-25 compact-0">
								<div class="boxLine pad-20" style="background: #efefef;">
									<p>
										MENU<br />
										desktop-33 (33%)<br />
										mobile-25 (25%)<br />
										compact-0 (Invisibile)
									</p>
								</div>
							</div>
							<div class="gBox desktop-66 mobile-75 compact-100">
								<div class="boxLine pad-20" style="background: #E1E1E1;">
									<p>
										CONTENT<br />
										desktop-66 (66%)<br />
										mobile-75 (75%)<br />
										compact-100 (100%)
									</p>
								</div>
							</div>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>
        <?php include("../tester/resource/topcnt.php") ?>

						<div class="gridBox">
							<div class="gBox desktop-25 mobile-33 compact-20">
								<div class="boxLine pad-20" style="background: #efefef;">
									<p>
										MENU<br />
										desktop-25 (25%)<br />
										mobile-33 (33%)<br />
										compact-20 (20%)
									</p>
								</div>
							</div>
							<div class="gBox desktop-50 mobile-66 compact-80">
								<div class="boxLine pad-20" style="background: #E1E1E1;">
									<p>
										CONTENT<br />
										desktop-50 (50%)<br />
										mobile-66 (66%)<br />
										compact-80 (80%)
									</p>
								</div>
							</div>
							<div class="gBox desktop-25 mobile-0 compact-0">
								<div class="boxLine pad-20" style="background: #dadada;">
									<p>
										EXTRA<br />
										desktop-25 (25%)<br />
										mobile-0 (invisibile)<br />
										compact-0 (invisibile)
									</p>
								</div>
							</div>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>
        <?php include("../tester/resource/topcnt.php") ?>


						<div class="gridBox gSpace-0">
							<div class="gBox desktop-25 mobile-33 compact-20">
								<div class="boxLine pad-20" style="background: #efefef;">
									<p>
										MENU<br />
										desktop-25 (25%)<br />
										mobile-33 (33%)<br />
										compact-20 (20%)
									</p>
								</div>
							</div>
							<div class="gBox desktop-50 mobile-66 compact-80">
								<div class="boxLine pad-10" style="background: #E1E1E1;">
									<p class="spaceAfter-20">
										CONTENT<br />
										desktop-50 (50%)<br />
										mobile-66 (66%)<br />
										compact-80 (80%)<br />
										
										+ grid into grid...
									</p>
									<div class="gridBox gSpace-10">
										<div class="gBox desktop-25 mobile-25 compact-25">
											<div class="boxLine pad-20" style="background: #eeeeee;">
												<p>BOX</p>
											</div>
										</div>
										<div class="gBox desktop-25 mobile-25 compact-25">
											<div class="boxLine pad-20" style="background: #f8f8f8;">
												<p>BOX</p>
											</div>
										</div>
										<div class="gBox desktop-25 mobile-25 compact-25">
											<div class="boxLine pad-20" style="background: #eeeeee;">
												<p>BOX</p>
											</div>
										</div>
										<div class="gBox desktop-25 mobile-25 compact-25">
											<div class="boxLine pad-20" style="background: #f8f8f8;">
												<p>BOX</p>
											</div>
										</div>
										<div class="gBox desktop-25 mobile-25 compact-25">
											<div class="boxLine pad-20" style="background: #eeeeee;">
												<p>BOX</p>
											</div>
										</div>
										<div class="gBox desktop-25 mobile-25 compact-25">
											<div class="boxLine pad-20" style="background: #f8f8f8;">
												<p>BOX</p>
											</div>
										</div>
										<div class="gBox desktop-25 mobile-25 compact-25">
											<div class="boxLine pad-20" style="background: #eeeeee;">
												<p>BOX</p>
											</div>
										</div>
										<div class="gBox desktop-25 mobile-25 compact-25">
											<div class="boxLine pad-20" style="background: #f8f8f8;">
												<p>BOX</p>
											</div>
										</div>
										<div class="clearAll"></div>
									</div>
								</div>
							</div>
							<div class="gBox desktop-25 mobile-0 compact-0">
								<div class="boxLine pad-20" style="background: #dadada;">
									<p>
										 EXTRA<br />
										desktop-25 (25%)<br />
										mobile-0 (invisibile)<br />
										compact-0 (invisibile)
									</p>
								</div>
							</div>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 
