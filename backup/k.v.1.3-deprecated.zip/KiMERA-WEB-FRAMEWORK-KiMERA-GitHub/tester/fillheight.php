
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-fillheight" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>FILL DESING :: fillHeight</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS ONLY</sub><br/>
						Standard Box formatted to comply with width and height automatically from css.<br />
						It does not reset anything but imposes a resolution of over 90 VGA / SVGA standards and variants included.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

					<div class="fillHeight" style="background: gray;">
						<div class="pad-30">
							<p class="spaceAfter-20" style="padding:0 20px 20px 20px;">
								The gray box is formatted to one of over 90 VGA / SVGA standard resolution.
							</p>
						</div>
					</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?>
