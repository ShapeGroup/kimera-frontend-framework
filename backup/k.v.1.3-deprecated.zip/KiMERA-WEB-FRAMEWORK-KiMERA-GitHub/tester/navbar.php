
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-nvbar" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: navBar</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						The navBar (or navbar) is the super class for the main menu of the sites. Its job is to manage the list of pages and options as needed.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

				<div style="min-height: 300px;">
				
								<div class="navbar pad-20">
									<ul class="lizeWidth">
										<li class="floatLeft">

											<a>HOMEPAGE</a>

										</li>
										<li class="floatLeft">

											<a class="navvoice-click">BLOG</a>
											<div class="navbox-line">
												<div class="panel pad-20 txtLeft">
													<h4 class="titleBig">Scopri tutto sul nostro blog!</h4>
													<hr />
													<p>
														Il box lungo come questo è relativo al parente di navBar, in questo caso un fillLine usato come contenitore... ma se lo metti in cima alla pagina non serve ;)
													</p>
												</div>
											</div>

										</li>
										<li class="floatLeft">

											<a class="navvoice-hover">SHOP</a>
											<div class="navbox-block">
												<div class="panel pad-20 txtLeft" style="min-width: 500px;">
													<h4 class="titleBig">Acquista ora sullo shop!</h4>
													<hr />
													<p>
														Lista delle categorie? o quello che vuoi... questo è solo un esempio.
													</p>
												</div>
											</div>

										</li>
										<li class="floatLeft">

											<a>CONTATTO</a>

										</li>                                        
									</ul>
								</div>
							</div>

							<!--
							<p>
								NOTA BENE:<br />
								Puoi usare lizeWidth per equalizzare i link del menu come in questo caso.<br />
								ul class="lizeWidth textCenter"<br />
								li class="floatLeft"
							</p>
							<p>
								Ricorda che puoi creare qualsiasi variante di stile semplicemente prolungando la superclasse dentro theme, ad esempio:<br />
								navBar-MioStile{ ... }
							</p>
							-->
						</div>

				</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 



