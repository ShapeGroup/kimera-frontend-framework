
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-tumbd" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: thumbed</h3>
                    <p>
                        <sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
                    </p>
                    <p>
                        "thumbed" creates a clickable and highly dynamic structure, technically called "thumbnail box". Basically does is to superimpose on each other boxes of its structure and transform the entire container into a clickable item using, of course, the link that will hide.
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                                <div class="gridBox gSpace-10">

                                    <div class="gBox desktop-33 mobile-33 compact-100">
                                        <div class="thumbed">
                                            <img class="caged-zoomIn" height="200" src="../kimera/theme/image/demoimage.jpg" alt="" />
                                            <div class="tmbContent pad-20">
                                                <p class="text-TitlePageDescription text-Black">TEST</p>
                                                <p class="text-TitlePageDescription text-Black">This is a thumbed box</p>
                                                <a class="text-TitlePageDescription text-Black">YOUR LINK</a>
                                            </div>
                                            <a class="tmbRef" href="">YOUR LINK</a>
                                        </div>
                                    </div>

                                    <div class="gBox desktop-33 mobile-33 compact-100">
                                        <div class="thumbed">
                                            <img class="caged-slideLeft" height="200" src="../kimera/theme/image/demoimage.jpg" alt="" />
                                            <div class="tmbContent pad-20">
                                                <p class="text-TitlePageDescription text-Black">TEST</p>
                                                <p class="text-TitlePageDescription text-Black">This is a thumbed box</p>
                                                <a class="text-TitlePageDescription text-Black">YOUR LINK</a>
                                            </div>
                                            <a class="tmbRef" href="">YOUR LINK</a>
                                        </div>
                                    </div>

                                    <div class="gBox desktop-33 mobile-33 compact-100">
                                        <div class="thumbed">
                                            <img class="caged-focuzInDegree" height="200" src="../kimera/theme/image/demoimage.jpg" alt="" />
                                            <div class="tmbContent pad-20">
                                                <p class="text-TitlePageDescription text-Black">TEST</p>
                                                <p class="text-TitlePageDescription text-Black">This is a thumbed box</p>
                                                <a class="text-TitlePageDescription text-Black">YOUR LINK</a>
                                            </div>
                                            <a class="tmbRef" href="">YOUR LINK</a>
                                        </div>
                                    </div>

                            </div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 


