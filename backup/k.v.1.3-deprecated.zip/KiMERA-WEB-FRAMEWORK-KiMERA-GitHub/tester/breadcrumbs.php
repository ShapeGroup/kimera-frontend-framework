
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-bdcrubps" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: breadcrumbs</h3>
                    <p>
                        <sub>PRIMARY CLASS - DYNAMIC COMPOSED STRUCTURE - CSS & JS</sub>
                    </p>
                    <p>
                        <a target="_blank" href="https://github.com/Alberto-GitHub/KiMERA-webframework/wiki/WIKI-CLASSES#-boxline-">link reference</a> | RESULT:
                    </p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                            <div class="centered" style="background: #55b088; max-width: 500px">
                                <div class="breadcrumbs-dashed">
                                    <div class="crumbslist">
                                        <a class="crumbref-xxx" href="#">page first</a>
                                        <a class="crumbref-bdcrubps" href="#">page active</a>
                                        <a class="crumbref-xxx" href="#">page 3</a>
                                        <a class="crumbref-xxx" href="#">page 4</a>
                                        <a class="crumbref-xxx" href="#">page 5</a>
                                        <a class="crumbref-xxx" href="#">page 6</a>
                                        <a class="crumbref-xxx" href="#">page 7</a>
                                        <a class="crumbref-xxx" href="#">page 8</a>
                                        <a class="crumbref-xxx" href="#">page 9</a>
                                        <a class="crumbref-xxx" href="#">page last</a>
                                    </div>
                                    <div class="clearAll"></div>
                                </div>
                             </div>
                         </div> 


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?>