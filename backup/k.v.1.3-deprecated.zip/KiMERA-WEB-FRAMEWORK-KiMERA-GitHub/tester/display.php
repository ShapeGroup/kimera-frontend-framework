
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-display" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: display</h3>
					<p>
						<sub>SECONDARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						The attribute classes "inLine", "inBlock" and "inLineBlock" are created to force the system and its design box.<br />
						The following example clarifies how affect on a box that.
					</p>
					<p>
						Into the boxText is valid help for text imagination with the image and other box.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

						<div class="inLine pad-40 centered" style="max-width:400px; border: 1px solid #ccc; ">
								<p>
									This box is in line<br />
									max-width:400px; border: 1px solid #ccc;  margin-left: auto; margin-right: auto; padding:40px;
								</p>
						</div>

        <?php include("../tester/resource/bottomcnt.php") ?>
        <?php include("../tester/resource/topcnt.php") ?>

						<div class="inBlock pad-40 centered" style="max-width:400px; border: 1px solid #ccc; ">
								<p>
									This box is in block<br />
									max-width:400px; border: 1px solid #ccc;  margin-left: auto; margin-right: auto; padding:40px;
								</p>
						</div>

        <?php include("../tester/resource/bottomcnt.php") ?>
        <?php include("../tester/resource/topcnt.php") ?>

						<div class="inLineBlock pad-40 centered" style="max-width:400px; border: 1px solid #ccc; ">
								<p>
									This box is in line-block<br />
									max-width:400px;  margin-left: auto; margin-right: auto; padding:40px;
								</p>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?>