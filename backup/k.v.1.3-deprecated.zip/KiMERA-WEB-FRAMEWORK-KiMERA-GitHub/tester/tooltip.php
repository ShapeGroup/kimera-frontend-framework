
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-ttps" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: tooltips</h3>
                    <p>
                        <sub>SECONDARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
                    </p>
                    <p>
                        A simple way to extra info on elements...
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                        <div class="inBlock pad-40 centered panel-dash" style="max-width:400px; ">
                                <a class="tooltips" title="info for all user!">"YOUT TOOLTIP"</a>
                        </div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 