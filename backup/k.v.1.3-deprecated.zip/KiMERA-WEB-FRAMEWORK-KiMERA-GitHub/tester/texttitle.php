
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-txtitle" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: Text Title</h3>
                    <sub>TYPOGRAPHY CLASS - FREE STRUCTURE - CSS ONLY</sub>
                    </p>
                    <p>
                        Actual situation of standard theme assets
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                        <div class="inBlock pad-10 centered" style="max-width:800px; ">
                                <p>
                                   STANDARD FORMTTED ELEMENTS:
                                </p>
                                <div class="boxText textLeft">
                                    <h1 class="text-black-magnum">LOREM IPSUM!  H1 text-black-magnum</h1>
                                    <hr />
                                    <h2 class="text-black-bold-verybig">LOREM IPSUM  H2 text-black-verybig</h1>
                                    <h3 class="text-back-big">LOREM IPSUM  H3 text-big</h2>
                                    <hr />
                                    <h4 class="text-black-medium">LOREM IPSUM H4 text-black-medium</h3>
                                    <h5 class="text-black-normal">LOREM IPSUM H5/P text-black-normal</h4>
                                    <hr />
                                    <h6 class="text-black-small">LOREM IPSUM H6 text-black-small</h5>
                                    <hr />
                                    <p  class="text-black">
                                        <a target="_Blank" href="http://en.lipsum.com/">Lorem ipsum</a> dolor sit amet, <b class="text-black-bold">consectetur</b> adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                        
                                    </p>
                                    <a></a>
                                </div>
                        </div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 