<?php include("../tester/resource/head.php") ?>
<a id="page-boxfx" href="#"></a>
		
		<?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: general box effects test</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						Create a effects typed for all box...
					</p>
					<p>
						<a target="_blank" href="XXXX">link reference</a> | RESULT:
					</p>

		<?php include("../tester/resource/bottomDeskr.php") ?>

		<?php include("../tester/resource/topcnt.php") ?>

						<div class="fillLine fx-onLoad_fadeUp-IN_200">
								<img class="caged-slideRight" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
						</div>

						<div class="gridBox">
							<div class="gBox dsk-33 mbl-33 cmp-100 fx-onLoad_fadeUp-IN_200">
								<img class="caged-zoomIn" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
							</div>
							<div class="gBox dsk-33 mbl-33 cmp-100 fx-onLoad_fadeUp-IN_400">
								<img class="caged-zoomInDegree" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
							</div>
							<div class="gBox dsk-33 mbl-33 cmp-100 fx-onLoad_fadeUp-IN_600">
								<img class="caged-zoomOutDegree" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
							</div>
						</div>


		<?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 
