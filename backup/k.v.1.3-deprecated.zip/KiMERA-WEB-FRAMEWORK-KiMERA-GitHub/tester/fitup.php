
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-fitup" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: fitUp</h3>
					<p>
						<sub>SECONDARY CLASS - FREE STRUCTURE - CSS & JS</sub>
					</p>
					<p>
					   It makes a stacked element to a previous element.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>
								
							<div class="boxLine panel-textbox_1">
								<p>this is a first box, height:400px;<br/> this box is under the second.</p>
							</div>
							<div class="fitUp panel-textbox_2">
								<p>this is a second box fit to height & width respect the previus div. <br /> this box has rose and over the previus div</p>
							</div>
							<style>
								.panel-textbox_1{
									border:  0px !important;
									background: #fff;
									height:400px;
								}
								.panel-textbox_1 > p{
									padding: 20px;
									color: #333;
									text-align: left;
								}
								.panel-textbox_2{
									border:  0px !important;
									background: #fcb5ff;
									opacity: .5;
								}
								.panel-textbox_2 > p{
									padding: 20px;
									color: #333;
									text-align: right;
								}
							</style>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 



