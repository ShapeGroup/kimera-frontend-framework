
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-tbl" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: table</h3>
                    <p>
                        <sub>PRIMARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
                    </p>
                    <p>
                        Standard table type.
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>


        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

            <div class="boxLine">           
                <div class="centered" style="max-width: 800px;">
                <div class="boxtText">
                        <p>
                            tableHorizontal
                        </p>
                        <table class="tableHorizontal">
                            <thead>
                                <tr><th><p> title... </p></th><th></th><th></th></tr>
                            </thead>
                            <tbody>
                                <tr><td> <p>content...</p> </td><td> <p>content...</p> </td><td> <p>content...</p> </td></tr>
                                <tr><td> <p>content...</p> </td><td> <p>content...</p> </td><td> <p>content...</p> </td></tr>
                            </tbody>
                            <tfoot>
                                <tr><td> <p>foot...</p> </td></tr>
                            </tfoot>
                        </table>

                        <hr />
                        
                        <p>
                            tableVertical
                        </p>
                        <table class="tableVertical">
                            <thead>
                                <tr><th><p> title... </p></th><th></th><th></th></tr>
                            </thead>
                            <tbody>
                                <tr><td> <p>content...</p> </td><td> <p>content...</p> </td><td> <p>content...</p> </td></tr>
                                <tr><td> <p>content...</p> </td><td> <p>content...</p> </td><td> <p>content...</p> </td></tr>
                            </tbody>
                            <tfoot>
                                <tr><td> <p>foot...</p> </td><td></td><td></td></tr>
                            </tfoot>
                        </table>

                        <hr />
                        
                        <p>
                            tableCrossed
                        </p>
                        <table class="tableCrossed">
                            <thead>
                                <tr><th><p> title... </p></th><th></th><th></th></tr>
                            </thead>
                            <tbody>
                                <tr><td> <p>content...</p> </td><td> <p>content...</p> </td><td> <p>content...</p> </td></tr>
                                <tr><td> <p>content...</p> </td><td> <p>content...</p> </td><td> <p>content...</p> </td></tr>
                            </tbody>
                            <tfoot>
                                <tr><td> <p>foot...</p> </td><td></td><td></td></tr>
                            </tfoot>
                        </table>   

                        <hr />         
                        
                        <p>
                            panel + table + scroll
                        </p>
                        <div class="panel-dash pad-20">
                            <table class="tableCrossed scroll-x">
                                <thead>
                                    <tr><th><p> title... </p></th><th></th><th></th></tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td> <p>content...</p> </td>
                                        <td> <p>content...</p> </td>
                                        <td nowrap>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> <p>content...</p> </td>
                                        <td> <p>content...</p> </td>
                                        <td nowrap>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr><td> <p>foot...</p> </td><td></td><td></td></tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
</div>
        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 


