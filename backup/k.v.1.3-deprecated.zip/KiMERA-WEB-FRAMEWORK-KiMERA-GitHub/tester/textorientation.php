
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-txori" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: Text orientation</h3>
                    <p>
                        <sub>SECONDARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
                    </p>
                    <p>
                        media query. The superclass that manage these parameters is "text" in all its variants.<br />
                        variants: textLeft - txtLeft textRight - txtRight textJustify - txtJustify textCenter - txtCenter<br />
                        or: textJustify_textCenter_textLeft
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                    <div class="centered">
                        <div class="inBlock pad-40 panel-dash" style="max-width:400px; ">
                                <p class="textCenter_textLeft_textRight">
                                   This element is dynamic text align
                                </p>
                        </div>
                        <div class="spaceAfter-10">&nbsp;</div>
                        <div class="inBlock pad-40 panel-dash" style="max-width:400px; ">
                                <p class="textCenter">
                                   This element is aligned to center
                                </p>
                        </div>
                        <div class="spaceAfter-10">&nbsp;</div>
                        <div class="inBlock pad-40 panel-dash" style="max-width:400px; ">
                                <p class="textLeft">
                                   This element is aligned left
                                </p>
                        </div>
                        <div class="spaceAfter-10">&nbsp;</div>
                        <div class="inBlock pad-40 panel-dash" style="max-width:400px; ">
                                <p class="textRight">
                                   This element is aligned right
                                </p>
                        </div>
                        <div class="spaceAfter-10">&nbsp;</div>
                        <div class="inBlock pad-40 panel-dash" style="max-width:400px; ">
                                <p class="textJustiify">
                                   This element is jusitfy for default
                                </p>
                        </div>
                    </div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 