
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-panl" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>PANEL SYSTEM :: panel</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
							The superclass "panel" is a box for generic content, its purpose is "in a defined manner contain something."
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


						<div class="gridBox gSpace-0">
							<div class="gBox desktop-33 mobile-25 compact-100">
								<div class="boxText pad-20">
									<p>
										the panels Graphic depend solely on the style you want to give it. So it depends on you.
									</p>
									<p>
										Here we report to you just a few examples made by us.<br />
										uses CSS3 rules to concatenate the values ​​of your panel.<br />
										In your browser debugging search: "panel-dashed-radiusSmall", "textclear-bkgDark-titled"
									</p>
								</div>
							</div>
							<div class="gBox desktop-66 mobile-75 compact-100">
								<div class="boxLine pad-20" style="background: #E1E1E1;">
									<div class="panel-dashed-radiusSmall">
										<h2 class="pad-20 text-white-bkgDark-titled">PANEL TITLE</h2>
										<p class="section pad-20">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
										</p>
										<div class="section pad-20">
											<p>
												remember: uses the theme and not css inline. the panels are everywhere; where they are not box ... panel.
											</p>
										</div>
										<div class="section boxFull">
											<a class="btn pad-20 inBlock" style="width:100% !important;">BUY NOW! (this framework is free... I'm joke)</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<style>
						.panel-myStyle{
							border:  1px solid #ccc !important;
							background: #e8e8e8;
							box-shadow: 0 3px 5px #333;
						}
						.panel-myStyle > h2{
							border-bottom: 1px solid #ccc;
						}
						.panel-myStyle > p{
							color: #333;
						}
					</style>
				</div>

				<p class="cenered">REMEMBER: USE THE THEME AND NOT CSS INLINE</p>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 



