
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-centry" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: centry</h3>
					<p>
						<sub>SECONDARY CLASS - DYNAMIC STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						If you want to center an object you can use the "centry" attribute class and the item will be centered along the vertical axis.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


					<div class="centered" style="height: 300px; width: 800px; background: #ccc;">
						<div class="centry pad-20" style="background: #31644f; color: white; width: 300px;">
							<p>
								THIS CONTENT WILL CENTERED WITH RESPECT TO THE FATHER
							</p>
						</div>
					</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?>


