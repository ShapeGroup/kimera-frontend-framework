
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-centere" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: centerd</h3>
					<p>
						<sub>SECONDARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						If you want to center an object you can use the "centered" attribute class and the item will be centered along the horizontal axis.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

						<div class="inBlock pad-40 centered panel-testerbox" style="max-width:400px; ">
								<p>
									This box is centered in the x axis<br />
									display: block; text-align:center; <br />
									margin-left: auto !important; margin-right: auto !important;
								</p>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?>