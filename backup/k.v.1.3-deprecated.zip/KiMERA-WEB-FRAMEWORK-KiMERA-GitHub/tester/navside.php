
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-nvsd" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: navSide</h3>
                    <p>
                        <sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
                    </p>
                    <p>
                        The "navSide" (or navside) are retractable panels. The system can be used for everything from furniture to a menu of the info panel. What this does is take the link the URL of the file to be included in the drop down panel and, of course, do so only appear at the appropriate time.
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                        <div class="fillLimits">
                            <div class="gridBox gSpace-20">
                                <div class="gBox desktop-50 mobile-50 compact-100 textLeft">
                                    <a class="navSideLeft-demo btnLink" rel="slideLeft" href="http://localhost/kimera/tester/resource/sidersfile_1.php"><i class="ico-menu"></i></a>
                                </div>
                                <div class="gBox desktop-50 mobile-50 compact-100 textRight">
                                    <a class="navSideRight-demo btnLink" rel="slideRight" href="http://localhost/kimera/tester/resource/sidersfile_2.php"><i class="ico-info"></i></a>
                                </div>
                            </div>
                        </div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 



