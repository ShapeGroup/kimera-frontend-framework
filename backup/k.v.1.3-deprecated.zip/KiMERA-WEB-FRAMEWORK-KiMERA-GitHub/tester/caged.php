
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-cagd" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: caged</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						the superclass caged activates a js function that "you wrap and center", in one fell swoop, an image. Very useful of the mobile, for pagination and thumb, to create post banner or, more simply, self-impaginanted images.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:
					</p>

				</div>
			</div>
		</div>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


						<div class="fillLimits dskPad-40 mblPad-20 cmpPad-10">

								<div class="gridBox gSpace-10">
									<div class="gBox desktop-100 mobile-100 compact-100">
										<p>caged | di base</p>
										<img class="caged" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-zoomIn</p>
										<img class="caged-zoomIn" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-zoomOut</p>
										<img class="caged-zoomOut" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-zoomInDegree</p>
										<img class="caged-zoomInDegree" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-zoomOutDegree</p>
										<img class="caged-zoomOutDegree" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-25 mobile-25 compact-100">
										<p>caged-slideTop</p>
										<img class="caged-slideTop" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-25 mobile-25 compact-100">
										<p>caged-slideDown</p>
										<img class="caged-slideDown" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-25 mobile-25 compact-50">
										<p>caged-slideLeft</p>
										<img class="caged-slideLeft" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-25 mobile-25 compact-50">
										<p>caged-slideRight</p>
										<img class="caged-slideRight" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-opacyUp</p>
										<img class="caged-opacyUp" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-opacyDown</p>
										<img class="caged-opacyDown" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-focuzUp</p>
										<img class="caged-focuzUp" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-focuzDown</p>
										<img class="caged-focuzDown" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-focuzInDegree</p>
										<img class="caged-focuzInDegree" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
									<div class="gBox desktop-50 mobile-50 compact-100">
										<p>caged-focuzDownDegree</p>
										<img class="caged-focuzDownDegree" height="150" src="../kimera/theme/image/demoimage.jpg" alt="" />
									</div>
								</div>
							</div>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?>

