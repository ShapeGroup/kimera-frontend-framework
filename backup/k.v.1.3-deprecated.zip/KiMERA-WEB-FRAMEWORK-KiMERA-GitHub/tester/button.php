
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-bttn" href="#"></a>
		
		<?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: Ui Button</h3>
					<p>
						<sub>PRIMARY CLASS - DYNAMIC STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						The class "button" (or btn) is the first resource of the UI framework. This superclass can adjust the appearance of each "user input" of our interface.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:
					</p>

		<?php include("../tester/resource/bottomDeskr.php") ?>

		<?php include("../tester/resource/topcnt.php") ?>

				<div class="fillLimits">

						<p class="pad-40">HTML5 full elements upgraded</p>
						<p class="pad-20"><i>not supported on kimera input type="color"</i><br /><i>not supported on kimera input type="month" input type="week" input type="datetime-local" input type="datetime" input type="date"</i></p>
						<div class="gridBox gSpace-20">

							<!-- html5 button -->

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--btn number-->
								 <div class="btnGroup">
									<a class="btn-minus"><i class="ico-minus"></i></a>
									<input class="btn _isNumber" type="text" value="" readonly>
									<input class="btnType-number" type="number" min="-5" max="5" readonly>
									<a class="btn-plus"><i class="ico-plus"></i></a>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!-- btn palette-->
								<div class="btnType-palette" style="max-width: 500px !important;">
									<label><i class="ico-tint-1"></i>&nbsp;&nbsp;</label>
									<input value="SELECT A COLOR..." type="text">
									<div class="flybox">
										<div class="colors">
											<div class="colorCode_536DFE">BLUE</div>
											<div class="colorCode_D50000">RED</div>
											<div class="colorCode_f2de4d">YELLOW</div>
										</div>
									</div>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--btn range-->
								<div class="btnType-range">
									<input class="range_slider" name="rangeInput" min="-100" max="100" value="0" />
									<input class="range_value" name="amount" />
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--btn search-->
								<div class="btnGroup">
									<label class="btn">find now:&nbsp;</label>
									<input class="btnType-search _isEmpties" type="text" value="search...">
									<input class="btnType-search _isEmpties" type="search" name="find" value="search...">
									<a class="btn-search"><i class="ico-search-1"></i></a>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--btn tel-->
								 <div class="btnGroup">
									<label class="btn"><i class="ico-phone"></i></label>
									<input class="btn _isNumber _isEmpties" type="text" value="">
									<input class="btnType-tel _isNumber _isEmpties" type="tel" value="">
									<a class="btn-search"><i class="ico-plus-2"></i></a>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--btn Url-->
								 <div class="btnGroup">
									<label class="btn"><i class="ico-link-4"></i></label>
									<input class="btn _isUrl _isEmpties" type="text" value="">
									<input class="btnType-url _isUrl _isEmpties" type="url" value="">
									<a class="btn-search"><i class="ico-plus-2"></i></a>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--btn Mail-->
								 <div class="btnGroup">
									<label class="btn"><i class="ico-mail-1"></i></label>
									<input class="btn _isMail _isEmpties" type="text" title="YOUR MAIL" value="">
									<input class="btnType-email _isMail _isEmpties" type="email" value="">
									<a class="btn-search"><i class="ico-plus-2"></i></a>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--btn date-->
								<div class="btnType-date">
									<label><i class="ico-calendar-1"></i></label>
									<input type="text" value="Select a date">
									<div class="flybox"> <!-- auto generated --> </div>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--btn time-->
								 <div class="btnType-time">
									<label><i class="ico-clock-3"></i></label>
									<input type="time" value="00:00" readonly>
									<input class=" _isNumber _isEmpties" type="text" value="00:00" readonly>
									<div class="flybox"> <!-- auto generated --> </div>
								</div>	 

							</div>

							<div class="gBox dsk-100 mbl-100 cmp-100"><div class="pad-10"><hr/></div></div>

							<!-- standard html button -->

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<div class="btnType-seenbox">
									<input class="_isReady" type="checkbox" value="None" id="IDSEQUENCE01A" name="testsequence01"/>
									<label for="IDSEQUENCE01A"></label>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<div class="btnType-lightbox">
									<input class="_isReady" type="checkbox" value="None" id="IDSEQUENCE02A" name="testsequence02"/>
									<label for="IDSEQUENCE02A"></label>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<div class="btnType-switchbox">
									<input class="_isReady" type="checkbox" value="None" id="IDSEQUENCE03A" name="testsequence03"/>
									<label for="IDSEQUENCE03A"></label>
								</div>

							</div>


							<div class="gBox dsk-33 mbl-50 cmp-100">

								<!--selectbox-->
								<div class="btnType-selectbox" style="max-width: 500px !important;">
									<label>SELECT AN OPTION...</label>
									<input class="_isReady" value="SELECT AN OPTION..." title="SELECT AN OPTION..." type="text"  readonly nowrap />
									<div class="flybox">
										<ul class="selector">
											<li>OPTION AAA</li>
											<li>OPTION BBB</li>
											<li>OPTION CCC</li>
											<li>OPTION DDD</li>
										</ul>
									</div>
								</div>

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<input class="btn _isEmpties _isReady" type="text" title="YOUR NAME" value="YOUR NAME"  />

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<input class="btn _isEmpties _isNumber _isReady" type="text" title="EVERY NUMBER" value="EVERY NUMBER"  />

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<input class="btn _isEmpties _isMail _isReady" type="text" title="YOUR MAIL" value="YOUR MAIL"  />

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<input class="btn _isEmpties _isReady" type="password" title="YOUR PASSWORD" value="YOUR PASSWORD" />

							</div>

							<div class="gBox dsk-33 mbl-50 cmp-100">

								<input class="btn" type="submit" title="type action" value="type action" />

							</div>

							<div class="gBox dsk-100 mbl-100 cmp-100"><div class="pad-10"><hr/></div></div>

							<div class="gBox dsk-100 mbl-100 cmp-100">

								<div class="boxLine spaceAfter-20"><p>inline test</p></div>

								<label class="btn">label</label>
								<div class="btnType-selectbox" style="max-width: 500px !important;">
									<label>SELECT AN OPTION...</label>
									<input value="SELECT AN OPTION..." type="text"  readonly nowrap />
									<div class="flybox">
										<ul class="selector">
											<li>OPTION AAA</li>
											<li>OPTION BBB</li>
											<li>OPTION CCC</li>
											<li>OPTION DDD</li>
										</ul>
									</div>
								</div>
								<div class="btn">div</div>
								<input class="btn _isEmpties" type="text" title="type text" value="type text"  />

							</div>
							<div class="gBox dsk-100 mbl-100 cmp-100">

								<label class="btn"><i class="ico-asterisk"></i></label>
								<div class="btnType-seenbox">
									<input type="checkbox" value="None" id="IDSEQUENCE0XX" name="testsequence01X"/>
									<label for="IDSEQUENCE0XX"></label>
								</div>
								<label class="btn">label</label>
								<div class="btn">div</div>
								<input class="btn _isEmpties" type="text" title="type text" value="type text"  />
								<input class="btn _isEmpties" type="password" title="password" value="password" />
								<input class="btn"  type="submit" title="type action" value="type action" />
								<a href="#" href="button" class="btn">LINK</a>
								<button class="btn" type="button">BUTTON</button>
								<div class="btnType-file">
									<input type="file" />
									<label class="ellipsis"><i class="ico-plus"></i> | Upload File</label>
								</div>

							</div>


							<div class="gBox dsk-100 mbl-100 cmp-100"><div class="pad-10"><hr/></div></div>


							<div class="gBox dsk-100 mbl-100 cmp-100">

								<div class="boxLine spaceAfter-20"><p>groupped test</p></div>

								<div class="btnGroup btnCompact">
									<label class="btn"><i class="ico-user-1"></i></label>
									<input class="btn _isEmpties" type="text" title="nick name" value="nick name" />
									<input class="btn _isEmpties" type="password" title="password" value="password" />
								</div>
								<div class="btnBreak"></div>
								<div class="btnType-optionbox"">
									<i class="ico-tools"></i>
									<div class="flybox" style="width:400px;">

										<div class="panel pad-20 radiusSmall" style="background: white;">
											<p class="text-Black">
												we are not styled this panel but you...
												You can crate all panel you wont into the theme ;)
											</p>
										</div>

									</div>
								</div>

							</div>
							<div class="gBox dsk-100 mbl-100 cmp-100">

								<div class="btnType-seenbox">
									<input type="checkbox" value="None" id="IDSEQUENCE01" name="testsequence01"/>
									<label for="IDSEQUENCE01"></label>
								</div>

								<div class="btnType-lightbox">
									<input type="checkbox" value="None" id="IDSEQUENCE02" name="testsequence02"/>
									<label for="IDSEQUENCE02"></label>
								</div>

								<div class="btnType-switchbox">
									<input type="checkbox" value="None" id="IDSEQUENCE03" name="testsequence03"/>
									<label for="IDSEQUENCE03"></label>
								</div>

								<div class="btnGroup btnCompact">
									<label class="btn"><i class="ico-user-1"></i></label>
									<div class="btnType-seenbox">
										<input type="checkbox" value="None" id="IDSEQUENCE0X" name="testsequence01"/>
										<label for="IDSEQUENCE0X"></label>
									</div>
									<input class="btn _isEmpties" type="password" title="password" value="password" />
								</div>

							</div>


							<div class="gBox dsk-100 mbl-100 cmp-100"><div class="pad-10"><hr/></div></div>


							<div class="gBox dsk-100 mbl-100 cmp-100">

								<div class="boxLine spaceAfter-20"><p>textarea test</p></div>

								<textarea class="btn">Lorem Ipsum</textarea>

							</div>


							<div class="gBox dsk-100 mbl-100 cmp-100"><div class="pad-10"><hr/></div></div>


							<div class="gBox dsk-100 mbl-100 cmp-100">

								<div class="boxLine spaceAfter-20"><p>mobile compact test</p></div>

								<form class="textCenter">
									<div class="btnGroup btnCompact boxFull">
										<label class="btn dsk-25"><i class="ico-user-1"></i></label>
										<label class="btn dsk-25"><i class="ico-user-1"></i></label>
										<input class="btn _isEmpties dsk-50" type="password" title="password" value="password" />
									</div>
								</form>

							</div>

						</div>

				</div>

		<?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?>