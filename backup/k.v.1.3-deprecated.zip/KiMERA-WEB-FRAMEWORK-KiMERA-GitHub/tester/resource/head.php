<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>KiMERA | TESTER</title>
	</head>
	<body class="loaderOn" style="display: none;">

		<div class="boxFull panel-testerHead-noborder-bkgClear textclear">
			<div class="fillLimits">

						<div class="breadcrumbs text-white">
							<div class="floatLeft">
								<a target="_top" class="inLineBlock pad-10" href="/kimera/tester/index.php"><i class="ico-home"></i></a>
								<a class="inLineBlock pad-10 navSideLeft-clist"  href="/kimera/tester/resource/pagelist.php"><i class="ico-list"></i></a>
							</div>
							<div class="crumbslist">
								<a target="_top" class="crumbref-lder" href="loader.php">loader</a>
								<a target="_top" class="crumbref-boxfull" href="boxfull.php">boxFull</a>
								<a target="_top" class="crumbref-boxline" href="boxline.php">boxLine</a>
								<a target="_top" class="crumbref-boxblock" href="boxblock.php">boxBlock</a>
								<a target="_top" class="crumbref-boxtext" href="boxtext.php">boxText</a>
								<a target="_top" class="crumbref-filllimits" href="filllimits.php">fillLimits</a>
								<a target="_top" class="crumbref-filllimitsof" href="filllimitsof.php">fillLimitsOf</a>
								<a target="_top" class="crumbref-fillobject" href="fillObjectLimits.php">fillObjectLimits</a>
								<a target="_top" class="crumbref-fillheight" href="fillheight.php">fillHeight</a>
								<a target="_top" class="crumbref-fillscreen" href="fillscreen.php">fillScreen</a>
								<a target="_top" class="crumbref-fillratio" href="fillratio.php">fillRatio</a>
								<a target="_top" class="crumbref-float" href="float.php">float</a>
								<a target="_top" class="crumbref-fixabs" href="fixed_absolute.php">fixed and absolute</a>
								<a target="_top" class="crumbref-gridbox" href="gridbox.php">gridBox</a>
								<a target="_top" class="crumbref-gridRow" href="gridRow.php">gridRow</a>
								<a target="_top" class="crumbref-gridcol" href="gridcol.php">gridCol</a>
								<a target="_top" class="crumbref-gridflex" href="gridflex.php">gridflex</a>
								<a target="_top" class="crumbref-gridflow" href="gridflow.php">gridflow</a>
								<a target="_top" class="crumbref-gridsquare" href="gridsquare.php">gridSquare</a>
								<a target="_top" class="crumbref-panl" href="panel.php">panel</a>
								<a target="_top" class="crumbref-pad" href="pad.php">pad</a>
								<a target="_top" class="crumbref-display" href="display.php">display</a>
								<a target="_top" class="crumbref-centere" href="centered.php">centered</a>
								<a target="_top" class="crumbref-centry" href="centry.php">centry</a>
								<a target="_top" class="crumbref-space" href="space.php">space</a>
								<a target="_top" class="crumbref-fitheight" href="fitheight.php">fitHeight</a>
								<a target="_top" class="crumbref-fitup" href="fitup.php">fitUp</a>
								<a target="_top" class="crumbref-norma" href="normalize.php">normalize</a>
								<a target="_top" class="crumbref-stik" href="stiky.php">stiky</a>
								<a target="_top" class="crumbref-viid" href="video.php">video</a>
								<a target="_top" class="crumbref-srll" href="scroll.php">scroll</a>
								<a target="_top" class="crumbref-cagd" href="caged.php">caged</a>
								<a target="_top" class="crumbref-tumbd" href="thumbed.php">thumbed</a>
								<a target="_top" class="crumbref-ttps" href="tooltip.php">tooltips</a>
								<a target="_top" class="crumbref-boxfx" href="boxfx.php">boxfx</a>
								<a target="_top" class="crumbref-ellipsis" href="textellipsis.php">ellipsis</a>
								<a target="_top" class="crumbref-txori" href="textorientation.php">Text orientation</a>
								<a target="_top" class="crumbref-txtitle" href="texttitle.php">Text title</a>
								<a target="_top" class="crumbref-lst" href="list.php">List</a>
								<a target="_top" class="crumbref-tbl" href="table.php">Table</a>
								<a target="_top" class="crumbref-bttn" href="button.php">Ui Button</a>
								<a target="_top" class="crumbref-stts" href="status.php">Status</a>
								<a target="_top" class="crumbref-gtop" href="gotop.php">goTop</a>
								<a target="_top" class="crumbref-nvbar" href="navbar.php">navBar</a>
								<a target="_top" class="crumbref-nvsd" href="navside.php">navSide</a>
								<a target="_top" class="crumbref-fla" href="flaps.php">flaps</a>
								<a target="_top" class="crumbref-tbs" href="tabs.php">tabs</a>
								<a target="_top" class="crumbref-pagnate" href="paginate.php">paginate</a>
								<a target="_top" class="crumbref-inc" href="includer.php">includer</a>
								<a target="_top" class="crumbref-ovlay" href="overlay.php">overlay</a>
								<a target="_top" class="crumbref-note" href="note.php">notes</a>
								<a target="_top" class="crumbref-bdcrubps" href="breadcrumbs.php">breadcrumbs</a>
							</div>
							<div class="clearAll"></div>
						</div>

			</div>
		</div>