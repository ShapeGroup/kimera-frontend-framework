

	</body>

	<script type="text/javascript" src="../kimera/data/pack.dev.js"></script>
	<link type="text/css" rel="stylesheet" media="screen" href="../kimera/data/pack.dev.css" charset="utf-8" />
	<link type="text/css" rel="stylesheet" media="screen" href="../kimera/theme/theme.css" charset="utf-8" />

	<!-- DO NOT REMOVE-->
	<script type="text/javascript">

		//only for test the loader into the tester
		$(window).on('load', function(urlBase) {
			var urlBase_tester 	= findUrlBase();
			var spinner 	= urlBase_tester+"/kimera/theme/spinner/spinner.html";
			$('.spinnerContainer').load( spinner, function() {
				$(".wait").fadeOut();
				$(".testLoader").find(".siteCover").fadeIn(1000,function(){
					$(".testLoader").fadeIn(1000);
				}).attr( 'style',  "display: block !important; opacity: 1 !important; position: relative !important;");

				//posiziono spinner
				var containerHeight  = $(".testLoader").height();
				var spinnerHeight   = $(".spinnerContainer").height();
				var topMargin       = (containerHeight/2)-spinnerHeight;
				var bottomMargin       = (containerHeight/2)-spinnerHeight;
				$(".testLoader").find(".spinnerContainer").css("margin-top", topMargin+"px");
				$(".testLoader").find(".spinnerContainer").css("margin-bottom", bottomMargin+"px");
			},3000);
		});

	</script>

</html>