<div class="boxBlock centered" style="width: 900px !important; max-width: 900px !important;">
    <div  class="panel-dash pad-10" style="background: white !important;">
        <h3>This is a test</h3>
        <p>
            If the page on which you surf is sufficiently large ... <br />
            The content will be automatically centered, otherwise it will be scrollable.
        </p>

	    <div class="spaceBefore-20">
		    <input class="btn" type="submit" value="some button" /> <a class="btn">some link</a>
	    </div>
    </div>
</div>
