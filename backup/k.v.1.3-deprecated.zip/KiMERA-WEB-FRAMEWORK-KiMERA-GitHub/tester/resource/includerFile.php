<!--INCLUDER CONTENT-->
<div class="pad-20" style="background: rgb(65, 170, 124);">
    <p>
        GOOD! This file is loaded!<br />
        Remember:<br />
        A) this file is a local file<br />
        B) This file url dont have undescore!
    </p>
</div>


