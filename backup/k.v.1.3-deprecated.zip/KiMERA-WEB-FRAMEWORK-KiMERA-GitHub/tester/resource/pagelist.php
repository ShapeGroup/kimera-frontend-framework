<!--SIDERS CONTENT-->
<div class=" textLeft" style="background: #41916d; width: 250px; box-shadow: 3px #000;">
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="loader.php">loader</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="boxfull.php">boxFull</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="boxline.php">boxLine</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="boxblock.php">boxBlock</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="boxtext.php">boxText</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="filllimits.php">fillLimits</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="filllimitsof.php">fillLimitsOf</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="fillObjectLimits.php">fillObjectLimits</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="fillheight.php">fillHeight</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="fillscreen.php">fillScreen</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="fillratio.php">fillRatio</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="fillratio.php">float</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="fixed_absolute.php">fixed and absolute</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="gridbox.php">gridBox</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="gridRow.php">gridRow</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="gridcol.php">gridCol</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="gridflex.php">gridflex</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="gridflow.php">gridflow</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="gridsquare.php">gridSquare</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="panel.php">panel</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="pad.php">pad</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="display.php">display</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="centered.php">centered</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="centry.php">centry</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="space.php">space</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="fitheight.php">fitHeight</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="fitup.php">fitUp</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="normalize.php">normalize</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="stiky.php">stiky</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="video.php">video</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="scroll.php">scroll</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="caged.php">caged</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="thumbed.php">thumbed</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="tooltip.php">tooltips</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="boxfx.php">boxfx</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="textellipsis.php">ellipsis</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="textorientation.php">Text orientation</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="texttitle.php">Text title</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="list.php">List</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="table.php">Table</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="button.php">Ui Button</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="status.php">Status</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="gotop.php">goTop</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="navbar.php">navBar</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="navside.php">navSide</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="flaps.php">flaps</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="tabs.php">tabs</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="paginate.php">paginate</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="includer.php">includer</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="overlay.php">overlay</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="note.php">notes</a></div>
	<div class="boxLine"><a class="inLineBlock menuvoice" target="_top" href="breadcrumbs.php">breadcrumbs</a></div>
</div>
<style type="text/css">
.menuvoice{
	-webkit-transition-duration: 200ms; transition-duration: 200ms;
	padding: 5px 5px 5px 5px; border-bottom: 1px dotted #39cb8a; color: white; width:100%!important;
}
.menuvoice:hover{
	padding: 5px 0px 5px 15px;
}
</style>