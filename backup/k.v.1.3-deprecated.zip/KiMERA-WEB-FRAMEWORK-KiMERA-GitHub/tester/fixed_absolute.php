
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-fixabs" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>FILL DESING :: fixed & absolute</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
						-FIXED- In the current version of Kimera you will have access to some basic fixed presets that you can use. The fixed variants are: <i>fixed-top, fixed-bottom, left-fixed, fixed-right</i> // <i>fixed-XXX-XXX fixedFull, fixedLine-XXX-XXX fixedBlock</i>
					</p>
					<p>
						-ABXOLUTE- "absolute" is identical to fixed, but the big difference is that, of course, its location will be reported to the parent and not the window.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

						<div class="boxLine centered dskPad-40 mblPad-20 cmpPad-10" style="background: #ccc; min-height: 300px;">
							<p>CONTAINER</p>
							<p>the element have, only for this exemple, opacity: 0.5;</p>

							<div class="fixed-left-bottom pull-bottom-40 pad-50" style="background: green; color:white;  opacity: .5;">
								<p>fixed-left-bottom</p>
							</div>
							<div class="absolute-left-bottom pull-bottom-40 pad-50" style="background: red; color:white;  opacity: .5;">
								<p>absolute-left-bottom</p>
							</div>
							<div class="clearAll"></div>
		
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 
