
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-note" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: notes</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						The superclass "notes" is nothing but to create a system of "alerts for the user" in a superimposed page. There are three variations that serve to align: "Notes", "notesLeft" and "notesRight" All three values ​​are centered and fit in compact resolution.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

		<div class="notesRight">
			<div class="noteContent panel-dash pad-30 fx-onLoad_fadeUp-IN_200">
				Note demo content 
			</div>
			<div class="noteContent panel-dash pad-30 fx-onLoad_fadeUp-IN_300">
				You can use "notesLeft" and "notesRight"
			</div>
			<div class="noteContent panel-dash pad-30 fx-onLoad_fadeUp-IN_400">
				For centered use simple "notes"
			</div>
		</div> 


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 