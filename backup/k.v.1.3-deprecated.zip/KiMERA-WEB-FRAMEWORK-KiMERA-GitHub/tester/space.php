
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-space" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: spaceAfter & spaceBefore</h3>
					<p>
						<sub>SECONDARY CLASS - FREE STRUCTURE - CSS ONLY</sub>
					</p>
					<p>
					   A simple CSS trick that allows you to leave a predefined space behind or before, of an element through "before" and "after".
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

						<div class="centered spaceAfter-20" style="max-width:400px; ">
							<div class="panel-dash-radiusMedium pad-40">
								<p>
									This box have a 20px of space after
								</p>
							</div>
						</div>
						<div class="centered" style="max-width:400px; ">
							<div class="panel-dash-radiusMedium pad-40">
								<p>
									20px after...
								</p>
							</div>
						</div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 