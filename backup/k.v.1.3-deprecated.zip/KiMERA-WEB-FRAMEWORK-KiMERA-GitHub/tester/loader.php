
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-lder" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>LOADER</h3>
					<p>
						<sub>PRIMARY CLASS - STATIC STRUCTURE - CSS AND JS</sub><br/>
						The loader is an element that is intended to "cover" while the site is loading (or move from one page to another) with the "spinner".
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

            		<div class="testLoader textCenter" style="display:none;">
						<p class="wait">Now you see the element. Please wait...</p>
						<div class="pad-50">
							<div class="siteCover">
								<div class="spinnerContainer" >
									


								</div>
							</div>
						</div>
					</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 
