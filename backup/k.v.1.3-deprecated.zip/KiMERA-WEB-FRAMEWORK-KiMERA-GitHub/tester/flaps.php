
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-fla" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: flaps</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						As for tabs the flaps are navigable layouts managed by js. Relatively simple are the perfect replacement of the old vertical accordion.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


            		<div class="fillLimits">
						   <div class="flaps radius-small">
								<a class="trig">MY TITLE ONE</a>
								<div>
									<div class="pad-20">
										<p>CONTENT</p>
										<p>
										   Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
										</p>
									</div>
								</div>
								<a class="trig">MY TITLE TWO</a>
								<div>
									<div class="pad-20">
										<p>CONTENT - CON SUBFLAPS</p>
										<p>
										   Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
										</p>
										<hr />
										<div class="flaps radius-small">
											<a class="trig">MY SUB TITLE ONE</a>
											<div style="display: block;">
												<div class="pad-20">
													<p>SUB CONTENT</p>
												</div>
											</div>
											<a class="trig">MY SUB TITLE TWO</a>
											<div style="display: block;">
												<div class="pad-20">
													<p>SUB CONTENT</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<a class="trig">MY TITLE TRHEE</a>
								<div>
									<div class="pad-20">
										<p>CONTENT</p>
										<p>
											Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
										</p>
									</div>
								</div>
							</div>
					</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 



