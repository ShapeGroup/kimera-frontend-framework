
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-filllimits" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>FILL DESING :: fillLimits</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS ONLY</sub><br/>
						Standard Box formatted to comply with the responsive resolutions.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
						(the dotted line is the responsive limits, squeeze the tab to see the automated adaptation)
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


					<div class="fillLimits thelimits" style="background: white">
						<div class="boxLine">
							<img src="../kimera/theme/image/demoimage.jpg" alt="" />
							<p class="pad-12 txtJustify" style="background: #e7fffc;">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
						</div>
					</div>
					<style>

						@media only screen and (max-width:450px) {
							.thelimits{
								border: 4px dotted red;
							}
							.thelimits::before{
								color: red;
								content: "ULTRACOMPACT";
								top: 2%;
								left: 2%;
							}

						}
						@media only screen and (max-width:720px) {
							.thelimits{
								border: 4px dotted #42f4a1;
							}
							.thelimits::before{
								color:#42f4a1;
								content: "COMPACT DEVICE";
								top: 5%;
								left: 4%;
							}
						}

						@media only screen and (min-width:720px) and (max-width:1024px) {
							.thelimits{
								border: 4px dotted #4298f4;
							}
							.thelimits::before{
								color: #4298f4;
								content: "MOBILE AND TABLET";
								top: 5%;
								left: 5%;
							}
						}
						@media only screen and (min-width:1024px) and (max-width:1150px) {
							.thelimits{
								border: 4px dotted #6e42f4;
							}
							.thelimits::before{
								color:#6e42f4;
								content: "DESKTOP 4:3";
								top: 5%;
								left: 8%;
							}
						}
						@media only screen and (min-width:1150px) {
							.thelimits{
								border: 4px dotted #f442e2;
							}
							.thelimits::before{
								color:#f442e2;
								content: "DESKTOP";
								top: 5%;
								left: 10%;
							}
						}
						.thelimits::before{
							display: block;
							position: absolute;
						}
					</style> 


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?>

