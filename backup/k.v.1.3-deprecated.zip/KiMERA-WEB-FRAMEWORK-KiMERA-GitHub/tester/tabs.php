
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-tbs" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: tabs</h3>
                    <p>
                        <sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
                    </p>
                    <p>
                        The tabbed panels are a classic element in the world of today's web, especially for e-commerce. Easy to understand and usable are an essential component for those cases where there is need to organize the categorized areas. 
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>


        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                        <div class="fillLimits">
                           <div class="tabs radius-small">
                                <ul class="tabsList">
                                    <li class="compact-50">
                                        <a>Content</a>
                                    </li>
                                    <li class="compact-50">
                                        <a>Tabs into tabs...</a>
                                    </li>
                                    <li class="compact-50">
                                        <a>form and other..</a>
                                    </li>
                                    <li class="compact-50">
                                        <a>Immage</a>
                                    </li>
                                    <li class="compact-100">
                                        <a>Videos and other</a>
                                    </li>
                                </ul>
                                <div class="tabsContent radius-small-bottom">
                                    <div>
                                        <div class="fillLine pad-20">
                                            <h3>LOREM IPSUM</h3>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                            </p>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="fillLine pad-20">
                                            <p>
                                               Sub tabs into tabs....
                                            </p>
                                            <hr />
                                            <div class="tabs">
                                                <ul class="tabsList">
                                                    <li class="compact-50">
                                                        <a>SUB1</a>
                                                    </li>
                                                    <li class="compact-50">
                                                        <a>SUB2</a>
                                                    </li>
                                                </ul>
                                                <div class="tabsContent">
                                                    <div>
                                                        <div class="fillLine pad-10">
                                                            <p>
                                                                FIRST SUB TAB
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div class="fillLine pad-10">
                                                            <p>
                                                                SECOND SUB TAB
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="fillLine pad-20">
                                            <input class="buttonText" type="text" value="Username"/>
                                            <input class="buttonText" type="password" value="Password"/>
                                            <input class="buttonAction" type="reset" value="LOGIN NOW"/>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="fillLine pad-20">
                                            <img class="fillFull" src="http://www.fotoevolution.de/images/webdesign.jpg" alt="" />
                                        </div>
                                    </div>
                                    <div>
                                        <iframe class="fillRatio type-16:9" src="http://youtu.be/mxHZaC2iw-A"></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 



