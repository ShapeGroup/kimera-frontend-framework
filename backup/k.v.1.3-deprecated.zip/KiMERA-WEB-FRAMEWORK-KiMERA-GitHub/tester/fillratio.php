
	<?php include("../tester/resource/head.php") ?>  
	<a id="page-fillratio" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>FILL DESING :: fillRatio</h3>
					<p>
						<sub>PRIMARY CLASS - FREE STRUCTURE - CSS ONLY</sub><br/>
						Standard Box formatted to comply with width and height automatically from css.<br />
						It does not reset anything but imposes a resolution of over 90 VGA / SVGA standards and variants included.
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

						<div class="centered spaceAfter-40" style="max-width: 900px;">
							<p class="pad-20">
								IFRAME EXEMPLE:<br />
								the image was set to 4:3 and 100% of width
							</p>
							<iframe class="fillRatio type-tv" src="https://www.w3.org/"></iframe>
						</div>


						<div class="centered spaceAfter-40"  style="max-width: 900px;">
							<p class="pad-20">
								YOUTUBE & VIMEO VIDEO EXEMPLE:<br />
								the video was set to 16:9 and a 100%
							</p>
							<iframe class="fillRatio type-film" src="https://youtu.be/zSUtUG3y3b4"></iframe>

							<div class="pad-20"></div>

							<iframe class="fillRatio type-film" src="https://player.vimeo.com/video/28505363" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
						</div>


						<div class="centered "  style="max-width: 900px;">
							<p class="pad-20">
								IMG TAG EXEMPLE:<br />
								the image was set to 100% and aspectRatio
							</p>
							<img  class="fillRatio type-auto" src="../kimera/theme/image/demoimage.jpg" alt=""/>
						</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 
