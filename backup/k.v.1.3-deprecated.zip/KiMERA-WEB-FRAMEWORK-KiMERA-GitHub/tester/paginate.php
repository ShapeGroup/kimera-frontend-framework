	<?php include("../tester/resource/head.php") ?>  
	<a id="page-pagnate" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

					<h3>ELEMENTS :: paginate</h3>
					<p>
						<sub>PRIMARY CLASS - COMPOSED STRUCTURE - CSS & JS</sub>
					</p>
					<p>
						paginate is the super class to handle multiple layouts, such as a list of products on multiple pages. Its variants are only 3 and depend on the structure on which you want to perform paging. 
					</p>
					<p>
						<a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
					</p>

        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>

                        <div class="fillLimits">
		   
							<p>
								Genric elements:
							</p>
							<div  style="padding:20px 0 20px 0;">
								<div  id="200" class="paginate maxpage-5 maxnumber-5">
									<div class='panel radiusMedium pad-12 pages'>
										<p>1 Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										<p>2 Vestibulum consectetur ipsum sit amet urna euismod imperdiet aliquam urna laoreet.</p>
										<p>3 Curabitur a ipsum ut elit porttitor egestas non vitae libero.</p>
										<p>4 Pellentesque ac sem ac sem tincidunt euismod.</p>
										<p>5 Duis hendrerit purus vitae nibh tincidunt bibendum.</p>
										<p>6 Nullam in nisi sit amet velit placerat laoreet.</p>
										<p>7 Vestibulum posuere ligula non dolor semper vel facilisis orci ultrices.</p>
										<p>8 Donec tincidunt lorem et dolor fringilla ut bibendum lacus fringilla.</p>
										<p>9 In non eros eu lacus vestibulum sodales.</p>
										<p>10 Duis ultrices metus sit amet sem adipiscing sit amet blandit orci convallis.</p>
										<p>11 Proin ullamcorper est vitae lorem mollis bibendum.</p>
										<p>12 Maecenas congue fringilla enim, tristique laoreet tortor adipiscing eget.</p>
										<p>13 Duis imperdiet metus et lorem venenatis nec porta libero porttitor.</p>
										<p>14 Maecenas lacinia lectus ac nulla commodo lacinia.</p>
										<p>15 Maecenas quis massa nisl, sed aliquet tortor.</p>
										<p>16 Quisque porttitor tellus ut ligula mattis luctus.</p>
										<p>17 In at mi dolor, at consectetur risus.</p>
										<p>18 Etiam id erat ut lorem fringilla dictum.</p>
										<p>19 Curabitur sagittis dolor ac nisi interdum sed posuere tellus commodo.</p>
										<p>20 Pellentesque quis magna vitae quam malesuada aliquet.</p>
										<p>21 Curabitur tempus tellus quis orci egestas condimentum.</p>
										<p>22 Maecenas laoreet eros ac orci adipiscing pharetra.</p>
										<p>23 Nunc non mauris eu nibh tincidunt iaculis.</p>
										<p>24 Ut semper leo lacinia purus hendrerit facilisis.</p>
										<p>25 Praesent et eros lacinia massa sollicitudin consequat.</p>
										<p>26 Proin non mauris in sem iaculis iaculis vel sed diam.</p>
										<p>27 Nunc quis quam pulvinar nibh volutpat aliquet eget in ante.</p>
										<p>28 In ultricies dui id libero pretium ullamcorper.</p>
										<p>29 Morbi laoreet metus vitae ipsum lobortis ultrices.</p>
										<p>30 Donec venenatis egestas arcu, quis eleifend erat tempus ullamcorper.</p>
										<p>31 Morbi nec leo non enim mollis adipiscing sed et dolor.</p>
										<p>32 Cras non tellus enim, vel mollis diam.</p>
										<p>33 Phasellus luctus quam id ligula commodo eu fringilla est cursus.</p>
										<p>34 Ut luctus augue tortor, in volutpat enim.</p>
										<p>35 Cras bibendum ante sed erat pharetra sodales.</p>
										<p>36 Donec sollicitudin enim eu mi suscipit luctus posuere eros imperdiet.</p>
										<p>37 Vestibulum mollis tortor quis ipsum suscipit in venenatis nulla fermentum.</p>
										<p>38 Proin vehicula suscipit felis, vitae facilisis nulla bibendum ac.</p>
										<p>39 Cras iaculis neque et orci suscipit id porta risus feugiat.</p>
										<p>40 Suspendisse eget tellus purus, ac pulvinar enim.</p>
										<p>41 Morbi hendrerit ultrices enim, ac rutrum felis commodo in.</p>
										<p>42 Suspendisse sagittis mattis sem, sit amet faucibus nisl fermentum vitae.</p>
										<p>43 Nulla sed purus et tellus convallis scelerisque.</p>
										<p>44 Nam at justo ut ante consectetur faucibus.</p>
										<p>45 E via di seguito...</p>
									</div>
									<div class='radius-small-bottom page_navigation'></div>
									<input type='hidden' class='current_page' />
									<input type='hidden' class='show_per_page' />
								</div>
							</div>

							<hr />
							<p>
								grid elements:
							</p>
							<div class="paginate maxpage-6 maxnumber-6" style="padding:20px 0 20px 0;">
								<div class='gridBox gSpace-10 pages'>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>1 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>2 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>3 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>4 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>5 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>6 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>7 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>8 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>9 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>10 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>11 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>12 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>13 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>14 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>15 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>16 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>17 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>18 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>19 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>20 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>21 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>22 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>23 content in grid</p>
									</div>
									<div class="gBox desktop-33 onlyDesktopOn panel">
										<p>24 And more...</p>
									</div>
								</div>
								<div class="clearAll"></div>
								<div class='page_navigation'></div>
								<input type='hidden' class='current_page' />
								<input type='hidden' class='show_per_page' />
							</div>

							<hr />
							<p>
								table elements:
							</p>
							<div class="padding:20px 0 20px 0;">
								<table class="paginate maxpage-3 maxnumber-3 tableCrossed">
									<thead>
										<tr>
											<th>type</th>
											<th>type</th>
											<th>type</th>
										</tr>
									</thead>
									<tbody class="pages">
										<tr>
											<td>AAA</td>
											<td>AAA</td>
											<td>AAA</td>
										</tr>
										<tr>
											<td>BBB</td>
											<td>BBB</td>
											<td>BBB</td>
										</tr>
										<tr>
											<td>CCC</td>
											<td>CCC</td>
											<td>CCC</td>
										</tr>
										<tr>
											<td>DDD</td>
											<td>DDD</td>
											<td>DDD</td>
										</tr>
										<tr>
											<td>EEE</td>
											<td>EEE</td>
											<td>EEE</td>
										</tr>
										<tr>
											<td>FFF</td>
											<td>FFF</td>
											<td>FFF</td>
										</tr>
										<tr>
											<td>GGG</td>
											<td>GGG</td>
											<td>GGG</td>
										</tr>
										<tr>
											<td>HHH</td>
											<td>HHH</td>
											<td>HHH</td>
										</tr>
										<tr>
											<td>III</td>
											<td>III</td>
											<td>III</td>
										</tr>
										<tr>
											<td>LLL</td>
											<td>LLL</td>
											<td>LLL</td>
										</tr>
										<tr>
											<td>MMM</td>
											<td>MMM</td>
											<td>MMM</td>
										</tr>
										<tr>
											<td>NNN</td>
											<td>NNN</td>
											<td>NNN</td>
										</tr>
										<tr>
											<td>OOO</td>
											<td>OOO</td>
											<td>OOO</td>
										</tr>
										<tr>
											<td>PPP</td>
											<td>PPP</td>
											<td>PPP</td>
										</tr>
										<tr>
											<td>QQQ</td>
											<td>QQQ</td>
											<td>QQQ</td>
										</tr>
										<tr>
											<td>RRR</td>
											<td>RRR</td>
											<td>RRR</td>
										</tr>
										<tr>
											<td>SSS</td>
											<td>SSS</td>
											<td>SSS</td>
										</tr>
										<tr>
											<td>TTT</td>
											<td>TTT</td>
											<td>TTT</td>
										</tr>
										<tr>
											<td>UUU</td>
											<td>UUU</td>
											<td>UUU</td>
										</tr>
										<tr>
											<td>VVV</td>
											<td>VVV</td>
											<td>VVV</td>
										</tr>
										<tr>
											<td>ZZZ</td>
											<td>ZZZ</td>
											<td>E via di seguito...</td>
										</tr>
									</tbody>
									<tfoot>
										<tr>
											<td colspan="3">
												<div class='page_navigation'></div>
												<input type='hidden' class='current_page' />
												<input type='hidden' class='show_per_page' />
											</td>
										</tr>
									</tfoot>
								</table>
							</div>
					

					</div>


        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 


