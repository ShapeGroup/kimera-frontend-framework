
    <?php include("../tester/resource/head.php") ?>  
    <a id="page-stts" href="#"></a>
        
        <?php include("../tester/resource/topDeskr.php") ?>

                    <h3>ELEMENTS :: Status</h3>
                    <p>
                        <sub>SECONDARY CLASS - FREE STRUCTURE - CSS</sub>
                    </p>
                    <p>
                        A simple presets to create the status elements.
                    </p>
                    <p>
                        <a target="_blank" href="xxxx">link reference</a> | RESULT:<br />
                    </p>


        <?php include("../tester/resource/bottomDeskr.php") ?>

        <?php include("../tester/resource/topcnt.php") ?>


            <div class="fillLimits">           
                    <div class="gridBox gSpace-10">

                       <div class="gBox desktop-50 mobile-50 compact-100">
                            <p>errorBorder:</p>
                            <input class="buttonText errorBorder"     type="text"     title="typeText"    value="typeText"  style="width: 100%" /> 
                            <p>errorBkg:</p>
                            <input class="buttonText errorBkg"     type="text"     title="typeText"    value="typeText"   style="width: 100%"   /> 
                       </div>
                       <div class="gBox desktop-50 mobile-50 compact-100">
                            <p>alarmBorder:</p>
                            <input class="buttonText alarmBorder"     type="text"     title="typeText"    value="typeText" style="width: 100%"  />
                            <p>alarmBkg:</p>
                            <input class="buttonText alarmBkg"     type="text"     title="typeText"    value="typeText"   style="width: 100%"   /> 
                       </div>
                       <div class="gBox desktop-50 mobile-50 compact-100">
                            <p>passBorder:</p>
                            <input class="buttonText passBorder"     type="text"     title="typeText"    value="typeText"  style="width: 100%" />
                            <p>passBkg:</p>
                            <input class="buttonText passBkg"     type="text"     title="typeText"    value="typeText"   style="width: 100%"   />  
                       </div>
                       <div class="gBox desktop-50 mobile-50 compact-100">
                            <p>newsBorder:</p>
                            <input class="buttonText newsBorder"     type="text"     title="typeText"    value="typeText"   style="width: 100%"   /> 
                            <p>newsBkg:</p>
                            <input class="buttonText newsBkg"     type="text"     title="typeText"    value="typeText"   style="width: 100%"   /> 
                       </div>
                       <div class="gBox desktop-100 mobile-100 compact-100"><hr /></div>
                       <div class="gBox desktop-50 mobile-50 compact-100">
                            <p>errorBorder:</p>
                            <div class="panel pad-10 radiusMedium errorBorder">
                                <p>STATUS ERROR</p>
                            </div>
                            <p>errorBkg:</p>
                            <div class="pad-10 radiusMedium errorBkg">
                                <div class="radiusMedium pad-10 radiusMedium" style="color: black; background:white;">
                                    <p>STATUS ERROR</p>
                                </div>
                            </div>
                       </div>
                       <div class="gBox desktop-50 mobile-50 compact-100">
                            <p>alarmBorder:</p>
                            <div class="pad-10 radiusMedium alarmBorder">
                                <p>STATUS ALARM</p>
                            </div>
                            <p>alarmBkg:</p>
                            <div class="pad-10 radiusMedium alarmBkg">
                                <div class="radiusMedium pad-10" style="color: black; background:white;">
                                    <p>STATUS ALARM</p>
                                </div>
                            </div>
                       </div>
                       <div class="gBox desktop-50 mobile-50 compact-100">
                            <p>passBorder:</p>
                            <div class="pad-10 radiusMedium passBorder">
                                <p>STATUS PASSED</p>
                            </div>
                            <p>passBkg:</p>
                            <div class="pad-10 radiusMedium passBkg">
                                <div class="radiusMedium pad-10" style="color: black; background:white;">
                                    <p>STATUS PASSED</p>
                                </div>
                            </div>
                       </div>
                       <div class="gBox desktop-50 mobile-50 compact-100">
                            <p>newsBorder:</p>
                            <div class="pad-10 radiusMedium newsBorder">
                                <p>STATUS NEWS!</p>
                            </div>
                            <p>newsBkg:</p>
                            <div class="pad-10 radiusMedium newsBkg">
                                <div class="radiusMedium pad-10" style="color: black; background:white;">
                                    <p>STATUS NEWS!</p>
                                </div>
                            </div>
                       </div>
                     </div>
                </div>

        <?php include("../tester/resource/bottomcnt.php") ?>

<?php include("../tester/resource/foot.php") ?> 
