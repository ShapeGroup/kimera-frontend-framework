# KiMERA-WEB-FRAMEWORK
kimera web framework designer pro

![Image of Yaktocat](https://scontent-mxp1-1.xx.fbcdn.net/v/t31.0-8/20157088_1900998406808623_8675654293744808247_o.jpg?oh=13e0965c8e3b8e10a1266fe5e1456b08&oe=59F07085)


It is a new free framework ( js & css ) designed for pro designer. With it you can realize all the designs for internet sites and apps made with the web code.

For tester and other, copy all folder into wamp (xamp or other localhost server). For your site, it's rapid and simple... Copy kimera folder into the root of your site or blog and it's all good!

Use css class directly into your code, mod all parts of theme, expand and concatenate all class supported. Read a WIKI CLASS for all options.

Stay tuned for all news!
