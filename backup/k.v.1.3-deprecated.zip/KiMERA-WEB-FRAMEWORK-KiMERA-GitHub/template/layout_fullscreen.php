<!DOCTYPE html>
<html>

	<head>


		<!-- TITLE -->
		<title>KiMERA | BASIC LAYOUT</title>

		<!-- METATAG -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

		<meta name="robots" content="index">
		<meta name="robots" content="follow">

		<meta name="author" content="Alberto Marà"/>
		<meta name="copyright" content="Alberto Marà ITALY ROME | layouts for KiMERA"/>
		<meta name="reply-to" content="albertomara@mail.com">

		<meta http-equiv="content-language" content="Italian"/>
		<meta name="language" content="it-IT"/>
		<meta name="description" content="KiMERA LAYOUT | BASIC"/>
		<meta name="keywords" content="Key1 Key2 Key3 ..."/>


	</head>

	<body class="loaderOn">

		<!-- TOPBAR forDesktop -->
		<div class="absoluteLine-top onlyCompactOff panel-header">

			<a class="floatLeft pad-15" target="_inside" href="index.php" style="border-right: 1px solid #728487">MYLOGO</a>
			<a class="floatLeft pad-15" target="_inside" href="layout_fullscreen.php">TYPE 0</a>
			<a class="floatLeft pad-15" target="_inside" href="layout_fullrow.php">TYPE 1</a>
			<a class="floatLeft pad-15" target="_inside" href="layout_rowboxed.php">TYPE 2</a>
			<a class="floatLeft pad-15" target="_inside" href="layout_column.php">TYPE 3</a>
			<a class="floatLeft pad-15" target="_inside" href="layout_tabloid.php">TYPE 4</a>
			<a class="floatLeft pad-15" target="_inside" href="layout_magazine.php">TYPE 5</a>
			<a class="floatLeft pad-15" target="_inside" href="layout_sided.php">TYPE 6</a>
			<a class="floatRight pad-15" style="padding-left:0px !important;"><i class="ico-facebook-squared"></i></a>
			<a class="floatRight pad-15" style="padding-left:0px !important;"><i class="ico-twitter-squared"></i></a>
			<a class="floatRight pad-15" style="padding-left:0px !important;"><i class="ico-pinterest-squared"></i></a>
			<a class="floatRight pad-15" style="padding-left:0px !important;"><i class="ico-linkedin-squared"></i></a>
			<div class="clearAll"></div>

		</div>

		<!-- TOPBAR forMobile-->
		<div class="boxLine absoluteLine-top onlyCompactOn panel-header pad-15">

			<!-- mobile menu -->
			<a class="navSide onlyCompactOn" rel="slideLeft" href="mobilemenu.php"><i class="ico-menu"></i></a>
			<div class="boxFull pad-15 textCenter" style="border-bottom: 1px solid #728487">
				<a >MYLOGO</a>
			</div>
			<div class="textCenter spaceBefore-20">
				<a class="pad-15"><i class="ico-facebook-squared"></i></a>
				<a class="pad-15"><i class="ico-twitter-squared"></i></a>
				<a class="pad-15"><i class="ico-pinterest-squared"></i></a>
				<a class="pad-15"><i class="ico-linkedin-squared"></i></a>
			</div>

		</div>
		

		<!-- CONTENT SITE - FULLSCREEN -->
		<div class="fillScreenFull">
			<!-- CENTERBOX -->
			<div class="centry" style="width: 100%; max-width: 590px; background: #ccc; border: 2px solid #fff;">
				<p class="dskPad-50 mblPad-20 cmpPad-15">LOGO &  SLOGAN<br/>FULLSCREEN CENTERED LAYOUT</p>
			</div>

			<!-- FOOTER -->
			<div class="absoluteLine-bottom pad-10 panel-footer">
				<p class="textCenter textclear">
					Powered by KiMERA © // Designer :: <a href="https://www.facebook.com/albertomara.page">Alberto Marà</a> ©
				</p>
			</div>
		</div>

		

		<!--SCRIPTS & CSS OF PAGE-->

		<!-- include kimera -->
		<link type="text/css" rel="stylesheet" media="screen" href="../kimera/theme/theme.css" charset="utf-8" />
		<link type="text/css" rel="stylesheet" media="screen" href="../kimera/data/pack.dev.css" charset="utf-8" />
		<script type="text/javascript" src="../kimera/data/pack.dev.js"></script>

		<!-- custom script -->
		<script type="text/javascript">
			function MyFunctionName(){
				//bla bla bla...
			};
		</script>


		<!-- extra css & other -->
		<!-- for convenience you all parameters here ... you use the theme!!-->
		<style type="text/css">
			body{
				background: #ffffff;
			}

			.fillScreenFull{
				background: rgba(0,0,0,.8);
			}

			.panel-header{
				border: 0px !important;
			}
				.panel-header a{
					background:  transparent;
					color: white;
				}

			.panel-content{
				border: 0px !important;
				background: #F7F7F4;
			}

			.panel-header,
			.panel-footer{
				color: #fff;
				border: 0px !important;
				background: rgba(0,0,0,.2);
			}

		</style>


	</body>

</html>