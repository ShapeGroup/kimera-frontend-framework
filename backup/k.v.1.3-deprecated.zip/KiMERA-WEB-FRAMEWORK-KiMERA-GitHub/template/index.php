<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

	<head>

		<!-- TITLE -->
		<title>KiMERA | BASIC LAYOUT</title>

		<!-- METATAG -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

		<meta name="robots" content="index">
		<meta name="robots" content="follow">

		<meta name="author" content="Alberto Marà"/>
		<meta name="copyright" content="Alberto Marà ITALY ROME | layouts for KiMERA"/>
		<meta name="reply-to" content="albertomara@mail.com">

		<meta http-equiv="content-language" content="Italian"/>
		<meta name="language" content="it-IT"/>
		<meta name="description" content="KiMERA LAYOUT | BASIC"/>
		<meta name="keywords" content="Key1 Key2 Key3 ..."/>

	</head>

	<body class="loaderOn">

		<div class="fillScreen">
			<div class="centry">
				<h2 class="TitlePage textdark">BASIC LAYOUT</h2>
				<hr />
				<a class="floatLeft pad-15 textCenter" target="_inside" href="layout_fullscreen.php" style="background: transparent !important;"  >
					<img class="inLineBlock" style="width: 52px !important; " src="resource/iconLayout_fullscreen.png" alt="" title="optimal for main screen"/><br />
					TYPE 0
				</a>
				<a class="floatLeft pad-15 textCenter" target="_inside" href="layout_fullrow.php" style="background: transparent !important;"  >
					<img class="inLineBlock" style="width: 52px !important; " src="resource/iconLayout_fullrow.png" alt="" title="optimal generic type of site and landing page"/><br />
					TYPE 1
				</a>
				<a class="floatLeft  pad-15" target="_inside" href="layout_rowboxed.php" style="background: transparent !important;"  >
					<img class="inLineBlock" style="width: 52px !important; " src="resource/iconLayout_rowboxed.png" alt="" title="optimal for agency and commercial site"/><br />
					TYPE 2
				</a>
				<a class="floatLeft  pad-15" target="_inside" href="layout_column.php" style="background: transparent !important;"  >
					<img class="inLineBlock" style="width: 52px !important; " src="resource/iconLayout_column.png" alt="" title="optimal for community and other"/><br />
					TYPE 3
				</a>
				<a class="floatLeft  pad-15" target="_inside" href="layout_tabloid.php" style="background: transparent !important;"  >
					<img class="inLineBlock" style="width: 52px !important; " src="resource/iconLayout_tabloid.png" alt="" title="optimal for tabloid and blog"/><br />
					TYPE 4
				</a>
				<a class="floatLeft  pad-15" target="_inside" href="layout_magazine.php" style="background: transparent !important;"  >
					<img class="inLineBlock" style="width: 52px !important; " src="resource/iconLayout_magazine.png" alt="" title="optimal for big blog and magazine"/><br />
					TYPE 5
				</a>
				<a class="floatLeft  pad-15" target="_inside" href="layout_sided.php" style="background: transparent !important;"  >
					<img class="inLineBlock" style="width: 52px !important; " src="resource/iconLayout_sided.png" alt="" title="optimal for professionist and agency site"/><br />
					TYPE 6
				</a>
				<div class="clearAll"></div>
			</div>
		</div>

	</body>

	<!--SCRIPTS & CSS OF PAGE-->

	<!-- include kimera -->
	<link type="text/css" rel="stylesheet" media="screen" href="../kimera/theme/theme.css" charset="utf-8" />
	<link type="text/css" rel="stylesheet" media="screen" href="../kimera/data/pack.dev.css" charset="utf-8" />
	<script type="text/javascript" src="../kimera/data/pack.dev.js"></script>

</html>