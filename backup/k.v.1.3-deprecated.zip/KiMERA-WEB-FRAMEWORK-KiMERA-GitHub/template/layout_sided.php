<!DOCTYPE html>
<html>

	<head>


		<!-- TITLE -->
		<title>KiMERA | BASIC LAYOUT</title>

		<!-- METATAG -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

		<meta name="robots" content="index">
		<meta name="robots" content="follow">

		<meta name="author" content="Alberto Marà"/>
		<meta name="copyright" content="Alberto Marà ITALY ROME | layouts for KiMERA"/>
		<meta name="reply-to" content="albertomara@mail.com">

		<meta http-equiv="content-language" content="Italian"/>
		<meta name="language" content="it-IT"/>
		<meta name="description" content="KiMERA LAYOUT | BASIC"/>
		<meta name="keywords" content="Key1 Key2 Key3 ..."/>


	</head>

	<body class="loaderOn">

		<!-- FIXED SIDE -->
		<div class="fixed-left onlyDesktopOn" style="min-width: 19.5%; max-width: 18%; height: 100%; min-height: 100%; border-right: 1px solid #ccc;">

			<div class="pad-20">
				<a href="index.php">MYLOGO</a>

				<hr style="margin:10px 0 10px 0;" />

				<a class="boxFull textLeft floatLeft pad-15" target="_inside" href="layout_fullscreen.php">TYPE 0</a>
				<a class="boxFull textLeft floatLeft pad-15" target="_inside" href="layout_fullrow.php">TYPE 1</a>
				<a class="boxFull textLeft floatLeft pad-15" target="_inside" href="layout_rowboxed.php">TYPE 2</a>
				<a class="boxFull textLeft floatLeft pad-15" target="_inside" href="layout_column.php">TYPE 3</a>
				<a class="boxFull textLeft floatLeft pad-15" target="_inside" href="layout_tabloid.php">TYPE 4</a>
				<a class="boxFull textLeft floatLeft pad-15" target="_inside" href="layout_magazine.php">TYPE 5</a>
				<a class="boxFull textLeft floatLeft pad-15" target="_inside" href="layout_sided.php">TYPE 6</a>
				<div class="clearAll"></div>

				<hr style="margin:10px 0 10px 0;" />

				<a class="pad-10"><i class="ico-facebook-squared"></i></a>
				<a class="pad-10"><i class="ico-twitter-squared"></i></a>
				<a class="pad-10"><i class="ico-pinterest-squared"></i></a>
				<a class="pad-10"><i class="ico-linkedin-squared"></i></a>
			</div>

		</div>

		<!-- CONTENT WRAP -->
		<div class="gridBox gSpace-0">
			<div class="gBox desktop-20 mobile-0 compact-0">
				&nbsp;
			</div>
			<div class="gBox desktop-80 mobile-100 compact-100">


				<div class="gridBox gSpace-10 pad-20">

					<!-- mobile menu -->
					<div class="gBox desktop-0 mobile-100 compact-100">
						<a class="navSide onlyCompactOn" rel="slideLeft" href="mobilemenu.php"><i class="ico-menu"></i></a>
					</div>

					<!-- SLIDER -->
					<div class="gBox desktop-100 mobile-100 compact-100">
						<h2 class="textLeft">MY PAGE TITLE</h2>
					</div>

					<div class="clearAll"></div><!--security stop-->

					<!-- SLIDER -->
					<div class="gBox desktop-100 mobile-100 compact-off">
						<div class="panel-slider">
							&nbsp;
						</div>
					</div>

					<div class="clearAll"></div><!--security stop-->

					<!-- LEFT CONTENT -->
					<div class="gBox desktop-20 mobile-30 compact-off" style="padding-right: 10px;">

						<div class="panel-examplecontent pad-10 textJustify">
							<p class="pad-10" style="padding-bottom:0px !important;">
								MENU SIDE
							</p>
							<ul class="listSection">
								<li><a class="pad-15">DEMO LINK</a></li>
								<li><a class="pad-15">DEMO LINK</a></li>
								<li><a class="pad-15">DEMO LINK</a></li>
								<li><a class="pad-15">DEMO LINK</a></li>
								<li><a class="pad-15">DEMO LINK</a></li>
							</ul>
						</div>
						<div class="spaceAfter-12"></div>
						<div class="panel-examplecontent pad-10 textJustify">
							<p class="pad-10" style="padding-bottom:0px !important;">
								OTHER BOX
							</p>
							<ul class="listSection">
								<li><a class="pad-15">DEMO LINK</a></li>
								<li><a class="pad-15">DEMO LINK</a></li>
							</ul>
						</div>

					</div>

					<!-- CENTER CONTENT -->
					<div class="gBox desktop-60 mobile-70 compact-100">

						<div class="boxText pad-10 panel-examplecontent">
							<h2 class="titleLarge text-TitlePage text-Colored">THE CONTENT SIDE</h2>
							<h3 class="titleMedium text-TitlePage text-Colored">A LOREM IPSUM - THE DEMO PARAGRAPH</h3>
							<hr />
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, <i>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</i>. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
							<table class="tableCrossed">
								<thead>
									<tr><th> Title... </th></tr>
								</thead>
								<tbody>
									<tr><td> row content... </td></tr>
								</tbody>
								<tfoot>
									<tr><td> Extra... </td></tr>
								</tfoot>
							</table>
							<p>
								Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, <b>eaque ipsa quae ab illo inventore</b> veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.
							</p>
							<p>
								Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?
							</p>
							<hr />
							<p>
								this is a basic themplate demo<br />
								<a href="http://www.lipsum.com/">all about loerm ipsum</a>
							</p>
						</div>

					</div>

					<!-- RIGHT CONTENT -->
					<div class="gBox desktop-20 mobile-off compact-off" style="padding-left:10px;">

						<div class="pad-10 textLeft panel-examplecontent">
							<p class="spaceAfter-10">
								EXTRA SIDE
							</p>
							<a href="http://webpack.org" target="loaderOut">
								<img src="http://1.bp.blogspot.com/-i6YMNMtws2c/TzevFDNAhlI/AAAAAAAAAEk/4lm8o9Oxou0/s1600/AdsHere.jpg" alt="yourAdv">
							</a>
							<a href="http://webpack.org" target="loaderOut">
								<img src="http://1.bp.blogspot.com/-i6YMNMtws2c/TzevFDNAhlI/AAAAAAAAAEk/4lm8o9Oxou0/s1600/AdsHere.jpg" alt="yourAdv">
							</a>
						</div>

					</div>

					<div class="clearAll"></div><!--security stop-->

					<!-- FOOTER -->
					<div class="gBox desktop-100 mobile-100 compact-100" style="padding-left:10px;">
						<div class="panel-footer pad-20">
							<p class="textCenter textclear">
								Powered by KiMERA © // Designer :: <a href="https://www.facebook.com/albertomara.page">Alberto Marà</a> ©
							</p>
						</div>
					</div>

					<div class="clearAll"></div>
				</div>



			</div>
			<div class="clearAll"></div>
		</div>

			

		<!--SCRIPTS & CSS OF PAGE-->

		<!-- include kimera -->
		<link type="text/css" rel="stylesheet" media="screen" href="../kimera/theme/theme.css" charset="utf-8" />
		<link type="text/css" rel="stylesheet" media="screen" href="../kimera/data/pack.dev.css" charset="utf-8" />
		<script type="text/javascript" src="../kimera/data/pack.dev.js"></script>

		<!-- custom script -->
		<script type="text/javascript">
			function MyFunctionName(){
				//bla bla bla...
			};
		</script>

		<!-- /CSS -->
		<style type="text/css">

			.panel-header{
				/*graphics for topbar*/
				border: 0px !important;
			}
				.panel-header a{
					background:  transparent;
					color: white;
				}

			.panel-slider{
				/*slider setting*/
				border: 0px !important;
				height: 400px;
				background: #8e8e8e;
				background: -moz-radial-gradient(center, ellipse cover, #8e8e8e 1%, #424242 100%);
				background: -webkit-radial-gradient(center, ellipse cover, #8e8e8e 1%,#424242 100%);
				background: radial-gradient(ellipse at center, #8e8e8e 1%,#424242 100%);
				filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#8e8e8e', endColorstr='#424242',GradientType=1 );
			}

			.panel-content{
				/*setting for content wrap*/
				border: 0px !important;
				background: #F7F7F4;
			}

			.panel-footer{
				color: #fff;

				border: 2px solid #fff !important;
				-webkit-border-radius: 4px;
				-moz-border-radius: 4px;
				border-radius: 4px;
			}

			/*Puoi creare i pannelli che vuoi usando un'estensione a piacere*/
			.panel-examplecontent{
				border-color: #E4E4E4 !important;
				background: #ffffff;
			}

			/*common*/
			.panel-header,
			.panel-footer{
				background: rgba(0,0,0,.8);
			}

		</style>


	</body>

</html>