<? header("location: ./k-tester/tester-y.php"); ?>

