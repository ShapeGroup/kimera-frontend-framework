<!DOCTYPE html>
<html>

  <head>

      <title>K TESTER</title>
      <meta name="viewport" content="target-densitydpi=150, width=device-width, height=device-height, initial-scale=1, user-scalable=no, minimal-ui">
      <meta http-equiv="Content-type" content="text/html; charset=UTF-8">
      
      <!--Google fonts-->
      <style> @import url('https://fonts.googleapis.com/css?family=Exo:400,700,900&display=swap'); </style> 

      <?

        //less compiler

        $lesspath =  "../lessphp/lessc.inc.php";
        $inputFile =   "../k-theme/theme.less";
        $outputFile =   "../k-theme/theme.css";

        require_once $lesspath; $less = new lessc;
        $less->setFormatter("compressed");
        $less->compileFile($inputFile,$outputFile);

      ?>

      <!-- K core :: wiki > https://git.io/Jv9u1 -->
      <link rel='stylesheet' href='../k-core/core.dev.css'>
      <script type='text/javascript' src='../k-core/core.dev.js'></script>

      <!-- K theme :: core styling override -->
      <link rel='stylesheet' href='../k-theme/theme.css'>

  </head>

  <body class="mode-web scroll-x">

      <span class="space-[100-50-15]" style="min-width:1600px;">

        <h1 class="font-size-1 align-center">K THEME-TEST</h1>

      </span>

      <span class="space-[100-50-15]" style="min-width:1000px;">

          <p> Color test for this theme - Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/GL-::-THEME">Reference -> THEME</a></p>
          <p> <sub>NOTE: from 2.7 "fade" is deprecated</sub> </p>

          <div class="space-05"></div>

          <p>
            The theme manages the colors as if they were the result of the photoshop curves with a series of variables that represent the dark parts, the light ones and finally ... the color (probably will be taken from the brand)<br />
            The colors are also divided by line ... so that you have a clear logic on their use. To understand this, just look at this scheme:
          </p>

          <div class="space-05"></div>

          <p>
            If you notice, on this page, each color is recalled on different elements. Those colors and those elements can be found in the theme.
          </p>

          <div class="space-20"></div>

          <div class="grid-x gap-15 autoset">

            <div class="box-[25-25-25]">
              <div style="margin:0 auto;"><p>&nbsp;</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big align-center"><p>tone tone</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big align-center"><p>midTone</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big align-center"><p>highlight</p></div>
            </div>

            <!--black-->
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;"><p>black:</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big rounded bkg-tone-1"><p>&nbsp;</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big rounded bkg-tone-2"><p>&nbsp;</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big rounded bkg-tone-3"><p>&nbsp;</p></div>
            </div>

            <!--white-->
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;"><p>white:</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big rounded bkg-tone-4"><p>&nbsp;</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big rounded bkg-tone-5"><p>&nbsp;</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big rounded bkg-tone-6"><p>&nbsp;</p></div>
            </div>

            <!--Cromo-->
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;"><p>cromatic :</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big bkg-color-1"><p>&nbsp;</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big bkg-color-2"><p>&nbsp;</p></div>
            </div>
            <div class="box-[25-25-25]">
              <div style="margin:0 auto;" class="space-25 radius-big bkg-color-3"><p>&nbsp;</p></div>
            </div>

            <div class="box-[100-100-100]">
              <div>&nbsp;</div>
            </div>

            <!--logical-->
            <div class="box-[24-24-24]">
              <div style="margin:0 auto;"><p>logical:</p></div>
            </div>
            <div class="box-[19-19-19]">
              <div style=" margin:0 auto;" class="space-25 radius-big bkg-news align-center"><p>news</p></div>
            </div>
            <div class="box-[18-18-18]">
              <div style=" margin:0 auto;" class="space-25 radius-big bkg-pass align-center"><p>pass</p></div>
            </div>
            <div class="box-[18-18-18]">
              <div style=" margin:0 auto;" class="space-25 radius-big bkg-alert align-center"><p>alert</p></div>
            </div>
            <div class="box-[18-18-18]">
              <div style=" margin:0 auto;" class="space-25 radius-big bkg-error align-center"><p>error</p></div>
            </div>

          </div>

      </span>

      <span class="space-[100-50-15]"  style="min-width:800px;">

          <div class="spoiler bkg-tone-6 radius-medium">

              <div class="toggle off  space-10">

                <h2> Basic roles -  Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/API-::-CLASSES#--wide-and-partial-elements">Reference -> Basics</a></h2>
                <div class="space-10"></div>
                <p>
                  Waiting a playground we crate this flap is maded for info on div and span. <br>
                  <b>Click here to open/close details...</b>
                </p>

              </div>

              <div>

                  <div class="space-15">

                    <p>DIV is a "wide box".</p>
                    
                    <div class="space-10"></div>

                    <div style="border: 2px solid #75eebb !important;border-style: dashed !important;">
                      <p> <i> this is a simple div. Expluded container padding... It's wide. </i> </p>
                    </div>
                    
                    <div class="space-10"></div>

                    <p>The div made everything (excluding spans) its wide content. The heights of the div are relative to the content or css you apply to them.</p>

                    <div class="space-10"></div>

                    <div class="spoiler">

                      <div class="toggle off">
                        <p> <b> Click here to open/close an exemple...</b> </p>
                      </div>

                      <div>
                        <div class="space-15"></div>

                        <p>Here is an example of what happens. Excluding spans, almost everything is considered as a div and therefore the content inherits a wide structure. It happens for images, videos, other sub-elements and much more.</p>

                        <div class="space-15"></div>

                        <div style="border: 2px solid #75eebb !important;border-style: dashed !important;">
                          <img src="https://technoblitz.it/wp-content/uploads/2018/06/immagini-4k.jpg" alt="exemple of image into div. div is wide so inner element is wide. The inner element have an propotional height so, div, adapt himself to content.">
                        </div>

                      </div>

                    </div>
                    
                    <div class="space-20"></div>

                    <p>SPAN is a "partial box". It not have a misure... follow the content inside it. All span, follow previous span.</p>

                    <div class="space-15"></div>

                    <div style="border: 2px solid #75eebb !important;border-style: dashed !important;">

                      <span style="border: 2px solid #4a33ee !important;border-style: dotted !important; padding:20px;">
                        <p>this is span</p>
                      </span>

                      <span style="border: 2px solid #4a33ee !important;border-style: dotted !important; padding:20px;">
                        <p>It's flex inline element.</p>
                      </span>

                      <span style="border: 2px solid #4a33ee !important;border-style: dotted !important; padding:20px;">
                        <p>every span follow the previus span</p>
                      </span>

                      <span style="border: 2px solid #4a33ee !important;border-style: dotted !important; padding:20px;">
                        <p>all span have max height of defaul</p>
                      </span>

                      <span style="border: 2px solid #4a33ee !important;border-style: dotted !important; padding:20px;">
                        <p>different to div, the width is not wide. If contents is big, span made biggest... and viceversa.</p>
                      </span>

                    </div>

                    <div class="space-20"></div>

                    <p>Let's assume we want to build a simple menu with these things. With the aid of a simple grill we could do that:</p>

                    <div class="space-15"></div>

                    <div class="grid-x">
                      <div class="box-[66-66-100]">
                        
                        <div style="border: 1px solid #75eebb !important;border-style: dashed !important; height:23px;">
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p>&nbsp;&nbsp;&nbsp;</p>
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <img src="https://image.flaticon.com/icons/svg/1828/1828859.svg" alt="">
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p>&nbsp;&nbsp;&nbsp;</p>
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <img src="https://image.flaticon.com/icons/svg/2111/2111425.svg" alt="">
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p>Item /</p>
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p>Item /</p>
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p>Item /</p>
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p>Item</p>
                          </span>
                        </div>
                        
                      </div>
                      <div class="box-[33-33-100]">
                        <div class="align-right"  style="border: 1px solid #75eebb !important;border-style: dashed !important; height:23px;">
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p><a href="">Login</a> / <a href="">Signup</a> </p>
                          </span>
                          <span style="border: 1px solid #4a33ee !important;border-style: dashed !important;">
                            <p>info</p>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div class="space-15"></div>

                    <p>The spans are centering each element one behind the other. Since the container (a div) is formatted at 23px in height, span will try to proportionally adjust everything respecting that limit.</p>
                    <p>You can do a little experiment to understand how similar this concept is to new design programs (such as figma or sketch). Open the debug and look for height: 23px and change the value. <br> In this framework everything works with this concept of "elasticity based on a proportion"</p>

                  </div>

              </div>

          </div>

      </span>

      <span class="space-[100-50-15]" style="min-width:1200px;">

        <p>Simple application of nav type-x (toolbox bar) -  Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/API-::-CLASSES#-navtype-">Reference -> nav type</a> </p>
        <div class="space-05"></div>
        <p>Navs of this type lend themselves to multiple uses, from photoshop-style palette tools, to side menus, to indexes. <br> "flange" is dynamic tooltips which vary their size according to the given settings.</p>
        <div class="space-05"></div>
        <p>Navs of this type have an super elastic system. They fit horizontally or vertically to their container ... adapting their content.</p>

        <div class="space-15"></div>

        <div class="grid-x gap-30">
          <div class="box-[90-90-80]">
            <div>

              <nav class="type-x bkg-tone-2 radius-medium">
                <ul>
                  <li>
                    <a class="button clearized">
                      <img height="20px" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiBoZWlnaHQ9IjI0cHgiIHZpZXdCb3g9IjAgMCA0NDguMjQ4MjMgNDQ4IiB3aWR0aD0iMjRweCI+PHBhdGggZD0ibTIwOC4xMjUgMTgxLjkwNjI1YzYuNDQxNDA2LTIuMTU2MjUgMTMuNDcyNjU2LTEuNjkxNDA2IDE5LjU3NDIxOSAxLjI4OTA2MiAyLjU3ODEyNSAxLjI5Njg3NiA1LjU5NzY1NiAxLjM5NDUzMiA4LjI1NzgxMi4yNjk1MzJsNC4xNjc5NjktMy4xOTkyMTl2LTI4LjAyMzQzN2gtMzJ6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjxwYXRoIGQ9Im0xNzYuNDkyMTg4IDg4LjM0NzY1NmM1LjEyNS0xLjc2MTcxOCAxMC4zNDM3NS0zLjIzODI4MSAxNS42MzI4MTItNC40MTc5Njh2LTE5LjY4NzVjMC0xNy42NzE4NzYgMTQuMzI0MjE5LTMyIDMyLTMyIDE3LjY3MTg3NSAwIDMyIDE0LjMyODEyNCAzMiAzMnYxOS43MDMxMjRjNS4yODkwNjIgMS4xNzU3ODIgMTAuNTA3ODEyIDIuNjQ0NTMyIDE1LjYzMjgxMiA0LjQwMjM0NGwyLjUyNzM0NC02LjExMzI4MSAyOC4xMDkzNzUtNjcuODcxMDk0Yy01MC40NTMxMjUtMTguOTg0Mzc1LTEwNi4wODU5MzctMTguOTg0Mzc1LTE1Ni41NDI5NjkgMGwyOC4xMTMyODIgNjcuODcxMDk0em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMjA4LjEyNSAyNzAuMzU1NDY5IDEyLjk0MTQwNiAyNS44ODY3MTloNi4xMTMyODJsMTIuOTQ1MzEyLTI1Ljg4NjcxOXYtNzEuNTYyNWMtNi40Mjk2ODggMi4yOTI5NjktMTMuNTE1NjI1IDEuODIwMzEyLTE5LjU4NTkzOC0xLjI5Mjk2OS0yLjc4MTI1LTEuMzg2NzE5LTYuMDU0Njg3LTEuMzg2NzE5LTguODM5ODQzIDAtLjU1MDc4MS4yNzM0MzgtMS4xMzY3MTkuNDg0Mzc1LTEuNzM0Mzc1LjYyODkwNmwtMS44Mzk4NDQuNDQxNDA2em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMjQwLjEyNSA2NC4yNDIxODhjMC04LjgzNTkzOC03LjE2NDA2Mi0xNi0xNi0xNnMtMTYgNy4xNjQwNjItMTYgMTZ2NzJoMzJ6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjxwYXRoIGQ9Im0yMTIuNDI5Njg4IDM4Mi4yNWMtMS44MDA3ODIgMy45NDkyMTktMS40MzM1OTQgOC41NDY4NzUuOTY0ODQzIDEyLjE2MDE1NiAyLjQ2NDg0NCAzLjQ4NDM3NSA2LjQ2NDg0NCA1LjU1NDY4OCAxMC43MzA0NjkgNS41NTQ2ODhzOC4yNjU2MjUtMi4wNzAzMTMgMTAuNzI2NTYyLTUuNTU0Njg4YzIuNDAyMzQ0LTMuNjEzMjgxIDIuNzY5NTMyLTguMjEwOTM3Ljk2ODc1LTEyLjE2MDE1NmwtMTEuNjk1MzEyLTI2LjMxMjV6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjxwYXRoIGQ9Im0zNTMuODk4NDM4IDE2MS44NDM3NSA3My45ODQzNzQtMzAuNjQwNjI1Yy0yMi4yNS00OS4xMTMyODEtNjEuNTkzNzUtODguNDY4NzUtMTEwLjcwMzEyNC0xMTAuNzMwNDY5bC0zMC42NTYyNSA3My45OTIxODhjMjkuNTExNzE4IDE0LjA4MjAzMSA1My4yOTY4NzQgMzcuODY3MTg3IDY3LjM3NSA2Ny4zNzg5MDZ6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjxwYXRoIGQ9Im0yNzMuMTA5Mzc1IDM0Mi41YzQ3LjgyODEyNS0xOS44MTI1IDc5LjAxNTYyNS02Ni40ODgyODEgNzkuMDE1NjI1LTExOC4yNTc4MTIgMC01MS43Njk1MzItMzEuMTg3NS05OC40NDUzMTMtNzkuMDE1NjI1LTExOC4yNTc4MTMtNS41MjczNDQtMi4yMzA0NjktMTEuMjAzMTI1LTQuMDc4MTI1LTE2Ljk4NDM3NS01LjUyNzM0NHYzNS43ODUxNTdoMTZ2MTZoLTE2djEyMGMuMDExNzE5IDEuMjM4MjgxLS4yNjE3MTkgMi40NjA5MzctLjgwMDc4MSAzLjU3NDIxOGwtMTYgMzJjLTEuMzYzMjgxIDIuNzI2NTYzLTQuMTUyMzQ0IDQuNDQxNDA2LTcuMTk5MjE5IDQuNDI1NzgyaC0xNmMtMy4wMzEyNSAwLTUuODA0Njg4LTEuNzEwOTM4LTcuMTYwMTU2LTQuNDI1NzgybC0xNi0zMmMtLjU1NDY4OC0xLjEwOTM3NS0uODQzNzUtMi4zMzIwMzEtLjgzOTg0NC0zLjU3NDIxOHYtMTIwaC0xNnYtMTZoMTZ2LTM1Ljc5Mjk2OWMtNS43ODUxNTYgMS40NDkyMTktMTEuNDU3MDMxIDMuMzAwNzgxLTE2Ljk4NDM3NSA1LjUzNTE1Ni01My44MjQyMTkgMjIuMTk1MzEzLTg1Ljg3MTA5NCA3Ny45Mzc1LTc3Ljk2ODc1IDEzNS42MTcxODcgNy45MDIzNDQgNTcuNjc5Njg4IDUzLjc1NzgxMyAxMDIuNzUgMTExLjU2NjQwNiAxMDkuNjQ4NDM4bDguMTEzMjgxLTE4LjI1MzkwNmMxLjI4NTE1Ny0yLjg5NDUzMiA0LjE0ODQzOC00Ljc1NzgxMyA3LjMxMjUtNC43NTc4MTMgMy4xNjQwNjMgMCA2LjAyNzM0NCAxLjg2MzI4MSA3LjMxMjUgNC43NTc4MTNsOC4xMjEwOTQgMTguMjYxNzE4YzExLjUxNTYyNS0xLjM4MjgxMiAyMi43ODkwNjMtNC4zMzIwMzEgMzMuNTExNzE5LTguNzU3ODEyem0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtNDM0LjAwMzkwNiAxNDUuOTY4NzUtNzMuOTc2NTYyIDMwLjY0MDYyNWMxMC45MDYyNSAzMC44MjAzMTMgMTAuOTA2MjUgNjQuNDQ1MzEzIDAgOTUuMjY1NjI1bDczLjk3NjU2MiAzMC42NDA2MjVjMTguOTkyMTg4LTUwLjQ1MzEyNSAxOC45OTIxODgtMTA2LjA5Mzc1IDAtMTU2LjU0Njg3NXptMCAwIiBmaWxsPSIjRkZGRkZGIi8+PHBhdGggZD0ibTI3MS43NTc4MTIgMzYwLjEzNjcxOWMtOC4yNjk1MzEgMi44ODY3MTktMTYuNzg1MTU2IDUuMDA3ODEyLTI1LjQ0MTQwNiA2LjMzNTkzN2w0LjEyMTA5NCA5LjI3MzQzOGM1LjM3NSAxMi4wNzgxMjUgMS44MzU5MzggMjYuMjY1NjI1LTguNTgyMDMxIDM0LjQwNjI1LTEwLjQyMTg3NSA4LjEzNjcxOC0yNS4wNDI5NjkgOC4xMzY3MTgtMzUuNDYwOTM4IDAtMTAuNDE3OTY5LTguMTQwNjI1LTEzLjk1NzAzMS0yMi4zMjgxMjUtOC41ODIwMzEtMzQuNDA2MjVsNC4xMjg5MDYtOS4yODEyNWMtOC42NjAxNTYtMS4zMjgxMjUtMTcuMTc1NzgxLTMuNDQ1MzEzLTI1LjQ0OTIxOC02LjMyODEyNWwtMi41MjczNDQgNi4xMTMyODEtMjguMTEzMjgyIDY3Ljg3MTA5NGM1MC40NTcwMzIgMTguOTg0Mzc1IDEwNi4wODk4NDQgMTguOTg0Mzc1IDE1Ni41NDI5NjkgMGwtMjguMTA5Mzc1LTY3Ljg3MTA5NHptMCAwIiBmaWxsPSIjRkZGRkZGIi8+PHBhdGggZD0ibTg4LjIxODc1IDE3Ni42MDkzNzUtNzMuOTc2NTYyLTMwLjY0MDYyNWMtMTguOTg4MjgyIDUwLjQ1MzEyNS0xOC45ODgyODIgMTA2LjA5Mzc1IDAgMTU2LjU0Njg3NWw3My45NzY1NjItMzAuNjQwNjI1Yy0xMC45MDIzNDQtMzAuODIwMzEyLTEwLjkwMjM0NC02NC40NDUzMTIgMC05NS4yNjU2MjV6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjxwYXRoIGQ9Im05NC4zNDc2NTYgMjg2LjY0MDYyNS03My45ODQzNzUgMzAuNjU2MjVjMjIuMjUzOTA3IDQ5LjEwOTM3NSA2MS41OTc2NTcgODguNDU3MDMxIDExMC43MDMxMjUgMTEwLjcxNDg0NGwzMC42NDA2MjUtNzMuOTkyMTg4Yy0yOS41MDM5MDYtMTQuMDg1OTM3LTUzLjI4MTI1LTM3Ljg3MTA5My02Ny4zNTkzNzUtNjcuMzc4OTA2em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMTYxLjcyMjY1NiA5NC40NjQ4NDQtMzAuNjM2NzE4LTczLjk5MjE4OGMtNDkuMTA5Mzc2IDIyLjI2MTcxOS04OC40NjA5MzggNjEuNjA1NDY5LTExMC43MjI2NTcgMTEwLjcxNDg0NGw3My45ODQzNzUgMzAuNjQwNjI1YzE0LjA4NTkzOC0yOS41MDc4MTMgMzcuODY3MTg4LTUzLjI4NTE1NiA2Ny4zNzUtNjcuMzYzMjgxem0tNDYuOTEwMTU2LTQ3LjE5OTIxOSA4LjM4MjgxMiAxMy42MDE1NjNjLTQuOTUzMTI0IDMuMDU0Njg3LTkuODAwNzgxIDYuMzQzNzUtMTQuMzk4NDM3IDkuNzkyOTY4bC05LjYwMTU2My0xMi44MDA3ODFjNC45NzY1NjMtMy43NTM5MDYgMTAuMjM0Mzc2LTcuMzIwMzEzIDE1LjYwMTU2My0xMC42MjV6bS01NC4wNDY4NzUgNzYuMDY2NDA2LTEzLjYwMTU2My04LjM3ODkwNmMxMS4yNTc4MTMtMTguMzQzNzUgMjUuMzIwMzEzLTM0LjgxMjUgNDEuNjc5Njg4LTQ4LjgwMDc4MWwxMC4zOTg0MzggMTIuMTc5Njg3Yy0xNS4xMDE1NjMgMTIuODgyODEzLTI4LjA5Mzc1IDI4LjA1NDY4OC0zOC40OTIxODggNDQuOTY0ODQ0em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMjg2LjUyMzQzOCAzNTQuMDE5NTMxIDMwLjY0MDYyNCA3My45OTIxODhjNDkuMTEzMjgyLTIyLjI1MzkwNyA4OC40NjA5MzgtNjEuNjAxNTYzIDExMC43MTg3NS0xMTAuNzE0ODQ0bC03My45ODQzNzQtMzAuNjU2MjVjLTE0LjA4MjAzMiAyOS41MTE3MTktMzcuODYzMjgyIDUzLjI5Njg3NS02Ny4zNzUgNjcuMzc4OTA2em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48L3N2Zz4K" />
                    </a>
                    <div class="flange-bottom radius-medium">
                      <div class="space-50 bkg-tone-2 font-tone-5">
                        <div class="space-15"></div>
                        <p>This is a demo of DIV flap-bottom.</p>
                      </div>
                    </div>
                  </li>
                  <li>
                    <a class="button clearized" href="#plt">
                      <img height="20px" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiBoZWlnaHQ9IjI0cHgiIHZpZXdCb3g9IjAgMCA0NDggNDQ4LjAwMDI4IiB3aWR0aD0iMjRweCI+PHBhdGggZD0ibTE2MCAxODYuMTkxNDA2djcyLjI1NzgxM2w2NS42Nzk2ODggNjUuNjc5Njg3IDU2LjU4NTkzNy01Ni41ODU5MzctMTAxLjgwODU5NC0xMDEuODA4NTk0em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMTkxLjc5Njg3NSAxNTQuMzk4NDM4IDQ1LjIzMDQ2OS00NS4yMzQzNzYgMTAxLjgwODU5NCAxMDEuODA4NTk0LTQ1LjIzNDM3NiA0NS4yMzA0Njl6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjxwYXRoIGQ9Im0wIDI1NmgxNDR2ODBoLTE0NHptMCAwIiBmaWxsPSIjRkZGRkZGIi8+PHBhdGggZD0ibTAgMTYwaDE0NHY4MGgtMTQ0em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMzg0IDMwNGg2NHYxNDRoLTY0em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMzA0IDMwNGg2NHYxNDRoLTY0em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMjQ4LjM0Mzc1IDk3Ljg1MTU2MiA0NS4yNTM5MDYtNDUuMjUzOTA2IDEwMS44MDQ2ODggMTAxLjgwNDY4OC00NS4yNTM5MDYgNDUuMjUzOTA2em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtODAgNDA4YzAgNC40MTc5NjktMy41ODIwMzEgOC04IDhzLTgtMy41ODIwMzEtOC04IDMuNTgyMDMxLTggOC04IDggMy41ODIwMzEgOCA4em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMTkyIDM4MC40MzM1OTQtMjguNTAzOTA2IDI4LjUwMzkwNi0yMi42NDA2MjUgMjIuNjM2NzE5Yy0xLjE5MTQwNyAxLjE5NTMxMi0yLjMyMDMxMyAyLjIzNDM3NS0zLjQ3MjY1NyAzLjIwMzEyNS00LjQ3NjU2MiA0Ljk1NzAzMS05LjUwMzkwNiA5LjM5NDUzMS0xNC45ODQzNzQgMTMuMjIyNjU2aDY5LjYwMTU2MnptMCAwIiBmaWxsPSIjRkZGRkZGIi8+PHBhdGggZD0ibTI4OCAzMDRoLTE5LjU2NjQwNmwtNjAuNDMzNTk0IDYwLjQzMzU5NHY4My41NjY0MDZoODB6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjxwYXRoIGQ9Im03MiA0NDhjOS45MDIzNDQuMDI3MzQ0IDE5LjcwMzEyNS0yLjAyNzM0NCAyOC43NjE3MTktNi4wMzEyNSA5LjUxNTYyNS00LjE2NDA2MiAxOC4wMTk1MzEtMTAuMzI4MTI1IDI0LjkzMzU5My0xOC4wODIwMzEgMi4yODEyNS0yLjU3NDIxOSA0LjM4MjgxMy01LjMwMDc4MSA2LjI4OTA2My04LjE2Nzk2OSA0LjU5NzY1Ni02Ljg2NzE4OCA3Ljk1NzAzMS0xNC40OTIxODggOS45Mjk2ODctMjIuNTE5NTMxIDEuMzg2NzE5LTUuNjI4OTA3IDIuMDg1OTM4LTExLjQwMjM0NCAyLjA4NTkzOC0xNy4xOTkyMTl2LTI0aC0xNDR2MjRjLjA0Njg3NSAzOS43NDYwOTQgMzIuMjUzOTA2IDcxLjk1MzEyNSA3MiA3MnptMC02NGMxMy4yNTM5MDYgMCAyNCAxMC43NDYwOTQgMjQgMjRzLTEwLjc0NjA5NCAyNC0yNCAyNC0yNC0xMC43NDYwOTQtMjQtMjQgMTAuNzQ2MDk0LTI0IDI0LTI0em0wIDAiIGZpbGw9IiNGRkZGRkYiLz48cGF0aCBkPSJtMTYwIDI4MS4wNzAzMTJ2OTQuOTI5Njg4Yy0uMDUwNzgxIDUuMTM2NzE5LS41NTQ2ODggMTAuMjYxNzE5LTEuNTAzOTA2IDE1LjMxMjVsNTUuOTAyMzQ0LTU1Ljg3MTA5NHptMCAwIiBmaWxsPSIjRkZGRkZGIi8+PHBhdGggZD0ibTAgODBoMTQ0djY0aC0xNDR6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjxwYXRoIGQ9Im0wIDBoMTQ0djY0aC0xNDR6bTAgMCIgZmlsbD0iI0ZGRkZGRiIvPjwvc3ZnPgo=" />
                    </a>
                    <span class="flange-bottom radius-medium" style="width:300px;">
                      <div class="bkg-tone-2 space-50 font-tone-5">
                        <p>This is a demo of SPAN flap-bottom.</p>
                      </div>
                    </span>
                  </li>
                  <li>
                    <a class="button clearized" href="#ui">
                      <img height="20px" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCIgdmlld0JveD0iMCAwIDMyOC45MTEgMzI4LjkxMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzI4LjkxMSAzMjguOTExOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxnPgoJPGc+CgkJPHBhdGggZD0iTTMxMC4yMDYsMTguNzFDMjk3LjczNSw2LjI0MiwyODIuNjU3LDAuMDA3LDI2NC45NTgsMC4wMDdINjMuOTU0Yy0xNy43MDMsMC0zMi43OSw2LjIzNS00NS4yNTMsMTguNzA0ICAgIEM2LjIzNSwzMS4xNzcsMCw0Ni4yNjEsMCw2My45NnYyMDAuOTkxYzAsMTcuNTE1LDYuMjMyLDMyLjU1MiwxOC43MDEsNDUuMTFjMTIuNDY3LDEyLjU2NiwyNy41NTMsMTguODQzLDQ1LjI1MywxOC44NDNoMjAxLjAwNCAgICBjMTcuNjk5LDAsMzIuNzc3LTYuMjc2LDQ1LjI0OC0xOC44NDNjMTIuNDctMTIuNTU5LDE4LjcwNS0yNy41OTYsMTguNzA1LTQ1LjExVjYzLjk2ICAgIEMzMjguOTExLDQ2LjI2MSwzMjIuNjcyLDMxLjE3NywzMTAuMjA2LDE4LjcxeiBNMjkyLjM2MiwyNjQuOTZjMCw3LjYxNC0yLjY3MywxNC4wODktOC4wMDEsMTkuNDE0ICAgIGMtNS4zMjQsNS4zMzItMTEuNzk5LDcuOTk0LTE5LjQxLDcuOTk0SDYzLjk1NGMtNy42MTQsMC0xNC4wODItMi42NjItMTkuNDE0LTcuOTk0Yy01LjMzLTUuMzI1LTcuOTkyLTExLjgtNy45OTItMTkuNDE0VjYzLjk2NSAgICBjMC03LjYxMywyLjY2Mi0xNC4wODYsNy45OTItMTkuNDE0YzUuMzI3LTUuMzI3LDExLjgtNy45OTQsMTkuNDE0LTcuOTk0aDIwMS4wMDRjNy42MSwwLDE0LjA4NiwyLjY2MywxOS40MSw3Ljk5NCAgICBjNS4zMjUsNS4zMjgsNy45OTQsMTEuODAxLDcuOTk0LDE5LjQxNFYyNjQuOTZ6IiBmaWxsPSIjRkZGRkZGIi8+CgkJPHBhdGggZD0iTTI0Ni42ODMsMTQ2LjE4OUg4Mi4yMjljLTIuNjY0LDAtNC44NTgsMC44NTUtNi41NjcsMi41NjhjLTEuNzExLDEuNzEzLTIuNTY4LDMuOTAzLTIuNTY4LDYuNTY3djE4LjI3MSAgICBjMCwyLjY2NiwwLjg1NCw0Ljg1NSwyLjU2OCw2LjU2M2MxLjcxMywxLjcwOCwzLjkwMywyLjU3LDYuNTY3LDIuNTdoMTY0LjQ1NGMyLjY2MiwwLDQuODUzLTAuODYyLDYuNTYzLTIuNTcgICAgYzEuNzEyLTEuNzA4LDIuNTYzLTMuODk3LDIuNTYzLTYuNTYzdi0xOC4yNzFjMC0yLjY2NC0wLjg1Mi00Ljg1Ny0yLjU2My02LjU2N0MyNTEuNTM2LDE0Ny4wNDgsMjQ5LjM0NSwxNDYuMTg5LDI0Ni42ODMsMTQ2LjE4OXogICAgIiBmaWxsPSIjRkZGRkZGIi8+Cgk8L2c+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==" />
                    </a>
                    <span class="flange-top radius-medium" style="width:300px;">
                      <div class="bkg-tone-2 space-50 font-tone-5">
                        <p>This is a demo of SPAN flap-top.</p>
                      </div>
                    </span>
                  </li>
                </ul>
              </nav>
              
            </div>
          </div>
          <div class="box-[10-10-20]">
            <div>
              <nav class="type-y bkg-tone-2 radius-medium">
                <ul>
                  <li>
                    <a class="button clearized" href="#font">
                      <img height="20px" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTguMS4xLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDU3My44NTIgNTczLjg1MiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTczLjg1MiA1NzMuODUyOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCI+CjxnPgoJPGc+CgkJPHBhdGggZD0iTTIxNy42NjcsODMuMTI5Yy0xLjYzMi00LjQ4OC00LjY5Mi02LjczMi05LjE4LTYuNzMySDEyOS41NGMtNC40ODgsMC03LjU0OCwyLjI0NC05LjE4LDYuNzMyICAgIEwwLjQwOCw0NzcuMjU3Yy0wLjgxNiwzLjY3Mi0wLjQwOCw2LjMyMSwxLjIyNCw3Ljk1M2MxLjYzMiwyLjQ0OCw0LjI4NCwzLjY3NSw3Ljk1NiwzLjY3NUg4MC41OGM0Ljg5NiwwLDcuOTU2LTIuMjQ0LDkuMTgtNi43MzIgICAgbDIwLjE5Ni03MC45OTJoMTE4LjExN2wyMC4xOTYsNzAuOTkyYzEuMjI0LDQuNDg4LDQuMDgsNi43MzIsOC41NjgsNi43MzJoNzEuNjA0aDAuNjA5YzIuNDQ4LDAsNC41OTMtMC44MTcsNi40MjktMi40NDggICAgczIuNzU0LTMuODc2LDIuNzU0LTYuNzMyYzAtMC44MTQtMC40MDktMi40NDYtMS4yMjctNC44OTZMMjE3LjY2Nyw4My4xMjl6IE0xMjguMzE2LDMzNC42NjFsNDAuMzkyLTE0NC40MzJsNDEuMDA0LDE0NC40MzIgICAgSDEyOC4zMTZ6IE01NDUuMDg3LDIyMC44MjljLTE5LjE3Ni0xNy41NDQtNDYuMTAzLTI2LjMxNi04MC43ODEtMjYuMzE2Yy0yMS42MjQsMC00MS42MTYsMy41Ny01OS45NzcsMTAuNzA5ICAgIGMtMTguMzYxLDcuMTQtMzQuNDc2LDE3LjY0Ni00OC4zNDgsMzEuNTE4Yy0zLjI2NywzLjI2NC0zLjg3Niw2LjkzNi0xLjgzNiwxMS4wMTZsMjIuNjQ0LDM5LjE2NyAgICBjMS4yMjUsMi40NDcsMy40NjcsNC4wOCw2LjczMiw0Ljg5NmMyLjg1NCwwLjgxNyw1LjUwOCwwLDcuOTU2LTIuNDQ4YzE4Ljc2OC0xOS4xNzYsMzkuNTc1LTI4Ljc2NCw2Mi40MjQtMjguNzY0ICAgIGMyOS4zNzUsMCw0NC4wNjIsMTQuMDc3LDQ0LjA2Miw0Mi4yMjh2MTcuNzQ4Yy0xNy4xMzUtMTMuNDY0LTM4LjM1MS0yMC4xOTMtNjMuNjQ2LTIwLjE5M2MtMTEuNDI0LDAtMjIuNzQ2LDEuOTM3LTMzLjk2Niw1LjgxMiAgICBjLTExLjIyMiwzLjg3Ni0yMS4yMTksOS43OTItMjkuOTg4LDE3Ljc0OGMtOC43NzMsNy45NTYtMTUuOTEyLDE4LjE1Ny0yMS40MiwzMC42MDNjLTUuNTA4LDEyLjQ0Mi04LjI2MiwyNy4wMjctOC4yNjIsNDMuNzU4ICAgIGMwLDE2LjMxNywyLjY0OSwzMC42LDcuOTUzLDQyLjg0YzUuMzA3LDEyLjI0LDEyLjQ0NCwyMi41NDIsMjEuNDIzLDMwLjkwNmM4Ljk3NSw4LjM2MiwxOC45NzEsMTQuNjg4LDI5Ljk4NSwxOC45NzIgICAgYzExLjAxOCw0LjI4NCwyMi40NCw2LjQyNiwzNC4yNzIsNi40MjZzMjMuMjU1LTEuODM2LDM0LjI3MS01LjUwOGMxMS4wMTktMy42NzIsMjAuODExLTguOTc1LDI5LjM3Ni0xNS45MTJ2NS41MDggICAgYzAsMi40NDgsMC45MTgsNC41OTMsMi43NTQsNi40MjljMS44MzksMS44MzYsMy45NzksMi43NTQsNi40MjksMi43NTRoNTcuNTI1YzIuNDQ4LDAsNC41OTItMC45MTgsNi40MjktMi43NTQgICAgYzEuODM2LTEuODM2LDIuNzU0LTMuOTc5LDIuNzU0LTYuNDI5di0xODYuMDVDNTczLjg1MywyNjMuMjYxLDU2NC4yNjUsMjM4LjM3Myw1NDUuMDg3LDIyMC44Mjl6IE00OTcuOTY0LDQxOS4xMTYgICAgYy04Ljk3NiwxMy44NzItMjMuMjU2LDIwLjgxMS00Mi44NCwyMC44MTFjLTExLjgzMiwwLTIxLjIxNS0zLjc3NC0yOC4xNDktMTEuMzIyYy02LjkzOC03LjU0OC0xMC40MDQtMTcuNDQzLTEwLjQwNC0yOS42ODUgICAgYzAtMTIuMjM3LDMuNDY3LTIyLjIzMywxMC40MDQtMjkuOTg1YzYuOTM1LTcuNzUyLDE2LjMxNy0xMS42MjgsMjguMTQ5LTExLjYyOGM1LjcxMiwwLDEyLjg1NCwxLjMyNSwyMS40MiwzLjk3OCAgICBjOC41NjgsMi42NTMsMTUuNzA4LDguNjcsMjEuNDIsMTguMDU0VjQxOS4xMTZ6IiBmaWxsPSIjRkZGRkZGIi8+Cgk8L2c+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==" />
                    </a>
                    <span class="flange-left radius-medium" style="width:300px;">
                      <div class="bkg-tone-2 space-20 font-tone-5">
                        <p>This is a demo of SPAN flap-left.</p>
                      </div>
                    </span>
                  </li>
                  <li>
                    <a class="button clearized" href="#table">
                      <img height="20px" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAgMCA1MTIgNTEyIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MTIgNTEyOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCI+CjxnPgoJPGc+CgkJPHBhdGggZD0iTTUwMy40NjcsMTI4SDM1OC40Yy00LjcxLDAtOC41MzMsMy44MjMtOC41MzMsOC41MzNWMjMwLjRjMCw0LjcxLDMuODIzLDguNTMzLDguNTMzLDguNTMzaDE0NS4wNjcgICAgYzQuNzEsMCw4LjUzMy0zLjgyMyw4LjUzMy04LjUzM3YtOTMuODY3QzUxMiwxMzEuODIzLDUwOC4xNzcsMTI4LDUwMy40NjcsMTI4eiIgZmlsbD0iI0ZGRkZGRiIvPgoJPC9nPgo8L2c+CjxnPgoJPGc+CgkJPHBhdGggZD0iTTMyNC4yNjcsMTI4SDE4Ny43MzNjLTQuNzEsMC04LjUzMywzLjgyMy04LjUzMyw4LjUzM1YyMzAuNGMwLDQuNzEsMy44MjMsOC41MzMsOC41MzMsOC41MzNoMTM2LjUzMyAgICBjNC43MSwwLDguNTMzLTMuODIzLDguNTMzLTguNTMzdi05My44NjdDMzMyLjgsMTMxLjgyMywzMjguOTc3LDEyOCwzMjQuMjY3LDEyOHoiIGZpbGw9IiNGRkZGRkYiLz4KCTwvZz4KPC9nPgo8Zz4KCTxnPgoJCTxwYXRoIGQ9Ik0xNTMuNiwxMjhIOC41MzNDMy44MjMsMTI4LDAsMTMxLjgyMywwLDEzNi41MzNWMjMwLjRjMCw0LjcxLDMuODIzLDguNTMzLDguNTMzLDguNTMzSDE1My42ICAgIGM0LjcxLDAsOC41MzMtMy44MjMsOC41MzMtOC41MzN2LTkzLjg2N0MxNjIuMTMzLDEzMS44MjMsMTU4LjMxLDEyOCwxNTMuNiwxMjh6IiBmaWxsPSIjRkZGRkZGIi8+Cgk8L2c+CjwvZz4KPGc+Cgk8Zz4KCQk8cGF0aCBkPSJNMzI0LjI2NywyNTZIMTg3LjczM2MtNC43MSwwLTguNTMzLDMuODIzLTguNTMzLDguNTMzVjM1OC40YzAsNC43MSwzLjgyMyw4LjUzMyw4LjUzMyw4LjUzM2gxMzYuNTMzICAgIGM0LjcxLDAsOC41MzMtMy44MjMsOC41MzMtOC41MzN2LTkzLjg2N0MzMzIuOCwyNTkuODIzLDMyOC45NzcsMjU2LDMyNC4yNjcsMjU2eiIgZmlsbD0iI0ZGRkZGRiIvPgoJPC9nPgo8L2c+CjxnPgoJPGc+CgkJPHBhdGggZD0iTTE1My42LDI1Nkg4LjUzM0MzLjgyMywyNTYsMCwyNTkuODIzLDAsMjY0LjUzM1YzNTguNGMwLDQuNzEsMy44MjMsOC41MzMsOC41MzMsOC41MzNIMTUzLjYgICAgYzQuNzEsMCw4LjUzMy0zLjgyMyw4LjUzMy04LjUzM3YtOTMuODY3QzE2Mi4xMzMsMjU5LjgyMywxNTguMzEsMjU2LDE1My42LDI1NnoiIGZpbGw9IiNGRkZGRkYiLz4KCTwvZz4KPC9nPgo8Zz4KCTxnPgoJCTxwYXRoIGQ9Ik01MDMuNDY3LDI1NkgzNTguNGMtNC43MSwwLTguNTMzLDMuODIzLTguNTMzLDguNTMzVjM1OC40YzAsNC43MSwzLjgyMyw4LjUzMyw4LjUzMyw4LjUzM2gxNDUuMDY3ICAgIGM0LjcxLDAsOC41MzMtMy44MjMsOC41MzMtOC41MzN2LTkzLjg2N0M1MTIsMjU5LjgyMyw1MDguMTc3LDI1Niw1MDMuNDY3LDI1NnoiIGZpbGw9IiNGRkZGRkYiLz4KCTwvZz4KPC9nPgo8Zz4KCTxnPgoJCTxwYXRoIGQ9Ik01MDMuNDY3LDM4NEgzNTguNGMtNC43MSwwLTguNTMzLDMuODIzLTguNTMzLDguNTMzdjExMC45MzNjMCw0LjcxLDMuODIzLDguNTMzLDguNTMzLDguNTMzaDE0NS4wNjcgICAgYzQuNzEsMCw4LjUzMy0zLjgyMyw4LjUzMy04LjUzM1YzOTIuNTMzQzUxMiwzODcuODIzLDUwOC4xNzcsMzg0LDUwMy40NjcsMzg0eiIgZmlsbD0iI0ZGRkZGRiIvPgoJPC9nPgo8L2c+CjxnPgoJPGc+CgkJPHBhdGggZD0iTTMyNC4yNjcsMzg0SDE4Ny43MzNjLTQuNzEsMC04LjUzMywzLjgyMy04LjUzMyw4LjUzM3YxMTAuOTMzYzAsNC43MSwzLjgyMyw4LjUzMyw4LjUzMyw4LjUzM2gxMzYuNTMzICAgIGM0LjcxLDAsOC41MzMtMy44MjMsOC41MzMtOC41MzNWMzkyLjUzM0MzMzIuOCwzODcuODIzLDMyOC45NzcsMzg0LDMyNC4yNjcsMzg0eiIgZmlsbD0iI0ZGRkZGRiIvPgoJPC9nPgo8L2c+CjxnPgoJPGc+CgkJPHBhdGggZD0iTTUwMy40NjcsMEg4LjUzM0MzLjgyMywwLDAsMy44MjMsMCw4LjUzM1YxMDIuNGMwLDQuNzEsMy44MjMsOC41MzMsOC41MzMsOC41MzNoNDk0LjkzM2M0LjcxLDAsOC41MzMtMy44MjMsOC41MzMtOC41MzMgICAgVjguNTMzQzUxMiwzLjgyMyw1MDguMTc3LDAsNTAzLjQ2NywweiIgZmlsbD0iI0ZGRkZGRiIvPgoJPC9nPgo8L2c+CjxnPgoJPGc+CgkJPHBhdGggZD0iTTE1My42LDM4NEg4LjUzM0MzLjgyMywzODQsMCwzODcuODIzLDAsMzkyLjUzM3YxMTAuOTMzQzAsNTA4LjE3NywzLjgyMyw1MTIsOC41MzMsNTEySDE1My42ICAgIGM0LjcxLDAsOC41MzMtMy44MjMsOC41MzMtOC41MzNWMzkyLjUzM0MxNjIuMTMzLDM4Ny44MjMsMTU4LjMxLDM4NCwxNTMuNiwzODR6IiBmaWxsPSIjRkZGRkZGIi8+Cgk8L2c+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==" />
                    </a>
                    <div class="flange-left radius-medium" style="width:300px;">
                      <div class="maxheight bkg-tone-2 space-20 font-tone-5">
                        <p>This is a demo of DIV flap-left.</p>
                      </div>
                    </div>
                  </li>
                  <li>
                    <a class="button clearized" href="#comps">
                      <img height="20px" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzNy4xNDUgMTM3LjE0NSIgZW5hYmxlLWJhY2tncm91bmQ9Im5ldyAwIDAgMTM3LjE0NSAxMzcuMTQ1IiB3aWR0aD0iMjRweCIgaGVpZ2h0PSIyNHB4Ij4KICA8Zz4KICAgIDxnPgogICAgICA8cGF0aCBkPSJtMzQuMjg3LDYxLjcxNnYxMy43MTRjMC00LjM3NCAwLjAwOS01LjE1NSAwLTEzLjcxNHptMCwyMC41NzJ2LTYuODU4YzAsNC40LTAuMDI5LDIuMTc0IDAsNi44NTh6bTc1LjQyOS04Mi4yODhoLTgyLjI4N2MtMTUuMTQ4LDAtMjcuNDI5LDEyLjI4MS0yNy40MjksMjcuNDI5djgyLjI4N2MwLDE1LjE0OCAxMi4yOCwyNy40MjkgMjcuNDI5LDI3LjQyOWg4Mi4yODZjMTUuMTQ5LDAgMjcuNDI5LTEyLjI4IDI3LjQyOS0yNy40Mjl2LTgyLjI4N2MwLTE1LjE0OC0xMi4yOC0yNy40MjktMjcuNDI4LTI3LjQyOXptMTMuNzE0LDEwMi44NThjMCwxMS4zNjEtOS4yMSwyMC41NzItMjAuNTcxLDIwLjU3MmgtNjguNTczYy0xMS4zNjEsMC0yMC41NzItOS4yMTEtMjAuNTcyLTIwLjU3MnYtNjguNTcyYzAtMTEuMzYxIDkuMjEtMjAuNTcyIDIwLjU3Mi0yMC41NzJoNjguNTcyYzExLjM2MSwwIDIwLjU3MSw5LjIxMSAyMC41NzEsMjAuNTcydjY4LjU3MnptLTIzLjk5OS00MS4xNDJjLTEuMjE2LDAtMi4zNDUsMC4zMDQtMy40MjgsMC42OTJ2LTIxLjI2NGgtMjEuMjY0YzAuMzg3LTEuMDgzIDAuNjkyLTIuMjEyIDAuNjkyLTMuNDI4IDAtNS42ODEtNC42MDUtMTAuMjg2LTEwLjI4Ni0xMC4yODYtNS42ODEsMC0xMC4yODYsNC42MDUtMTAuMjg2LDEwLjI4NiAwLDEuMjE2IDAuMzA1LDIuMzQ2IDAuNjkyLDMuNDI4aC0yMS4yNjN2MjAuNTcyYy0wLjAwMS0xLjIzMyAyLjEyMSwwIDMuNDI5LDAgNS42ODEsMCAxMC4yODYsNC42MDUgMTAuMjg2LDEwLjI4NiAwLDUuNjgtNC42MDUsMTAuMjg2LTEwLjI4NiwxMC4yODYtMS4yOCwwLTMuNDIxLDEuMjA4LTMuNDI5LDB2MjAuNTcxaDYxLjcxNXYtMjEuMjY0YzEuMDgzLDAuMzg4IDIuMjEyLDAuNjkzIDMuNDI4LDAuNjkzIDUuNjgxLDAgMTAuMjg2LTQuNjA2IDEwLjI4Ni0xMC4yODYtMS40MjEwOWUtMTQtNS42ODEtNC42MDUtMTAuMjg2LTEwLjI4Ni0xMC4yODZ6IiBmaWxsPSIjRkZGRkZGIi8+CiAgICA8L2c+CiAgPC9nPgo8L3N2Zz4K" />
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>

      </span>
                
      <span class="space-[100-50-15]" style="min-width:1800px;">

        <div class="space-[100-50-15]">

          <p>Ui system. Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/API-::-UI-ASSET">Reference -> ui assets</a> </p>

          <div class="space-05"></div>

          <p>
            you can see that the framework does not give you any "primary, secondary etc" button because it is set up for a base, not a finished one. It is up to you to decide the information architecture and how.<br>
            However, you have at your disposal both the logical colors and the classes capable of limiting the appearance of the buttons to recreate the same effect.<br>
            Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/API-::-UI-ASSET#-uxd-and-logical-actions---all-reset-and-status-classes">Reference -> ui assets -> uxd-and-logical-actions</a>
          </p>

          <div class="space-05"></div>

          <p>
            How is an asset of this type valid? The framework does not yet officially support "plug-ins" but we have already created a js class that integrates perfectly, an excellent basis for processing at will ... <a target="_blank" href="">You can find it here</a>.
          </p>

          <div class="space-05"></div>

          <p>
            Coming soon: button-dropfile; button-timer; button-datetime;
          </p>

          <div class="space-05"></div>
          

          <div class="space-15"></div>

          <div class="grid-x gap-15">

            <div class="box-[25-50-100]">
              <p class="space-05 font-tone-3">link</p>
              <div class="button-action">
                <a>This is a link</a>
              </div>
            </div>

            <div class="box-[25-50-100]">
              <p class="space-05 font-tone-3">button</p>
              <div class="button">
                <button>Classic button</button>
              </div>
            </div>

            <div class="box-[25-50-100]">
              <p class="space-05 font-tone-3">input submit</p>
              <div class="button-action">
                <input type="submit" value="Classic submit" />
              </div>
            </div>

            <div class="box-[25-50-100]">
              <p class="space-05 font-tone-3">file</p>
              <div class="button-file">
                  <input type="file" multiple="true" size="0.5" maxsize="1.5" minlength="1" maxlength="8" accept="png, jpeg, jpg"/>
                  <p class="ellipsis">Upload a File</p>
              </div>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">select</p>
              <div class="button-select">
                <p>select an option...</p>
                <select value="select an option...">
                    <optgroup label="type of coding">
                      <option value="CSS">CSS</option>
                      <option value="JAVASCRIPT">JAVSCRIPT</option>
                      <option value="HTML">HTML</option>
                      <option value="PHP">PHP</option>
                    </optgroup>
                    <optgroup label="type of canvas">
                      <option value="WEB">WEB</option>
                      <option value="CORDOVA">CORDOVA</option>
                      <option value="ELECTRON">ELECTRON</option>
                    </optgroup>
                    <optgroup label="type of device">
                      <option value="ANDROID">ANDROID</option>
                      <option value="IOS">IOS</option>
                      <option value="LINUX">LINUX</option>
                      <option value="WINDOW">WINDOW</option>
                    </optgroup>
                </select>
              </div>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">time</p>
              <div class="button-time">
                <p>Hours:Minutes</p>
                <input type="time">
              </div>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">date</p>
              <div class="button-date UTC MDY -compact">
                  <p>open UTC MDY -compact calendar...</p>
                  <input type="text" value="Select a date" />
              </div>
            </div>

            <!-- complete dating action on next versions
            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">date and time</p>
              <div class="button-datetime">
                  <p>Select new date...</p>
                  <input type="text" value="Select a date" />
              </div>
            </div>
           -->

            <div class="box-[33-50-100]">
                <p class="space-05 font-tone-3">number</p>
                <div class="button-number">
                  <span>
                    <img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMjRweCIgdmVyc2lvbj0iMS4xIiBoZWlnaHQ9IjI0cHgiIHZpZXdCb3g9IjAgMCA2NCA2NCIgZW5hYmxlLWJhY2tncm91bmQ9Im5ldyAwIDAgNjQgNjQiPgogIDxnPgogICAgPGcgZmlsbD0iIzFEMUQxQiI+CiAgICAgIDxwYXRoIGQ9Im00Ni41NTEsMzAuMTE5aC0yOC4yODVjLTEuMTA1LDAtMiwwLjg5Ni0yLDJzMC44OTUsMiAyLDJoMjguMjg1YzEuMTA1LDAgMi0wLjg5NiAyLTJzLTAuODk1LTItMi0yeiIgZmlsbD0iI0ZGRkZGRiIvPgogICAgICA8cGF0aCBkPSJNMzIsMEMxNC4zNTUsMCwwLDE0LjM1NSwwLDMyczE0LjM1NSwzMiwzMiwzMnMzMi0xNC4zNTUsMzItMzJTNDkuNjQ1LDAsMzIsMHogTTMyLDYwICAgIEMxNi41NjEsNjAsNCw0Ny40MzksNCwzMlMxNi41NjEsNCwzMiw0czI4LDEyLjU2MSwyOCwyOFM0Ny40MzksNjAsMzIsNjB6IiBmaWxsPSIjRkZGRkZGIi8+CiAgICA8L2c+CiAgPC9nPgo8L3N2Zz4K" />
                  </span>
                  <span>
                    <img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMjRweCIgdmVyc2lvbj0iMS4xIiBoZWlnaHQ9IjI0cHgiIHZpZXdCb3g9IjAgMCA2NCA2NCIgZW5hYmxlLWJhY2tncm91bmQ9Im5ldyAwIDAgNjQgNjQiPgogIDxnPgogICAgPGcgZmlsbD0iIzFEMUQxQiI+CiAgICAgIDxwYXRoIGQ9Im00Ni41NTEsMzAuMTE5aC0xMi4xNDN2LTEyLjE0MmMwLTEuMTA0LTAuODk1LTItMi0ycy0yLDAuODk2LTIsMnYxMi4xNDNoLTEyLjE0MmMtMS4xMDUsMC0yLDAuODk2LTIsMnMwLjg5NSwyIDIsMmgxMi4xNDN2MTIuMTQzYzAsMS4xMDQgMC44OTUsMiAyLDJzMi0wLjg5NiAyLTJ2LTEyLjE0NGgxMi4xNDNjMS4xMDUsMCAyLTAuODk2IDItMnMtMC44OTYtMi0yLjAwMS0yeiIgZmlsbD0iI0ZGRkZGRiIvPgogICAgICA8cGF0aCBkPSJNMzIsMEMxNC4zNTUsMCwwLDE0LjM1NSwwLDMyczE0LjM1NSwzMiwzMiwzMnMzMi0xNC4zNTUsMzItMzJTNDkuNjQ1LDAsMzIsMHogTTMyLDYwICAgIEMxNi41NjEsNjAsNCw0Ny40MzksNCwzMlMxNi41NjEsNCwzMiw0czI4LDEyLjU2MSwyOCwyOFM0Ny40MzksNjAsMzIsNjB6IiBmaWxsPSIjRkZGRkZGIi8+CiAgICA8L2c+CiAgPC9nPgo8L3N2Zz4K" />
                  </span>
                  <div><!--automatic displayed numbers--></div>
                  <input type="number" min="-20" max="20" value="0" readonly />
                </div>
            </div>

            <div class="box-[33-50-100]">
              <p class="space-05 font-tone-3">range</p>

              <div class="button-range">

                <div class="labels"><p>min</p><p>max</p></div>

                <div class="sliders">

                  <span class="monitor"><p>0</p></span>

                  <input type="range" value="-90" min="-100" max="100" />
                  <span style="background-color:rgb(135, 24, 47) !important;"></span><b></b>

                  <input type="range" value="-33" min="-100" max="100" />
                  <span style="background-color:rgb(209, 29, 249) !important;"></span><b></b>

                  <input type="range" value="33" min="-100" max="100" />
                  <span style="background-color:rgb(232, 236, 116) !important;"></span><b></b>

                  <input type="range" value="90" min="-100" max="100" />
                  <span style="background-color:rgb(181, 251, 50) !important;"></span><b></b>

                </div>

              </div>

            </div>

            <div class="box-[50-50-100]">
              <p class="space-05 font-tone-3">icon-before, icon, icon-after</p>
              <button class="button-action">
                <img class="before" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDQ5Ljk0IDQ5Ljk0IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA0OS45NCA0OS45NDsiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIxNnB4IiBoZWlnaHQ9IjE2cHgiPgo8cGF0aCBkPSJNNDguODU2LDIyLjczYzAuOTgzLTAuOTU4LDEuMzMtMi4zNjQsMC45MDYtMy42NzFjLTAuNDI1LTEuMzA3LTEuNTMyLTIuMjQtMi44OTItMi40MzhsLTEyLjA5Mi0xLjc1NyAgYy0wLjUxNS0wLjA3NS0wLjk2LTAuMzk4LTEuMTktMC44NjVMMjguMTgyLDMuMDQzYy0wLjYwNy0xLjIzMS0xLjgzOS0xLjk5Ni0zLjIxMi0xLjk5NmMtMS4zNzIsMC0yLjYwNCwwLjc2NS0zLjIxMSwxLjk5NiAgTDE2LjM1MiwxNGMtMC4yMywwLjQ2Ny0wLjY3NiwwLjc5LTEuMTkxLDAuODY1TDMuMDY5LDE2LjYyMmMtMS4zNTksMC4xOTctMi40NjcsMS4xMzEtMi44OTIsMi40MzggIGMtMC40MjQsMS4zMDctMC4wNzcsMi43MTMsMC45MDYsMy42NzFsOC43NDksOC41MjhjMC4zNzMsMC4zNjQsMC41NDQsMC44ODgsMC40NTYsMS40TDguMjI0LDQ0LjcwMSAgYy0wLjE4MywxLjA2LDAuMDk1LDIuMDkxLDAuNzgxLDIuOTA0YzEuMDY2LDEuMjY3LDIuOTI3LDEuNjUzLDQuNDE1LDAuODcxbDEwLjgxNC01LjY4NmMwLjQ1Mi0wLjIzNywxLjAyMS0wLjIzNSwxLjQ3MiwwICBsMTAuODE1LDUuNjg2YzAuNTI2LDAuMjc3LDEuMDg3LDAuNDE3LDEuNjY2LDAuNDE3YzEuMDU3LDAsMi4wNTktMC40NywyLjc0OC0xLjI4OGMwLjY4Ny0wLjgxMywwLjk2NC0xLjg0NiwwLjc4MS0yLjkwNCAgbC0yLjA2NS0xMi4wNDJjLTAuMDg4LTAuNTEzLDAuMDgzLTEuMDM2LDAuNDU2LTEuNEw0OC44NTYsMjIuNzN6IiBmaWxsPSIjRkZGRkZGIi8+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=" />
                <img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDQ5Ljk0IDQ5Ljk0IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA0OS45NCA0OS45NDsiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIxNnB4IiBoZWlnaHQ9IjE2cHgiPgo8cGF0aCBkPSJNNDguODU2LDIyLjczYzAuOTgzLTAuOTU4LDEuMzMtMi4zNjQsMC45MDYtMy42NzFjLTAuNDI1LTEuMzA3LTEuNTMyLTIuMjQtMi44OTItMi40MzhsLTEyLjA5Mi0xLjc1NyAgYy0wLjUxNS0wLjA3NS0wLjk2LTAuMzk4LTEuMTktMC44NjVMMjguMTgyLDMuMDQzYy0wLjYwNy0xLjIzMS0xLjgzOS0xLjk5Ni0zLjIxMi0xLjk5NmMtMS4zNzIsMC0yLjYwNCwwLjc2NS0zLjIxMSwxLjk5NiAgTDE2LjM1MiwxNGMtMC4yMywwLjQ2Ny0wLjY3NiwwLjc5LTEuMTkxLDAuODY1TDMuMDY5LDE2LjYyMmMtMS4zNTksMC4xOTctMi40NjcsMS4xMzEtMi44OTIsMi40MzggIGMtMC40MjQsMS4zMDctMC4wNzcsMi43MTMsMC45MDYsMy42NzFsOC43NDksOC41MjhjMC4zNzMsMC4zNjQsMC41NDQsMC44ODgsMC40NTYsMS40TDguMjI0LDQ0LjcwMSAgYy0wLjE4MywxLjA2LDAuMDk1LDIuMDkxLDAuNzgxLDIuOTA0YzEuMDY2LDEuMjY3LDIuOTI3LDEuNjUzLDQuNDE1LDAuODcxbDEwLjgxNC01LjY4NmMwLjQ1Mi0wLjIzNywxLjAyMS0wLjIzNSwxLjQ3MiwwICBsMTAuODE1LDUuNjg2YzAuNTI2LDAuMjc3LDEuMDg3LDAuNDE3LDEuNjY2LDAuNDE3YzEuMDU3LDAsMi4wNTktMC40NywyLjc0OC0xLjI4OGMwLjY4Ny0wLjgxMywwLjk2NC0xLjg0NiwwLjc4MS0yLjkwNCAgbC0yLjA2NS0xMi4wNDJjLTAuMDg4LTAuNTEzLDAuMDgzLTEuMDM2LDAuNDU2LTEuNEw0OC44NTYsMjIuNzN6IiBmaWxsPSIjRkZGRkZGIi8+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=" />
                <img class="after" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDQ5Ljk0IDQ5Ljk0IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA0OS45NCA0OS45NDsiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIxNnB4IiBoZWlnaHQ9IjE2cHgiPgo8cGF0aCBkPSJNNDguODU2LDIyLjczYzAuOTgzLTAuOTU4LDEuMzMtMi4zNjQsMC45MDYtMy42NzFjLTAuNDI1LTEuMzA3LTEuNTMyLTIuMjQtMi44OTItMi40MzhsLTEyLjA5Mi0xLjc1NyAgYy0wLjUxNS0wLjA3NS0wLjk2LTAuMzk4LTEuMTktMC44NjVMMjguMTgyLDMuMDQzYy0wLjYwNy0xLjIzMS0xLjgzOS0xLjk5Ni0zLjIxMi0xLjk5NmMtMS4zNzIsMC0yLjYwNCwwLjc2NS0zLjIxMSwxLjk5NiAgTDE2LjM1MiwxNGMtMC4yMywwLjQ2Ny0wLjY3NiwwLjc5LTEuMTkxLDAuODY1TDMuMDY5LDE2LjYyMmMtMS4zNTksMC4xOTctMi40NjcsMS4xMzEtMi44OTIsMi40MzggIGMtMC40MjQsMS4zMDctMC4wNzcsMi43MTMsMC45MDYsMy42NzFsOC43NDksOC41MjhjMC4zNzMsMC4zNjQsMC41NDQsMC44ODgsMC40NTYsMS40TDguMjI0LDQ0LjcwMSAgYy0wLjE4MywxLjA2LDAuMDk1LDIuMDkxLDAuNzgxLDIuOTA0YzEuMDY2LDEuMjY3LDIuOTI3LDEuNjUzLDQuNDE1LDAuODcxbDEwLjgxNC01LjY4NmMwLjQ1Mi0wLjIzNywxLjAyMS0wLjIzNSwxLjQ3MiwwICBsMTAuODE1LDUuNjg2YzAuNTI2LDAuMjc3LDEuMDg3LDAuNDE3LDEuNjY2LDAuNDE3YzEuMDU3LDAsMi4wNTktMC40NywyLjc0OC0xLjI4OGMwLjY4Ny0wLjgxMywwLjk2NC0xLjg0NiwwLjc4MS0yLjkwNCAgbC0yLjA2NS0xMi4wNDJjLTAuMDg4LTAuNTEzLDAuMDgzLTEuMDM2LDAuNDU2LTEuNEw0OC44NTYsMjIuNzN6IiBmaWxsPSIjRkZGRkZGIi8+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=" />
              </button>
            </div>

            <div class="box-[50-50-100]">
              <div>
                <p class="space-05 font-tone-3">Selectable</p>
                <div class="button-group">
                  <div class="button-text">
                    <label>selectable option</label>
                  </div>
                  <div class="button-radio">
                    <input type="radio" name="selection" />
                    <div><p>YES</p></div>
                  </div>
                  <div class="button-radio">
                    <input type="radio" name="selection" />
                    <div><p>NO</p></div>
                  </div>
                </div>
              </div>
            </div>

            <div class="box-[16-16-50]">
              <p class="space-05 font-tone-3">Checkbox</p>
              <div class="button-checkbox">
                  <p class="before">mylabel</p>
                  <input type="checkbox" name="checkbox" />
                  <span class="after"></span>
              </div>
            </div>

            <div class="box-[16-16-50]">
              <p class="space-05 font-tone-3">Checkbox</p>
              <div class="button-checkbox">
                  <p class="before">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mylabel</p>
                  <input type="checkbox" name="checkbox" />
                  <span class="before"></span>
              </div>
            </div>

            <div class="box-[16-16-50]">
              <p class="space-05 font-tone-3">Checkbox</p>
              <div class="button-checkbox">
                  <p class="after">mylabel</p>
                  <input type="checkbox" name="checkbox" />
                  <span class="before"></span>
              </div>
            </div>

            <div class="box-[16-16-50]">
              <p class="space-05 font-tone-3">Radiobox</p>
              <div class="button-radio">
                  <p class="after">&nbsp;&nbsp;mylabel</p>
                  <input type="radio" name="radio" />
                  <span class="before"></span>
              </div>
            </div>

            <div class="box-[16-16-50]">
              <p class="space-05 font-tone-3">Radiobox</p>
              <div class="button-radio">
                  <p class="before">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mylabel</p>
                  <input type="radio" name="radio" />
                  <span class="before"></span>
              </div>
            </div>

            <div class="box-[16-16-50]">
              <p class="space-05 font-tone-3">Radiobox</p>
              <div class="button-radio">
                  <p class="before">&nbsp;&nbsp;mylabel</p>
                  <input type="radio" name="radio" />
                  <span class="after"></span>
              </div>
            </div>

          </div>

        </div>

      </span>

      <span class="space-[100-50-15]" style="min-width:1800px;">

        <div class="space-[100-50-15]">

          <div class="grid-x gap-15">

            <div class="box-[50-50-100]">
              <p class="space-05 font-tone-3">button-group exemple</p>
              <div class="button-group">
                <div class="button-text">
                  <input type="text" placeholder="your text"/>
                </div>
                <div class="button-action">
                  <input type="submit" value="SUBMIT" />
                </div>
              </div>
            </div>

            <div class="box-[50-50-100]">
              <p class="space-05 font-tone-3">button-group "setmobile" (reintroduced - remember: It's overflow hidden)</p>
              <div class="button-group setmobile">
                <div class="button-text disabled">
                  <label>LABEL TITLE</label>
                </div>
                <div class="button-text">
                  <input type="text" placeholder="your text" />
                </div>
                <div class="button-action">
                  <input  type="submit" value="SUBMIT" />
                </div>
              </div>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">simple text label</p>
              <label class="button-text">LABEL</label>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">input text</p>
              <div class="button-text">
                <input type="text" placeholder="your text" />
              </div>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">input email</p>
              <div class="button-text">
                <input type="email" placeholder="your@email.com" />
              </div>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">input search</p>
              <div class="button-text">
                <input type="search" placeholder="search now" />
              </div>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">input site</p>
              <div class="button-text">
                <input type="url" placeholder="www.yoursite.com" />
              </div>
            </div>

            <div class="box-[33-33-100]">
              <p class="space-05 font-tone-3">input phone</p>
              <div class="button-text">
                <input type="tel" placeholder="+39 000 00 00 0000" pattern="[0-9]{10}" />
              </div>
            </div>

            <div class="box-[100-100-100]">
              <p class="space-05 font-tone-3">simple textarea</p>
              <div class="button-text">
                <textarea>Exemple...</textarea>
              </div>
            </div>

            <div class="box-[100-100-100]">
              <div class="space-[30-30-15]"></div>
            </div>

            <div class="box-[25-25-50]">
              <div class="button-text border-pass">
                <label>border-pass</label>
              </div>
            </div>

            <div class="box-[25-25-50]">
              <div class="button-text border-error">
                <label>border-error</label>
              </div>
            </div>

            <div class="box-[25-25-50]">
              <div class="button-text border-alert">
                <label>border-alert</label>
              </div>
            </div>

            <div class="box-[25-25-50]">
              <div class="button-text border-news">
                <label>border-news</label>
              </div>
            </div>

            <div class="box-[25-25-50]">
              <div class="button-text bkg-pass">
                <label>bkg-pass</label>
              </div>
            </div>

            <div class="box-[25-25-50]">
              <div class="button-text bkg-error">
                <label>bkg-error</label>
              </div>
            </div>

            <div class="box-[25-25-50]">
              <div class="button-text bkg-alert">
                <label>bkg-alert</label>
              </div>
            </div>

            <div class="box-[25-25-50]">
              <div class="button-text bkg-news">
                <label>bkg-news</label>
              </div>
            </div>

            <div class="box-[100-100-100]">
              <div class="space-[30-30-15]"></div>
            </div>

          </div>

        </div>

      </span>

      <span class="space-[100-50-15]" style="min-width:1200px;">

        <p> Tabs - Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/API-::-CLASSES#-tabs-">Reference -> tabs-x and y</a></p>
        <p> A standard simple system hide/show elements </p>

        <div class="space-05"></div>

        <div class="grid-x gap-20">
          <div class="box-[75-75-100]">

            <div class="tabs-x">

              <nav class="align-right">

                 <p>FONT TEST</p>

                 <a> Dark line </a>
                 <a> Clear line </a>
                 <a class="active"> Chromatic </a>
                 <a> Post Test </a>

              </nav>

              <div>

                <div class="bkg-tone-3 font-tone-6 space-20">

                  <p>Typography: tone-3 / tone-6</p>

                  <div class="space-05"></div>

                  <div class="grid-x gap-20">

                    <div class="box-[33-33-100]">

                      <div class="text-group">

                        <h1 class="font-size-1">size-1</h1>
                        <h2 class="font-size-2">size-2</h2>
                        <h3 class="font-size-3">size-3</h3>
                        <h4 class="font-size-4">size-4</h4>
                        <h5 class="font-size-5">size-5</h5>
                        <h6 class="font-size-6">size-6</h6>

                      </div>

                    </div>

                    <div class="box-[66-66-100]">

                      <div class="grid-y autoset" style="height:100%;">

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-3">Lorem ipsum</h4>
                            <p class="font-size-7">Size-7 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-5">Lorem ipsum</h4>
                            <p class="font-size-8">Size-8 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-20">
                          <div class="text-group">
                            <h4 class="font-size-7">Lorem ipsum</h4>
                            <p class="font-size-9">Size-9 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                      </div>

                    </div>

                    <div class="box-[100-100-100]">
                      <div class="space-30"></div>
                      <div class="grid-x gap-20">
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-expanded">
                            <b>EXPANDED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                          </p>
                        </div>
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-condensed">
                            <b>CONDENSED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

                <div class="bkg-tone-2 font-tone-5 space-20">

                  <p>Typography: tone-2 / tone-5</p>

                  <div class="space-05"></div>

                  <div class="grid-x gap-20">

                    <div class="box-[33-33-100]">

                      <div class="text-group">

                        <h1 class="font-size-1">size-1</h1>
                        <h2 class="font-size-2">size-2</h2>
                        <h3 class="font-size-3">size-3</h3>
                        <h4 class="font-size-4">size-4</h4>
                        <h5 class="font-size-5">size-5</h5>
                        <h6 class="font-size-6">size-6</h6>

                      </div>

                    </div>

                    <div class="box-[66-66-100]">

                      <div class="grid-y autoset" style="height:100%;">

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-3">Lorem ipsum</h4>
                            <p class="font-size-7">Size-7 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-5">Lorem ipsum</h4>
                            <p class="font-size-8">Size-8 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-20">
                          <div class="text-group">
                            <h4 class="font-size-7">Lorem ipsum</h4>
                            <p class="font-size-9">Size-9 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                      </div>

                    </div>

                    <div class="box-[100-100-100]">
                      <div class="space-30"></div>
                      <div class="grid-x gap-20">
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-expanded">
                            <b>EXPANDED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                          </p>
                        </div>
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-condensed">
                            <b>CONDENSED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

                <div class="bkg-tone-1 font-tone-4 space-20">

                  <p>Typography: tone-1 / tone-4</p>

                  <div class="space-05"></div>

                  <div class="grid-x gap-20">

                    <div class="box-[33-33-100]">

                      <div class="text-group">

                        <h1 class="font-size-1">size-1</h1>
                        <h2 class="font-size-2">size-2</h2>
                        <h3 class="font-size-3">size-3</h3>
                        <h4 class="font-size-4">size-4</h4>
                        <h5 class="font-size-5">size-5</h5>
                        <h6 class="font-size-6">size-6</h6>

                      </div>

                    </div>

                    <div class="box-[66-66-100]">

                      <div class="grid-y autoset" style="height:100%;">

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-3">Lorem ipsum</h4>
                            <p class="font-size-7">Size-7 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-5">Lorem ipsum</h4>
                            <p class="font-size-8">Size-8 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-20">
                          <div class="text-group">
                            <h4 class="font-size-7">Lorem ipsum</h4>
                            <p class="font-size-9">Size-9 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                      </div>

                    </div>

                    <div class="box-[100-100-100]">
                      <div class="space-30"></div>
                      <div class="grid-x gap-20">
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-expanded">
                            <b>EXPANDED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                          </p>
                        </div>
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-condensed">
                            <b>CONDENSED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

              </div>

              <div>

                <div class="bkg-tone-4 font-tone-1 space-20">

                  <p>Typography: tone-4 / tone-1</p>

                  <div class="space-05"></div>

                  <div class="grid-x gap-20">

                    <div class="box-[33-33-100]">

                      <div class="text-group">

                        <h1 class="font-size-1">size-1</h1>
                        <h2 class="font-size-2">size-2</h2>
                        <h3 class="font-size-3">size-3</h3>
                        <h4 class="font-size-4">size-4</h4>
                        <h5 class="font-size-5">size-5</h5>
                        <h6 class="font-size-6">size-6</h6>

                      </div>

                    </div>

                    <div class="box-[66-66-100]">

                      <div class="grid-y autoset" style="height:100%;">

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-3">Lorem ipsum</h4>
                            <p class="font-size-7">Size-7 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-5">Lorem ipsum</h4>
                            <p class="font-size-8">Size-8 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-20">
                          <div class="text-group">
                            <h4 class="font-size-7">Lorem ipsum</h4>
                            <p class="font-size-9">Size-9 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                      </div>

                    </div>

                    <div class="box-[100-100-100]">
                      <div class="space-30"></div>
                      <div class="grid-x gap-20">
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-expanded">
                            <b>EXPANDED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                          </p>
                        </div>
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-condensed">
                            <b>CONDENSED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

                <div class="bkg-tone-5 font-tone-2 space-20">

                  <p>Typography: tone-5 / tone-2</p>

                  <div class="space-05"></div>

                  <div class="grid-x gap-20">

                    <div class="box-[33-33-100]">

                      <div class="text-group">

                        <h1 class="font-size-1">size-1</h1>
                        <h2 class="font-size-2">size-2</h2>
                        <h3 class="font-size-3">size-3</h3>
                        <h4 class="font-size-4">size-4</h4>
                        <h5 class="font-size-5">size-5</h5>
                        <h6 class="font-size-6">size-6</h6>

                      </div>

                    </div>

                    <div class="box-[66-66-100]">

                      <div class="grid-y autoset" style="height:100%;">

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-3">Lorem ipsum</h4>
                            <p class="font-size-7">Size-7 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-5">Lorem ipsum</h4>
                            <p class="font-size-8">Size-8 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-20">
                          <div class="text-group">
                            <h4 class="font-size-7">Lorem ipsum</h4>
                            <p class="font-size-9">Size-9 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                      </div>

                    </div>

                    <div class="box-[100-100-100]">
                      <div class="space-30"></div>
                      <div class="grid-x gap-20">
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-expanded">
                            <b>EXPANDED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                          </p>
                        </div>
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-condensed">
                            <b>CONDENSED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

                <div class="bkg-tone-6 font-tone-3 space-20">

                  <p>Typography: tone-6 / tone-3</p>

                  <div class="space-05"></div>

                  <div class="grid-x gap-20">

                    <div class="box-[33-33-100]">

                      <div class="text-group">

                        <h1 class="font-size-1">size-1</h1>
                        <h2 class="font-size-2">size-2</h2>
                        <h3 class="font-size-3">size-3</h3>
                        <h4 class="font-size-4">size-4</h4>
                        <h5 class="font-size-5">size-5</h5>
                        <h6 class="font-size-6">size-6</h6>

                      </div>

                    </div>

                    <div class="box-[66-66-100]">

                      <div class="grid-y autoset" style="height:100%;">

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-3">Lorem ipsum</h4>
                            <p class="font-size-7">Size-7 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-40">
                          <div class="text-group">
                            <h4 class="font-size-5">Lorem ipsum</h4>
                            <p class="font-size-8">Size-8 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                        <div class="box-20">
                          <div class="text-group">
                            <h4 class="font-size-7">Lorem ipsum</h4>
                            <p class="font-size-9">Size-9 Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur....</p>
                          </div>
                        </div>

                      </div>

                    </div>

                    <div class="box-[100-100-100]">
                      <div class="space-30"></div>
                      <div class="grid-x gap-20">
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-expanded">
                            <b>EXPANDED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                          </p>
                        </div>
                        <div class="box-[50-50-50]">
                          <p class="font-size-8-condensed">
                            <b>CONDENSED</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

              </div>

              <div class="active">

                <div class="grid-x autoset">

                  <div class="box-[100-100-100]"></div>

                  <div class="box-[11-11-33]">
                    <div class="bkg-tone-1 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-1 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-1 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-2 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-2 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-2 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-3 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-3 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-3 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>

                  <div class="box-[100-100-100]"></div>

                  <div class="box-[11-11-33]">
                    <div class="bkg-tone-4 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-4 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-4 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-5 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-5 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-5 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-6 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-6 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-tone-6 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>

                  <div class="box-[100-100-100]"></div>

                  <div class="box-[11-11-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-color-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-color-2-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-color-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>

                  <div class="box-[100-100-100]"></div>

                  <div class="box-[11-11-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-tone-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-tone-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-tone-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-tone-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-tone-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-tone-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-tone-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-tone-1-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-tone-3-size-8 align-center">Lorem</p>
                    </div>
                  </div>

                  <div class="box-[100-100-100]"></div>

                  <div class="box-[11-11-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-tone-4-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-tone-4-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-1 space-[20-15-05]">
                      <p class="font-tone-4-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-tone-4-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-tone-4-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-2 space-[20-15-05]">
                      <p class="font-tone-4-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-tone-4-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-tone-4-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                  <div class="box-[auto-auto-33]">
                    <div class="bkg-color-3 space-[20-15-05]">
                      <p class="font-tone-6-size-8 align-center">Lorem</p>
                    </div>
                  </div>
                </div>

              </div>

              <div>

                  <div class="bkg-tone-5 space-20">

                    <div class="text-group font-tone-2 align-justify">

                      <h3>TEXT P + FLOATTED BLOCKQUOTE</h3>

                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id accumsan eros. Cras convallis tempor arcu, a auctor elit vulputate non. Praesent at turpis sit amet diam tristique porttitor. Duis aliquet ante augue, eu efficitur libero placerat sit amet. Sed mattis magna sit amet lacinia volutpat. Quisque massa orci, molestie imperdiet mattis at, cursus eget nulla. Integer ac congue dui.
                      </p>
                      <blockquote class="float-right" style="width:300px; margin-left:20px;">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </blockquote>
                      <p>
                        Donec malesuada, tellus at ultrices tincidunt, leo lectus interdum ipsum, a laoreet dui nunc vel risus. Ut aliquet ipsum sed mi pretium, ac sodales leo imperdiet. Vestibulum molestie nibh a erat efficitur rutrum. Vestibulum elementum eros id sagittis dapibus. Etiam ultrices eu est id rhoncus. Phasellus quis elit lorem. Aliquam eget tortor dignissim, fermentum sapien vel, fringilla est. Nullam lacinia placerat nunc, eget semper nunc eleifend id. Mauris sem nisl, lobortis quis fringilla id, <a>imperdiet in libero</a>. Proin lectus dolor, lacinia vitae tincidunt elementum, molestie at tellus. Donec et neque dolor. Duis bibendum nunc ut elit sodales, et scelerisque sem tincidunt. In hac habitasse platea dictumst. Cras imperdiet lorem quis consectetur ultricies.
                      </p>
                      <p>
                        Morbi nisl nisi, porta eget convallis eu, pharetra quis urna. Maecenas luctus lorem sit amet ligula feugiat hendrerit. Pellentesque lacinia efficitur dolor, vitae fermentum libero. Aliquam porta urna ac nibh tempus convallis. Maecenas blandit id erat nec tristique. Ut nec tortor arcu. Etiam vestibulum pulvinar eros nec fermentum. Donec convallis pharetra erat. Proin congue diam eu diam euismod, id placerat dolor vulputate. Sed eleifend orci nec ante pulvinar, ut egestas turpis molestie. Maecenas neque dui, aliquet in quam sit amet, egestas hendrerit nisi. Maecenas risus orci, venenatis ut commodo ut, imperdiet ac nulla.
                      </p>

                    </div>

                  </div>

                  <div class="bkg-tone-2 space-20">

                    <div class="text-group font-tone-5 align-justify">

                      <h3>TEXT P + FLOATTED BLOCKQUOTE</h3>

                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id accumsan eros. Cras convallis tempor arcu, a auctor elit vulputate non. Praesent at turpis sit amet diam tristique porttitor. Duis aliquet ante augue, eu efficitur libero placerat sit amet. Sed mattis magna sit amet lacinia volutpat. Quisque massa orci, molestie imperdiet mattis at, cursus eget nulla. Integer ac congue dui.
                      </p>
                      <blockquote class="float-right" style="width:300px; margin-left:20px;">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </blockquote>
                      <p>
                        Donec malesuada, tellus at ultrices tincidunt, leo lectus interdum ipsum, a laoreet dui nunc vel risus. Ut aliquet ipsum sed mi pretium, ac sodales leo imperdiet. Vestibulum molestie nibh a erat efficitur rutrum. Vestibulum elementum eros id sagittis dapibus. Etiam ultrices eu est id rhoncus. Phasellus quis elit lorem. Aliquam eget tortor dignissim, fermentum sapien vel, fringilla est. Nullam lacinia placerat nunc, eget semper nunc eleifend id. Mauris sem nisl, lobortis quis fringilla id, <a>imperdiet in libero</a>. Proin lectus dolor, lacinia vitae tincidunt elementum, molestie at tellus. Donec et neque dolor. Duis bibendum nunc ut elit sodales, et scelerisque sem tincidunt. In hac habitasse platea dictumst. Cras imperdiet lorem quis consectetur ultricies.
                      </p>
                      <p>
                        Morbi nisl nisi, porta eget convallis eu, pharetra quis urna. Maecenas luctus lorem sit amet ligula feugiat hendrerit. Pellentesque lacinia efficitur dolor, vitae fermentum libero. Aliquam porta urna ac nibh tempus convallis. Maecenas blandit id erat nec tristique. Ut nec tortor arcu. Etiam vestibulum pulvinar eros nec fermentum. Donec convallis pharetra erat. Proin congue diam eu diam euismod, id placerat dolor vulputate. Sed eleifend orci nec ante pulvinar, ut egestas turpis molestie. Maecenas neque dui, aliquet in quam sit amet, egestas hendrerit nisi. Maecenas risus orci, venenatis ut commodo ut, imperdiet ac nulla.
                      </p>

                    </div>

                  </div>

              </div>

            </div>

          </div>
          <div class="box-[25-25-100]">
            <div class="tabs-y">

               <div class="space-20">
                   <p> tab 1 </p> <a class="close"></a>
               </div>
               <div>
                 <div class="bkg-tone-6 space-30">
                   <p class="font-color-1-size-6">
                     Simple test
                   <p>
                    <div class="space-05"></div>
                   <p class="font-color-1-size-8">
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                   </p>
                 </div>
               </div>

               <div class="space-20">
                   <p> tab 2 </p> <a class="close"></a>
               </div>
               <div>
                 <div class="bkg-tone-2 space-30">
                   <p class="font-color-3-size-6">
                     Simple test
                   <p>
                    <div class="space-05"></div>
                   <p class="font-tone-4-size-8">
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                   </p>
                 </div>
               </div>

               <div class="space-20">
                   <p> tab 3 </p> <a class="close"></a>
               </div>
               <div>
                 <div class="bkg-color-1 space-30">
                   <p class="font-tone-4-size-6">
                     Simple test
                   <p>
                    <div class="space-05"></div>
                   <p class="font-tone-4-size-8">
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                   </p>
                 </div>
               </div>

            </div>
            
          </div>
        </div>

      </span>

      <span class="space-[100-50-15]" style="min-width:1200px;">

        <p> Table - Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/API-::-CLASSES#-checksize">Reference -> checksize</a></p>
        <p> A standard, presetted, stylizable table. All tables can scroll under mobile and/or if their min-width is over the screen size... automatically. </p>
        
        <div class="space-05"></div>

        <table>
          <thead>
            <tr>
              <th>Company</th>
              <th>Contact</th>
              <th>Country</th>
            </tr>
          <thead>

          <tbody>
            <tr>
              <td>Alfreds Futterkiste</td>
              <td>Maria Anders</td>
              <td>Germany</td>
            </tr>
            <tr>
              <td>Centro comercial Moctezuma</td>
              <td>Francisco Chang</td>
              <td>Mexico</td>
            </tr>
            <tr>
              <td>Ernst Handel</td>
              <td>Roland Mendel</td>
              <td>Austria</td>
            </tr>
            <tr>
              <td>Island Trading</td>
              <td>Helen Bennett</td>
              <td>UK</td>
            </tr>
            <tr>
              <td>Laughing Bacchus Winecellars</td>
              <td>Yoshi Tannamuri</td>
              <td>Canada</td>
            </tr>
            <tr>
              <td>Magazzini Alimentari Riuniti</td>
              <td>Giovanni Rovelli</td>
              <td>Italy</td>
            </tr>
          </tbody>

          <tfoot>
            <tr>
              <td colspan="3">
                Simple note
              </td>
            </tr>
          </tfoot>

        </table>

      </span>

      <span class="space-[100-50-15]" style="min-width:1200px;">

        <p> Spoiler - Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/API-::-CLASSES#-spoiler">Reference -> spoiler</a></p>
        <p> A standard, presetted, stylizable alternative of details tag (we are trying to make the details fluid too. stay tuned.).</p>
        
        <div class="space-05"></div>

        <div class="grid-x gap-50">
      
          <div class="box-[25-25-100]">

            <div class="spoiler bkg-tone-2 font-color-2 radius-small">
              <div class="toggle off">
                <p class="toggle space-20">
                  <!--icon--> &nbsp;&nbsp;spoiler title
                </p>
              </div>
              <div>
                  <div class="text-group space-15">
                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                  </div>
              </div>
            </div>

          </div>

          <div class="box-[25-25-100]">

            <div class="spoiler bkg-tone-6 font-color-1 radius-small">
              <div>
                <p class="toggle off space-20">
                  <!--icon--> &nbsp;&nbsp;spoiler title
                </p>
              </div>
              <div>
                  <div class="text-group space-15">
                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                  </div>
              </div>
            </div>

          </div>

          <div class="box-[25-25-100]">

            <div class="spoiler bkg-tone-1 font-tone-5 radius-small">
              <div>
                <p class="toggle off space-20">
                  <!--icon--> &nbsp;&nbsp;spoiler title
                </p>
              </div>
              <div>
                  <div class="text-group space-15">
                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                  </div>
              </div>
            </div>

          </div>

          <div class="box-[25-25-100]">

            <div class="spoiler bkg-color-1 font-tone-4 radius-small">
              <div>
                <p class="toggle off space-20">
                  <!--icon--> &nbsp;&nbsp;spoiler title
                </p>
              </div>
              <div>
                  <div class="text-group space-15">
                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                  </div>
              </div>
            </div>
          </div>

        </div>

      </span>

      <span class="space-[100-50-15]" style="min-width:1200px;">

        <p> Snaps - Read more on: <a target="_blank" href="https://github.com/ShapeGroup/kimera-frontend-framework/wiki/API-::-CLASSES#-snap-">Reference -> snap</a></p>
        <p>Taken from the concept of the mode-app, these elements have everything you need to create a basic carousel, a google-style link list or any other system with draggable slide content.</p>

        <div class="space-05"></div>

        <div class="grid-x gap-20">

          <div class="box-[50-50-100]">

            <div style="max-width:600px; margin:0 auto;">

              <div class="snap-x mask autosnap-[3000] bkg-tone-2  radius-small" style="height:200px;">
  
                <div class="snaplabels-top bkg-tone-2 font-tone-6">
                  <a class="active">&nbsp;label-01&nbsp;</a>
                  <a>&nbsp;label-02&nbsp;</a>
                  <a>&nbsp;label-03&nbsp;</a>
                  <a>&nbsp;label-04&nbsp;</a>
                  <a>&nbsp;label-05&nbsp;</a>
                  <a>&nbsp;label-06&nbsp;</a>
                </div>
  
                <div class="snaptype-wide">
                  
                  <div class="snaps font-tone-6">
  
                    <div class="space-30  active">
                      <div style="margin: 0 30px; border: 1px solid #white;">
                        <p>
                          ...contents 01...
                        </p>
                      </div>
                    </div>
  
                    <div class="space-30">
                      <div style="margin: 0 30px; border: 1px solid #white;">
                        <p>
                          ...contents 02...
                        </p>
                      </div>
                    </div>
  
                    <div class="space-30">
                      <div style="margin: 0 30px; border: 1px solid #white;">
                        <p>
                          ...contents 03...
                        </p>
                      </div>
                    </div>
  
                    <div class="lock space-30">
                      <div style="margin: 0 30px; border: 1px solid #white;">
                        <p>
                          ...contents 04...
                        </p>
                      </div>
                    </div>
  
                    <div class="space-30">
                      <div style="margin: 0 30px; border: 1px solid #white;">
                        <p>
                          ...contents 05...
                        </p>
                      </div>
                    </div>
  
                    <div class="space-30">
                      <div style="margin: 0 30px; border: 1px solid #white;">
                        <p>
                          ...contents 06...
                        </p>
                      </div>
                    </div>
  
                  </div>
  
                </div>
  
                <div class="dots"></div>
  
                <a class="prev"> </a>
                <a class="next"> </a>
  
              </div>
              
            </div>

          </div>

          <div class="box-[50-50-100]">

            <div style="max-width:600px; margin:0 auto;">

              <div class="snap-x mask autosnap-[3000] font-color-2 radius-small" style="height:200px;">
  
                <div class="snaplabels-top-center">
                  <a class="space-10 font-color-2 radius-medium bkg-tone-5 active">&nbsp;label-01&nbsp;</a>
                  <a class="space-10 font-color-2 radius-medium bkg-tone-5">&nbsp;label-02&nbsp;</a>
                  <a class="space-10 font-color-2 radius-medium bkg-tone-5">&nbsp;label-03&nbsp;</a>
                  <a class="space-10 font-color-2 radius-medium bkg-tone-5">&nbsp;label-04&nbsp;</a>
                  <a class="space-10 font-color-2 radius-medium bkg-tone-5">&nbsp;label-05&nbsp;</a>
                  <a class="space-10 font-color-2 radius-medium bkg-tone-5">&nbsp;label-06&nbsp;</a>
                </div>
  
                <div class="snaptype-blocks">
                  
                  <div class="snaps">

                    <div class="space-10 active">
                      <div class="maxheight space-40 radius-big bkg-tone-4 font-tone-3">
                        <span style="width:200px;">
                          <p>
                            ...contents 01...
                          </p>
                        </span>
                      </div>
                    </div>

                    <div class="space-10">
                      <div class="maxheight space-40 radius-big bkg-tone-4 font-tone-3">
                        <span style="width:300px;">
                          <p>
                            ...contents 02...
                          </p>
                        </span>
                      </div>
                    </div>

                    <div class="space-10">
                      <div class="maxheight space-40 radius-big bkg-tone-4 font-tone-3">
                        <span style="width:140px;">
                          <p>
                            ...contents 03...
                          </p>
                        </span>
                      </div>
                    </div>

                    <div class="space-10">
                      <div class="maxheight space-40 radius-big bkg-tone-4 font-tone-3">
                        <span style="width:350px;">
                          <p>
                            ...contents 04...
                          </p>
                        </span>
                      </div>
                    </div>

                    <div class="space-10">
                      <div class="maxheight space-40 radius-big bkg-tone-4 font-tone-3">
                        <span style="width:150px;">
                          <p>
                            ...contents 05...
                          </p>
                        </span>
                      </div>
                    </div>

                    <div class="space-10">
                      <div class="maxheight space-40 radius-big bkg-tone-4 font-tone-3">
                        <span style="width:250px;">
                          <p>
                            ...contents 06...
                          </p>
                        </span>
                      </div>
                    </div>
  
                  </div>
  
                </div>
  
                <div class="dots"></div>
  
                <a class="prev"> </a>
                <a class="next"> </a>
  
              </div>

            </div>
            
          </div>

          <div class="box-[50-50-100]">

            <div style="max-width:600px; margin:0 auto;">

              <div class="snap-y mask autosnap-[3000] radius-small" style="height:200px;">
          
                <span class="bkg-tone-2" style="width:70px; position: absolute; z-index:2000;">
                  
                  <div class="snaplabels-left">
                    <a class="space-10 radius-small bkg-tone-4 font-color-1 active">label 01</a>
                    <a class="space-10 radius-small bkg-tone-4 font-color-1"> label 02 </a>
                    <a class="space-10 radius-small bkg-tone-4 font-color-1"> label 03 </a>
                    <a class="space-10 radius-small bkg-tone-4 font-color-1"> label 04 </a>
                    <a class="space-10 radius-small bkg-tone-4 font-color-1"> label 05 </a>
                    <a class="space-10 radius-small bkg-tone-4 font-color-1"> label 06 </a>
                  </div>
                
                </span>

                <div class="snaptype-wide">

                  <div class="snaps font-tone-6 ">
                    
                    <div class="space-100 bkg-tone-3 active">
                      <p>
                        ...contents 01...
                      </p>
                    </div>
                    
                    <div class="space-100 bkg-tone-3">
                      <p>
                        ...contents 02...
                      </p>
                    </div>
                    
                    <div class="space-100 bkg-tone-3">
                      <p>
                        ...contents 03...
                      </p>
                    </div>
                      
                    <div class="space-100 bkg-tone-3">
                      <p>
                        ...contents 04...
                      </p>
                    </div>
                    
                    <div class="space-100 bkg-tone-3">
                      <p>
                        ...contents 05...
                      </p>
                    </div>
                    
                    <div class="space-100 bkg-tone-3">
                      <p>
                        ...contents 06...
                      </p>
                    </div>

                  </div>

                </div>
                
                <div class="dots"></div>

                <a class="prev"> </a>
                <a class="next"> </a>
                
              </div>

              
            </div>
            
          </div>

          <div class="box-[50-50-100]">

            <div style="max-width:600px; margin:0 auto;">

              <div class="snap-y mask autosnap-[3000] radius-small" style="height:200px;">
          
                <div class="snaplabels-left-center">
                  <a class="space-10 radius-big bkg-tone-6 font-color-2 active">01</a>
                  <a class="space-10 radius-big bkg-tone-6 font-color-2"> 02 </a>
                  <a class="space-10 radius-big bkg-tone-6 font-color-2"> 03 </a>
                  <a class="space-10 radius-big bkg-tone-6 font-color-2"> 04 </a>
                  <a class="space-10 radius-big bkg-tone-6 font-color-2"> 05 </a>
                  <a class="space-10 radius-big bkg-tone-6 font-color-2"> 06 </a>
                </div>
                
                <div class="snaptype-blocks">

                  <div class="snaps">
                    
                    <div class="align-center space-30 bkg-color-2 font-tone-6 active">
                      <p>
                        ...contents 01...
                      </p>
                    </div>
                    
                    <div class="align-center space-30 bkg-tone-5">
                      <p>
                        ...contents 02...
                      </p>
                    </div>
                    
                    <div class="align-center space-30 bkg-tone-2">
                      <p>
                        ...contents 03...
                      </p>
                    </div>
                      
                    <div class="align-center space-30 bkg-color-2 font-tone-6">
                      <p>
                        ...contents 04...
                      </p>
                    </div>
                    
                    <div class="align-center space-30 bkg-tone-5">
                      <p>
                        ...contents 05...
                      </p>
                    </div>
                    
                    <div class="align-center space-30 bkg-tone-2">
                      <p>
                        ...contents 06...
                      </p>
                    </div>

                  </div>

                </div>
                
                <div class="dots"></div>

                <a class="prev"> </a>
                <a class="next"> </a>
                
              </div>
              
            </div>
            
          </div>

        </div>

      </span>

      <div style="position:fixed; top: 0; z-index:5000; padding:20px;">
        <p>
          <a target="_self" href="../k-tester/tester-y.php">return to standard scrollable version</a>
        </p>
      </div>

      <div class="loader active">
          <span class="spinner-box">
              <div class="standard-spinner"></div>
          </span>
      </div>

    </body>
</html>
