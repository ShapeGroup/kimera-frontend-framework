

/*
//	[ kimera framework V 2.5.1-12 ] [gapkit project beta 0.5.1 ]
//	Credits: Shape group - Alberto Marà & Shape group - All right reserved
//	https://github.com/ShapeGroup/kimera-frontend-framework/wiki
//	https://www.facebook.com/kimeraframework/
*/

////// Kimera

const k = ((ajaxstatus) => {


  console.time(':::: [ kimera framework V 2.5.1-12 ]\n:::: [ wikizone ] https://git.io/fhSzk\n:::: [ k-loader ] page time ')


 ////// eventDone

  let eventDone = (F) =>
  {
     var timer;
     return (event) =>
     {
       if(timer) clearTimeout(timer);
       timer = setTimeout(F,100,event);
     };
  }


  ////// touch check

  const is_touch_device = () =>
  {
    return 'ontouchstart' in window;
  }


  ////// Anti mobile bar

  const nomobar = () =>
  {

    if(document.documentElement.clientWidth <= 920) // fuck mobile browser bar!
    {
      document.querySelector('html').style.height = window.innerHeight + 'px';
      document.querySelector('body').style.height = window.innerHeight + 'px';
    }
    else
    {
      document.querySelector('html').style.height = '';
      document.querySelector('body').style.height = '';
    }

  }


  ////// loader

  const loaderstart = () =>
  {


      if ( ajaxstatus != true || ajaxstatus == undefined )
      {

        Loader = [...document.querySelectorAll('.loader')][0];
        Loader.style.transitionTime='';
        Loader.classList.add('active');

        window.onload = () =>
        {

          document.querySelectorAll('*[class*="viewport-"]')[0].style.opacity='1';

          Loader.classList.add('off');
          Loader.classList.remove('active');

          effectors();

          setTimeout(()=>{

            Loader.classList.remove('active', 'gpuboost');
            Loader.classList.replace('off','hide');

            console.timeEnd(':::: [ kimera framework V 2.5.1-12 ]\n:::: [ wikizone ] https://git.io/fhSzk\n:::: [ k-loader ] page time ')

          },500)

          return;

        }

      }


  }



  // Loader out

  const loaderout = () =>
  {

    let OutLinks = [...document.querySelectorAll('[target*="_self"], [target*="_top"], [target*="_inside]"')];

    let l = OutLinks.length;
    for (let i = 0; i < l; i++)
    {

      let Link = OutLinks[i];

      Link.onclick = event =>
      {

        event.preventDefault();

        let Loader = [...document.querySelectorAll('.loader')][0],
            destination = Link.getAttribute('href'),
            disabled = Link.getAttribute('disabled');

        Loader.querySelector('.spinner-box').classList.add('hide');
        Loader.classList.add('off');


        if(!disabled)
        {

          Loader.classList.remove('hide');


          setTimeout( () => {

            Loader.classList.add('gpuboost','active');
            Loader.classList.remove('off');

          }, 15); // after add gpuboost

          setTimeout( () => {

            if(destination==='#')
            {
              location.reload();
            }
            else
            {
              location.href=destination;
            }

          }, 270); // after loader fadein

        }

      }

    }

    return;

  }



  ////// viewport-app

  const viewportapp = () =>
  {


    // options

    let lockScroll  = false,
        draglimit   = parseInt((document.body.clientWidth/2.5)), // drag
        sensibility = 50; // swipe


    let AllViewportApp = [...document.querySelectorAll('.viewport-app')];

    let l = AllViewportApp.length;
    for (let i = 0; i < l; i++)
    {


      let   VPort = AllViewportApp[i];


      //set all controller elements

      let   Controller    = [...VPort.querySelectorAll('.view-controller')][0],
            ContentBox    = [...VPort.querySelectorAll('.view-group')][0],
            Section       = [...ContentBox.querySelectorAll('.view')],
            Pointers      = [...Controller.querySelectorAll('.pointer')],
            PrevView      = [...VPort.querySelectorAll('.prev-view')],
            NextView      = [...VPort.querySelectorAll('.next-view')],
            Dots          = VPort.querySelector('.dots'),
            Steps         = VPort.querySelector('.steps');


      if(Dots)
      {
        if(Dots.closest('.snap-x')||Dots.closest('.snap-y')){ Dots = null;}
      }

      //check controller elements

      let isPointed, isDots, isSteps;
      if(Pointers<=0) { isPointed=false } else { isPointed=true };
      if(!Dots) { isDots=false } else { isDots=true };
      if(!Steps) { isSteps=false } else { isSteps=true };



      ////// swipe actions

      let sectionsize = Section.length;
      for (let i = 0; i < sectionsize; i++)
      {


        ////// on first, find start viewbox by active

        if(Section[i].className.match('active'))
        {

          let start = i,
              StartPosition = Section[start].offsetLeft;

          if(isPointed)
          {
            Pointers[start].classList.add('active');
          }

          ContentBox.style.transform = 'translate('+StartPosition*-1+'px,0)';

        }



        /////// steps manager

        if( isSteps )
        {

          let StepSpan  = document.createElement('span');

          Steps.appendChild(StepSpan);

          StepSpan.classList.add('step');

          if(Section[i].className.match('active'))
          {
            let sai = i,
            steps = [...Steps.querySelectorAll('.step')];
            for (sai = 0; sai < steps.length; sai++)
            {
              steps[sai].classList.add("active");
            }
          }

        }



        /////// dots manager

        if( isDots )
        {

          let DotSpan  = document.createElement('span');

          Dots.appendChild(DotSpan);

          DotSpan.classList.add('dot');

          if(Section[i].className.match('active'))
          {
            DotSpan.classList.add('active');
          }

        }



        ////// controllers manager

        if( isPointed )
        {

          Pointers[i].onclick = event =>
          {


            //ContentBox.classList.remove('smooth'); //immidiatly! native app like.

            resetActiveClasses();

            Pointers[i].classList.add('active');
            Section[i].classList.add(/*'visible',*/'active');

            event.preventDefault(/*stop all return click.*/);


            //define relative panel offset

            let RelativePanel;

            if( i >= Pointers.length-1 )
            {

              let   SWidth = parseInt( window.getComputedStyle(Section[i]).width ),
              WWidth = parseInt( window.innerWidth),
              Offset = Section[i].offsetLeft;

              RelativePanel = parseInt( (Offset)-(WWidth-SWidth) );

            }

            else
            {

              RelativePanel = Section[i].offsetLeft;

            }


            updateSteps();
            updateDots();


            //go on panel


            // addSmooth();

            ContentBox.style.transform = 'translateX('+RelativePanel*-1+'px)';

            // removeSmooth();


          }

        }


        ////// content manager

        let EventTarget,
            PanelTarget,

            PrevPanel,
            NextPanel,
            PrevOffset,
            NextOffset,

            Zone,
            DragPosition,
            StartX, StartY,
            DistX, DistY, DragX, DragY,

            StartTouchPosition,
            StandardPosition,
            underScroll,

            StartTime;



        ContentBox.ontouchstart = event =>
        {

          //ContentBox.classList.remove("smooth"); /*immidiatly! native app like.*/

          //set target of actions

          PanelTarget = event.target.closest('.view');
          EventTarget = event.target;

          //you can drag?

          if(
              event.target.closest('.scroll-x') || event.target.closest('.scroll-y') ||
              event.target.closest('.snap-x') || event.target.closest('.snap-y') ||
              event.target.closest('.button-number') ||
              event.target.closest('.button-range *') ||
              event.target.className.match("nofx")
            )
          {
            PanelTarget.removeAttribute("draggable");
          }
          else
          {
            PanelTarget.setAttribute('draggable','true');
          }

          //set event starter variable

          Zone        = event.changedTouches[0],
          StartX      = Zone.pageX,
          StartY      = Zone.pageY,
          StartTime   = new Date(),

          StartTouchPosition =  parseInt( Zone.clientX ),
          PrevPanel = PanelTarget.previousElementSibling,
          NextPanel = PanelTarget.nextElementSibling,

          underScroll = false;

          //check who is the active

          if(!PanelTarget.className.match('active'))
          {
            resetActiveClasses();
            PanelTarget.classList.add('active');
            updateController();
            updateSteps();
            updateDots();
          }


          // set previous elements

          if(PrevPanel)
          {
            PrevOffset  = parseInt( PanelTarget.previousElementSibling.offsetLeft*-1 )
          }

          else
          {
            PrevOffset = PanelTarget.offsetLeft
          }


          // set next elements

          if(NextPanel)
          {
            NextOffset  = parseInt( PanelTarget.nextElementSibling.offsetLeft*-1 )
          }

          else if(NextPanel === null)
          {
            NextOffset  = parseInt( PanelTarget.offsetLeft*-1 )
          }

          else if(NextPanel === null && (parseInt(NextPanel.nextElementSibling.offsetWidth) <  parseInt(ContentBox.offsetWidth)))
          {  //note: else is last and have a small width... recalculate final scroll by pre-last
            NextOffset  = parseInt( PanelTarget.offsetLeft*-1 );
          }


        }


        ContentBox.ontouchmove = event =>
        {


          //refresh starter variable on dragging

          Zone                 = event.changedTouches[0],
          StandardPosition     = PanelTarget.offsetLeft,
          DragPosition         = parseInt( ( (StandardPosition+StartTouchPosition) ) + (Zone.pageX*-1) ),
          DragY                = Zone.pageY-StartY,
          DragX                = StandardPosition-DragPosition;


          PanelTarget.onscroll = event =>
          {
            underScroll = true;
            return;
          }

          let X = Math.abs(DragX), Y = Math.abs(DragY);
          if(PanelTarget.hasAttribute('draggable') && X>Y)
          {

            if( DragX < 0 && !NextPanel || DragX > 0 && !PrevPanel)
            {
              DragX = 0;

              // addSmooth();

              ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
              PanelTarget.removeAttribute('draggable');

              // removeSmooth();
            }
            else if( DragX != 0 && !underScroll )
            {
              DragY = 0;
              ContentBox.style.transform = 'translate('+DragPosition*-1+'px,0)';
            }

          }
          else
          {

            DragX = 0;

            // addSmooth();

            ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
            PanelTarget.removeAttribute('draggable');

            // removeSmooth();

          }

        };


        ContentBox.ontouchend = event =>
        {


          //refresh starter variable on dragging

          Zone = event.changedTouches[0],
          StandardPosition = PanelTarget.offsetLeft,
          DistX = parseInt(Zone.pageX - StartX),
          DistY = parseInt(Zone.pageY - StartY)


          //Drag Release
          let X = Math.abs(DistX), Y = Math.abs(DistY);

          let Sensibility
          if(
              event.target.closest('.scroll-x') || event.target.closest('.scroll-y') ||
              event.target.closest('.snap-x') || event.target.closest('.snap-y') ||
              event.target.closest('.button-number') ||
              event.target.closest('.button-range *') ||
              event.target.className.match("nofx")
            )
          {
            Sensibility = 0;
            DistX = 0;
          }
          else
          {
            Sensibility = sensibility;
          }


          // let SwipeRangeY = DistY <= (Sensibility*2) && DistY >= -(Sensibility*2),
          //     stoptime = new Date() - StartTime;
          //     swipemin = parseInt( Sensibility*12/(Sensibility/4) );
          //     swipemax = parseInt( Sensibility*82/(Sensibility/4)  ),
          //     timerange = stoptime >= swipemin && stoptime <= swipemax;

          if(PanelTarget.hasAttribute('draggable'))
          {

            DistY = 0;
            DistX = DistX*-1;

            if( DistX > (draglimit) )
            // if( (DistX >= (draglimit/2) && timerange) || (DistX > draglimit))
            {
              goNext();
            }
            else if( DistX <= (-draglimit))
            // else if( (DistX <= -(draglimit/2)&& timerange) ||  (DistX < (-draglimit)))
            {
              goPrev();
            }
            else
            {
                // addSmooth();

                ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
                PanelTarget.removeAttribute('draggable');

                // removeSmooth();
            }

          }


          //stop all and fuckoff.
          PanelTarget.blur();
          underScroll = false;


        };


        ////// Next\Prev manager

        if( NextView )
        {

          let nvl = NextView.length;
          for (let n = 0; n < nvl; n++)
          {

            NextView[n].onclick = event =>
            {

              event.preventDefault();
              event.stopPropagation();


              let sl = Section.length;
              for (let i = 0; i < sl; i++)
              {

                let nextindex;
                if(Section[i].className.match('active'))
                {

                  nextindex = parseInt(i+1);
                  __next(nextindex);
                  return;
                }

                function __next(nextindex)
                {

                  if(Section[nextindex] === undefined) {  return; }

                  else(nextindex>=0 && nextindex<=Section.length)
                  {

                    let offset = Section[nextindex].offsetLeft;

                    resetActiveClasses();

                    // addSmooth();

                    ContentBox.style.transform = 'translate('+offset*-1+'px,0)';
                    Section[nextindex].classList.add("active");

                    // removeSmooth();

                    updateController();

                  }
                }


              }

            }

          }
        }
        else{ NextView = null; }

        if( PrevView )
        {

          let pvl = PrevView.length;
          for (let p = 0; p < pvl; p++)
          {

            PrevView[p].onclick = event =>
            {

              event.preventDefault();
              event.stopPropagation();


              let sl = Section.length;
              for (let i = 0; i < sl; i++)
              {


                let previndex;
                if(Section[i].className.match('active'))
                {

                  previndex = parseInt(i-1);
                  __prev(previndex);
                  return;
                }

                function __prev(previndex)
                {

                  if(Section[previndex] === undefined) {  return; }

                  else(previndex>=0 && previndex<=Section.length)
                  {

                    let offset = Section[previndex].offsetLeft;

                    resetActiveClasses();

                    // addSmooth();

                    ContentBox.style.transform = 'translate('+offset*-1+'px,0)';
                    Section[previndex].classList.add('active');

                    // removeSmooth();

                    updateController();

                  }
                };


              }

            }

          }
        }
        else{ PrevView = null; }



        ////// methods...


        let addSmooth = () =>
        {
          ContentBox.classList.add('smooth');
        }

        let removeSmooth = () =>
        {
          setTimeout(()=>{
            ContentBox.classList.remove('smooth');
          },600)
        }

        let resetActiveClasses = () =>
        {

          for (let p = 0; p < Pointers.length; p++)
          {
            Pointers[p].classList.remove('active');
          }

          for (let s = 0; s < Section.length; s++)
          {
            Section[s].classList.remove('active'/*,'hidden'*/);
          }

        }


        let updateDots = () =>
        {
          if( Dots )
          {

            let dot = [...Dots.querySelectorAll('.dot')];

            for (let i = 0; i < Section.length; i++)
            {

              if(Section[i].className.match('active'))
              {
                dot[i].classList.add('active');
              }
              else
              {
                dot[i].classList.remove('active');
              }

            }

          }

        }

        let updateSteps = () =>
        {

          if( Steps )
          {
            let step = [...Steps.querySelectorAll('.step')];

            for (let i = 0; i < step.length; i++)
            {
              step[i].classList.remove("active");
            }

            for (let i = 0; i < Section.length; i++)
            {

              if(Section[i].className.match('active'))
              {
                let filled = step.fill(0,1+i);
                for (let f = 0; f < 1+i; f++) {
                  filled[f].classList.add('active');
                }
              }
            }

          }

        }

        let updateController = () =>
        {

          for (let i = 0; i < Section.length; i++)
          {

            if(Section[i].className.match('active'))
            {
              if( isPointed ) { Pointers[i].classList.add('active'); }
              //Section[i].classList.replace('hidden','visible');

            }

            else
            {
              if( isPointed ) { Pointers[i].classList.remove('active'); }
            }

          }


        }

        let goNext = () =>
        {


          //addSmooth();

          PanelTarget.removeAttribute('draggable');
          PanelTarget.classList.remove('active');
          NextPanel.classList.add('active');


          // if(!NextPanel.nextElementSibling && (window.getComputedStyle(ContentBox).width > window.getComputedStyle(NextPanel).width))
          // {
          //   let   NEW = parseInt( window.getComputedStyle(NextPanel).width ),
          //         VCW = parseInt( window.innerWidth),
          //         NCO = NextPanel.offsetLeft,
          //
          //   LastPosition = parseInt( (NCO)-(VCW-NEW) );
          //
          //   //it's last and small!
          //   ContentBox.style.transform = 'translate('+(LastPosition*-1)+'px,0)';
          // }
          // else
          // {
            ContentBox.style.transform = 'translateX('+NextOffset+'px)';
          // }


          // removeSmooth();

          updateController();
          updateSteps();
          updateDots();


        }

        let goPrev = () =>
        {

          //addSmooth();

          PanelTarget.removeAttribute('draggable');

          PanelTarget.classList.remove('active');
          PrevPanel.classList.add('active');


          ContentBox.style.transform = 'translateX('+PrevOffset+'px)';

          // removeSmooth();

          updateController();
          updateSteps();
          updateDots();


        }



      }


    }

    return;

  }


  ////// outbox

  const outbox = () =>
  {

    //options

    let Viewport = document.querySelector('body>*[class*="viewport-"]'),
        RelOutbox = [...document.querySelectorAll('*[target^="outbox#"]')];


    let l = RelOutbox.length;
    for (let i = 0; i < l; i++)
    {

      RelOutbox[i].onclick = event =>
      {

          event.preventDefault();

          let target = RelOutbox[i].getAttribute('target').split('#')[1],
              OutBox = [...document.querySelectorAll('#'+target)][0],
              OutBoxType = OutBox.querySelector('div').className;

          // do open...

          OutBox.classList.add('gpuboost','active');

          if( OutBoxType.match('center') )
          { addViewTransition('center'); }

          else if( OutBoxType.match('top') )
          { addViewTransition('top'); }

          else if( OutBoxType.match('left') )
          { addViewTransition('left'); }

          else if( OutBoxType.match('right') )
          { addViewTransition('right'); }

          else if( OutBoxType.match('bottom') )
          { addViewTransition('bottom'); }


          OutBox.onclick = event =>
          {

              if(event.target.className.match('close') || event.target.className.match('accept') || event.target === OutBox)
              {

                OutBox.classList.add('off');
                OutBox.classList.remove('active');

                setTimeout( () => {
                  OutBox.classList.remove('off','active','gpuboost');
                },300)

                removedViewTransition(OutBox);

                return;
              }

          }

          return;
      }


    }

    let addViewTransition  = (side) =>
    {

      Viewport.classList.add('gpuboost','vfxtransition-in','vfx'+side);

    }

    let removedViewTransition  = (OutBox, side) =>
    {

      Viewport.classList.add('vfxtransition-out'),
      Viewport.classList.remove('vfxtransition-in','vfxtop','vfxleft','vfxbottom','vfxright','vfxcenter');

      setTimeout( () => {
        OutBox.classList.remove('off','active','gpuboost'),
        Viewport.classList.remove('vfxtransition-out','gpuboost');
      },500)

    }

    return;

  };



  ////// position absolute

  const absolute = () =>
  {

      var absolute = [...document.querySelectorAll('[class*="absolute-"]')];

      let l = absolute.length;
      for (let i = 0; i < l; i++)
      {
        if(!absolute[i].parentNode.className.match('outbox') || !absolute[i].parentNode.className.match('view'))
        {
          absolute[i].parentNode.style.position = 'relative';
        }
      }

      return;
  }



  ////// standard scroll manager

  const standardscroll = () =>
  {

    var ScrolledBox = [...document.querySelectorAll('.scroll-x, .scroll-y')];

    let l = ScrolledBox.length;
    for (let i = 0; i < l; i++)
    {

      let sensibility

      if( typeof InstallTrigger !== 'undefined' )//is firefox?
      {
        sensibility = 85;
      }
      else
      {
        sensibility = 2.5;
      }

      var onwhe = -1;
      ScrolledBox[i].onwheel = event =>
      {

        event.preventDefault();
        event.stopPropagation();
        ScrolledBox[i].focus();

        onwhe++
        if(onwhe >= 1)
        {


          let velocityofscrolling;

          if(onwhe<5)
          {
            velocityofscrolling = (onwhe/2);
          }
          else if(onwhe>5 && onwhe<8)
          {
            velocityofscrolling = (onwhe/2.5);
          }
          else {
            velocityofscrolling = (onwhe/3.5);
          }


          if(ScrolledBox[i].className.match('scroll-x'))
          {


            if(event.deltaY>0)
            {
              ScrolledBox[i].scrollLeft += velocityofscrolling*(sensibility*event.deltaY);
            }
            else if(event.deltaY<0)
            {
              ScrolledBox[i].scrollLeft -= (velocityofscrolling*(sensibility*event.deltaY))*-1;
            }
          }

          else if(ScrolledBox[i].className.match('scroll-y'))
          {


            if(event.deltaY>0)
            {
              ScrolledBox[i].scrollTop += velocityofscrolling*(sensibility*event.deltaY);

            }
            else if(event.deltaY<0)
            {
              ScrolledBox[i].scrollTop -= (velocityofscrolling*(sensibility*event.deltaY))*-1;
            }

          }

          setTimeout(()=>{
            return onwhe = 0;
          },150)

        }

      }

    }

    return;

  }



  ////// snap scroll manager

  const snapscroll = () =>
  {


    //
    // 1 set for start
    //


    (()=>{

        let AllSnaps = [...document.querySelectorAll('.snapgroup')];

        let l = AllSnaps.length;
        for (let i = 0; i < l; i++)
        {

          let Snapgroup = AllSnaps[i];

          let Firstofmask = [...Snapgroup.querySelectorAll('*:first-child')][0];
              Firstofmask.classList.add('active');


          if(Snapgroup.nextElementSibling && Snapgroup.nextElementSibling.className.match('dots'))
          {

              let GroupChilds = [...Snapgroup.querySelectorAll(".snapgroup>*")];

              let cl = GroupChilds.length;
              for (let i=0; i<cl; i++)
              {

                  let DotBox = GroupChilds[i].parentNode.nextElementSibling,
                      dot  = document.createElement('span');

                  DotBox.appendChild(dot);

                  dot.classList.add('dot');

                  let FirstDot = [...DotBox.querySelectorAll('.dot')][0];
                  FirstDot.classList.add("active");

              }

          }

        }

    })();


    //
    // 2 make dynamic
    //


    let Xsnap = [...document.querySelectorAll('.snap-x>.snapgroup')],
        Ysnap = [...document.querySelectorAll('.snap-y>.snapgroup')],
        Snap;

    let xl = Xsnap.length;
    for (let i = 0; i < xl; i++)
    {

        // auto snap

        if(Xsnap[i].parentNode.className.match('autosnap') )
        {
          let Slider = Xsnap[i];
          let timer = parseInt(Slider.parentNode.className.split('autosnap-[')[1].split(']')[0]);
          var autoslide = setInterval(()=>{ changeslide(Slider); }, timer);

          function changeslide(Slider)
          {

            let slidebox = [...Slider.querySelectorAll('.snapgroup>*')],
                sl = slidebox.length;

            for (let i = 0; i < sl; i++)
            {

              if(slidebox[i].className.match('active'))
              {
                if(!slidebox[i].nextElementSibling)
                {

                  slidebox[i].classList.remove('active');
                  slidebox[0].classList.add('active');


                  Slider.style.transform = 'translateX(-'+slidebox[0].offsetLeft+'px)';
                  updateDots (Slider,(i));

                }
                else
                {

                  Slider.style.transform = 'translateX(-'+( slidebox[i].nextElementSibling.offsetLeft)+'px)';
                  setTimeout(()=>{
                    slidebox[i].classList.remove('active');
                    slidebox[i].nextElementSibling.classList.add('active');
                    updateDots (Slider,(i+1));
                  },300)

                }

              }

            }
          }
        }


        // manual snap

        let startX,dirX,Active,ActiveIndex;

        if(is_touch_device())
        {
          Xsnap[i].ontouchstart = dragStart;
        }
        else
        {
          Xsnap[i].onmousedown = dragStart;
        }


        function dragStart (event)
        {

            event.preventDefault();
            event.stopPropagation();

            dirX = null;

            document.ontouchmove = dragMove;
            document.onmousemove = dragMove;

            if(is_touch_device())
            {
              startX = event.touches[0].clientX ;
            }
            else
            {
              startX = event.clientX ;
            }

        }


        function dragMove (event)
        {

          event.preventDefault();
          event.stopPropagation();

          document.ontouchend = dragEnd;
          document.onmouseup = dragEnd;

          Active = findActive(Xsnap[i]);

          if(is_touch_device())
          {
            dirX = event.touches[0].clientX-startX;
          }
          else
          {
            dirX = event.clientX-startX;
          }

          let position = Active.offsetLeft-dirX;
          if( dirX > 10 && Active.previousElementSibling )
          {
            Xsnap[i].style.transform = 'translateX(-'+(position)+'px)';
          }
          else if( dirX < -10 && Active.nextElementSibling )
          {
            Xsnap[i].style.transform = 'translateX(-'+(position)+'px)';
          }

          Xsnap[i].ontouchend = dragEnd
          Xsnap[i].onmouseup = dragEnd;
          return;

        }


        function dragEnd (event)
        {

          event.preventDefault();
          event.stopPropagation();


          if( dirX > 1 && Active.previousElementSibling )
          {
            goToPrev(Xsnap[i]);
          }
          else if( dirX < -1 && Active.nextElementSibling )
          {
            goToNext(Xsnap[i]);
          }
          else
          {
            setTimeout(()=>{
              Xsnap[i].style.transform = 'translateX(-'+(Active.offsetLeft)+'px)';
            },300)
          }


          document.ontouchmove = null;
          document.onmousemove = null;
          document.ontouchend = null;
          document.onmouseup = null;
          dirX = null;

          return;

        }


    }


    let yl = Ysnap.length;
    for (let i = 0; i < yl; i++)
    {


      // auto snap

      if(Ysnap[i].parentNode.className.match('autosnap') )
      {
        let Slider = Ysnap[i];
        let timer = parseInt(Slider.parentNode.className.split('autosnap-[')[1].split(']')[0]);
        var autoslide = setInterval(()=>{ changeslide(Slider); }, timer);

        function changeslide(Slider)
        {

          let slidebox = [...Slider.querySelectorAll('.snapgroup>*')],
              sl = slidebox.length;

          for (let i = 0; i < sl; i++)
          {

            if(slidebox[i].className.match('active'))
            {
              if(!slidebox[i].nextElementSibling)
              {

                slidebox[i].classList.remove('active');
                slidebox[0].classList.add('active');

                Slider.style.transform = 'translateY(-'+slidebox[0].offsetTop+'px)';
                updateDots (Slider,(i));

              }
              else
              {

                Slider.style.transform = 'translateY(-'+( slidebox[i].nextElementSibling.offsetTop)+'px)';
                setTimeout(()=>{
                  slidebox[i].classList.remove('active');
                  slidebox[i].nextElementSibling.classList.add('active');
                  updateDots (Slider,(i+1));
                },300)

              }

            }

          }
        }
      }


      // manual snap

      let startY,dirY,Active,ActiveIndex;

      if(is_touch_device())
      {
        Ysnap[i].ontouchstart = dragStart;
      }
      else
      {
        Ysnap[i].onmousedown = dragStart;
      }


      function dragStart (event)
      {

          event.preventDefault();
          event.stopPropagation();

          dirY = null;

          document.ontouchmove = dragMove;
          document.onmousemove = dragMove;

          if(is_touch_device())
          {
            startY = event.touches[0].clientY ;
          }
          else
          {
            startY = event.clientY ;
          }

          position = Active.offsetTop
      }


      function dragMove (event)
      {

        event.preventDefault();
        event.stopPropagation();

        document.ontouchend = dragEnd;
        document.onmouseup = dragEnd;

        Active = findActive(Ysnap[i]);

        if(is_touch_device())
        {
          dirY = event.touches[0].clientY-startY;
        }
        else
        {
          dirY = event.clientY-startY;
        }

        let position = Active.offsetTop-dirY;

        if( dirY > 10 && Active.previousElementSibling )
        {
          Ysnap[i].style.transform = 'translateY(-'+(position)+'px)';
        }
        else if( dirY < -10 && Active.nextElementSibling )
        {
          Ysnap[i].style.transform = 'translateY(-'+(position)+'px)';
        }


        Ysnap[i].ontouchend = dragEnd
        Ysnap[i].onmouseup = dragEnd;
        return;

      }


      function dragEnd (event)
      {

        event.preventDefault();
        event.stopPropagation();


        if( dirY > 1 && Active.previousElementSibling )
        {
          goToPrev(Ysnap[i]);
        }
        else if( dirY < -1 && Active.nextElementSibling )
        {
          goToNext(Ysnap[i]);
        }
        else
        {
          setTimeout(()=>{
            Ysnap[i].style.transform = 'translateY(-'+(Active.offsetTop)+'px)';
          },300)
        }

        document.ontouchmove = null;
        document.onmousemove = null;
        document.ontouchend = null;
        document.onmouseup = null;
        dirY = null;

        return;

      }


    }


    function findActive(Snap)
    {

      let Childs = [...Snap.querySelectorAll('*')],
          childslength = Childs.length;
      for (let i = 0; i < childslength; i++)
      {

        if(Childs[i].className.match('active'))
        {
          Active = Childs[i];
          ActiveIndex = Childs[i];
          return(Active,ActiveIndex)
        }

      }

    }

    function goToNext(Snap)
    {

      Active = findActive(Snap);

      if(Active.nextElementSibling)
      {

        let nextactive = Active.nextElementSibling,
            nextposLeft = parseInt( nextactive.offsetLeft ),
            nextposTop = parseInt( nextactive.offsetTop );

        Snap.style.transform = 'translate(-'+nextposLeft+'px, -'+nextposTop+'px)';

        nextactive.classList.add('active');
        Active.classList.remove('active');

        updateDots(Snap);
      }

      return;

    }

    function goToPrev(Snap)
    {

      Active = findActive(Snap);

      if(Active.previousElementSibling)
      {

        let prevactive = Active.previousElementSibling,
            prevposLeft = parseInt( prevactive.offsetLeft ),
            prevposTop = parseInt( prevactive.offsetTop );

        Snap.style.transform = 'translate(-'+prevposLeft+'px,-'+prevposTop+'px)';

        prevactive.classList.add('active');
        Active.classList.remove('active');

        updateDots(Snap);

      }

      return;

    }

    function updateDots (Snap,ActiveIndex)
    {

      if(Snap.nextElementSibling)
      {

        if(Snap.nextElementSibling.className.match('dots'))
        {

          //get\set active dot
          let Dots = [...Snap.nextElementSibling.querySelectorAll(".dot")],
              Childs = [...Snap.querySelectorAll('.snapgroup>*')];

          for (let i = 0; i < Childs.length; i++)
          {

            if(Childs[i].className.match('active'))
            {
              Dots[i].classList.add('active')
            }
            else
            {
              Dots[i].classList.remove('active')
            }

          }

        }


      }

    }

    return;

  }



  ////// snap scroll manager

  const autocrop = () =>
  {

    var Croppeds = [...document.querySelectorAll('*[class*="autocrop"]')]

    let l = Croppeds.length;
    for (let i = 0; i < l; i++)
    {

      if(Croppeds[i].style.height == undefined || !Croppeds[i].style.height)
      {
        let ph = String(Croppeds[i].parentNode.style.height)+"px";
        Croppeds[i].style.height = ph;
      }

    }

    return;

  }



  ////// flange

  const flange = () =>
  {


    var Flanges = [...document.querySelectorAll('*[class*="flange"]')]


    let l = Flanges.length;
    for (let i = 0; i < l; i++)
    {

        setTimeout(()=>{

          let Flange = Flanges[i],
              Nav = Flange.closest('NAV'),
              Trigger = Flange.parentNode,

              flangeoffs,navoffs,position,
              flangeheight,parentheight,
              flangewidth,parentWidth,
              isopen=false;


          Flange.parentElement.style.position = 'relative';

          setTimeout(()=>{
          if(Flange.className.match('flange-left') || Flange.className.match('flange-right'))
          {


              if(Flange.tagName == 'DIV') //equalize height
              {

                Flange.style.height = Nav.offsetHeight+'px';

                flangeoffs = (Flange.parentNode.offsetTop),
                navoffs = (Nav.offsetTop),
                positon = (navoffs-flangeoffs);

                Flange.style.top = positon+'px';

              }
              else //center it (by height)
              {

                Flange.style.top = 0;

                flangeheight = (Flange.offsetHeight)/2,
                parentheight = (Flange.parentNode.offsetHeight)/2,
                position = (flangeheight-parentheight)*-1;

                Flange.style.marginTop = position+'px';

              }

              if(Flange.className.match('flange-left'))
              {
                flangewidth = Flange.offsetWidth;
                Flange.style.marginLeft = (flangewidth*-1)+'px';
              }

          }

          if(Flange.className.match('flange-top') || Flange.className.match('flange-bottom'))
          {

            if(Flange.tagName == 'DIV') //equalize width
            {

              flangeoffs = parseInt(Flange.parentNode.offsetLeft),
              navoffs = parseInt(Nav.offsetLeft),
              position = navoffs-flangeoffs;

              Flange.style.left = position+'px';
              Flange.style.width = Nav.offsetWidth+'px';

            }
            else //center it (by width)
            {

              let flangewidth = parseInt(Flange.offsetWidth)/2,
                  parentWidth = parseInt(Flange.parentNode.offsetWidth)/2,
                  position = (flangewidth-parentWidth)*-1;

              Flange.style.left = position+'px';

            }


            if(Flange.className.match('flange-top'))
            {
                Flange.style.top = 0;
                flangeheight = (Flange.offsetHeight)*-1;
                Flange.style.marginTop = flangeheight+'px';
            }


            if(Flange.className.match('flange-bottom'))
            {
                Flange.style.top = 0;
                parentheight = (Flange.parentNode.offsetHeight);
                Flange.style.marginTop = (parentheight)+'px';
            }
          }

          //if not have animation motor... create a basic.
          if ( !Trigger.className.match('fx-') && !Flange.className.match('fx-') )
          {

            Trigger.addEventListener('click', event => {toggleFlange(event); }, true);
            Flange.addEventListener('mouseleave', event => {closeFlange(event); }, false);
            document.body.addEventListener('click', event => {

              if(!event.target.closest('NAV'))
              {
                closeFlange(event);
              }

              document.body.onclick = null;

            }, true);

          }

        },150)

        let toggleFlange = (event) =>
        {

          if( event.target.closest('li') && (event.target.tagName.toLowerCase() == 'a'  || event.target.closest('a')) )
          {
            if(!isopen)
            {

              for (let i = 0; i < Flanges.length; i++)
              {
                Flanges[i].classList.remove('active','off');
                Flanges[i].classList.add('off');
              }

              Flange.classList.add('active');
              Flange.classList.remove('off');
              Trigger.classList.add('active');
              Trigger.classList.remove('off');

              isopen = true;

            }

            else if (isopen)
            {

              Flange.classList.add('off');
              Flange.classList.remove('active');

              Trigger.classList.add('off');
              Trigger.classList.remove('active');

              isopen = false;
            }
          }

        }

        let closeFlange = (event) =>
        {

          Flange.classList.add('off');
          Flange.classList.remove('active');
          Trigger.classList.add('off');
          Trigger.classList.remove('active');

          setTimeout(()=>{
            Flange.classList.remove('off','active');
            Flange.previousElementSibling.classList.remove('off','active');
          },250)

          return isopen = false;
        }

      },200);

    }

    return;

  };



  ////// button

  const buttons = () =>
  {


      let Btncheck = [...document.querySelectorAll('input[type="checkbox"]')];

      if(Btncheck)
      {

        let l = Btncheck.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = Btncheck[i];
          Btn.onclick = event =>
          {

            if(Btn.checked===true){  Btn.setAttribute('checked',true)}
            else{  Btn.setAttribute('checked',false)}

            return;

          };

        }

      }



      let BtnRadio = [...document.querySelectorAll('input[type="radio"]')];

      if(BtnRadio)
      {

        let l = BtnRadio.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = BtnRadio[i];
          Btn.onclick = event =>
          {

              let name = Btn.getAttribute('name'),
                  ingroups = [...document.querySelectorAll('input[type="radio"][name="+name+"]')];

              let names = ingroups.length;
              for (let i = 0; i < names; i++)
              {
                ingroups[i].checked = false;
              }

              Btn.checked = true;


              return;

          };

        }
      }



      let BtnNumber = [...document.querySelectorAll('*[class*="button-number"]')]

      if(BtnNumber)
      {

        let l = BtnNumber.length;
        for (let i = 0; i < l; i++)
        {


          let Btn = BtnNumber[i];


          // get input values

          let Input = [...Btn.querySelectorAll('input[type="number"]')][0]
              val   = Input.getAttribute('value'),
              min   = Input.getAttribute('min'),
              max   = Input.getAttribute('max');


          //build the numbers into cage

          NumbersContainer = [...Btn.querySelectorAll('div:first-of-type')][0]
          let html_slide = document.createElement("SPAN");
          html_slide.classList.add('slide');
          NumbersContainer.appendChild(html_slide);
          NumbersContainer.classList.add('mask');

          for (let i = min; i <= max; i++)
          {

            let html_number = document.createElement('SPAN'); html_number.classList.add('number-['+i+']');
            let html_numval = document.createElement('SPAN'); html_numval.innerHTML = i;

            html_number.appendChild(html_numval);
            html_slide.appendChild(html_number);

          }


          // reget elem by class

          let Mask    =  [...Btn.querySelectorAll('.mask')][0],
              Slide   =  [...Btn.querySelectorAll('.slide')][0],
              Numbers =  [...Btn.querySelectorAll('[class*="number-"]')][0];


          //set active by input

          [...Slide.querySelectorAll('[class*="number-['+Input.value+']"]')][0].classList.add('active');


          //slide to start

          let Active = [...Slide.querySelectorAll('.slide>.active')][0],
              btnpad = parseInt( window.getComputedStyle(Btn, null).getPropertyValue('padding-left') ),
              maskcenter = parseInt( (Mask.offsetWidth-btnpad )/2 ),
              activeposition = parseInt((Active.offsetLeft-maskcenter)*-1);

          Slide.style.transform = 'translateX('+( activeposition )+'px)';

          glass();


          // on drag it

          Slide.ontouchstart = dragStart;
          Slide.onmousedown = dragStart;
          Slide.ontouchmove = dragMove;
          Slide.ontouchend = dragEnd;

          let startX, dirX;

          function dragStart(event)
          {

            let slideTransforms = Slide.style.transform,
                slideTranslateX = slideTransforms.replace(/[^\d.]/g, '');
                actualposition = slideTranslateX*-1;

            if (event.type === "touchstart")
            {
              startX = event.touches[0].clientX - actualposition;
              return;
            }
            else
            {
              event.preventDefault();
              startX = event.clientX - actualposition;
              document.onmousemove = dragMove;
              document.onmouseup = dragEnd;
              return;
            }


          }

          function dragMove(event)
          {

            event.preventDefault();

            if (event.type === "touchmove")
            {
              dirX = event.touches[0].clientX - startX;
            }
            else
            {
              dirX = event.clientX - startX;
            }

            Slide.style.transform = "translateX("+dirX+"px)";

            checkactive();
            return;


          }

          function dragEnd(event)
          {

            startX = dirX*-1;
            startvalueposition = startX*-1;
            document.onmouseup = null;
            document.onmousemove = null;


              let slideTransforms = Slide.style.transform,
                  slideTranslateX = slideTransforms.replace(/[^\d.]/g, ''),
                  actualposition = slideTranslateX*-1,

                  activepos = parseInt([...Slide.querySelectorAll('.slide > .active')][0].offsetLeft),

                  midpos = parseInt(Btn.offsetWidth/2),

                  correction =  (activepos+(btnpad/2)) ; //-maskcenter

              Slide.classList.add('smooth');
              Slide.style.transform = 'translateX('+( correction*-1 )+'px)';

              setTimeout(()=>{
                Slide.classList.remove('smooth');
              },150);


          }

          function checkactive(pushPrevious,pushNext,distX)
          {

            let
                //slide position
                slideTransforms = Slide.style.transform,
                slideTranslateX = slideTransforms.replace(/[^\d.]/g,''),
                sX = parseInt(slideTranslateX);
                if(sX>0) //>maskcenter
                {
                  actualposition = parseInt(sX); //+maskcenter
                }
                else {
                  actualposition = parseInt(sX+distX);
                }

                //aclual active position
                ActualActive = [...Slide.querySelectorAll('.slide > .active')][0],
                widthrange = parseInt(ActualActive.offsetWidth/1.5),
                activeposition = parseInt(ActualActive.offsetLeft),

                //all numbers
                numbs = [...Slide.querySelectorAll(".slide>span")],
                numbslength = numbs.length,
                I;

            if( (actualposition) > (activeposition+widthrange) )
            {

              ActualActive.nextElementSibling.classList.add('active');
              ActualActive.classList.remove('active');
              ActualActive = [...Slide.querySelectorAll('.slide > .active')][0];

              glass();

            }
            else if( (actualposition) < (activeposition-widthrange) )
            {

              ActualActive.previousElementSibling.classList.add('active');
              ActualActive.classList.remove('active');
              ActualActive = [...Slide.querySelectorAll('.slide > .active')][0];

              glass();

            }


          }


          // on click next/prev

          let Minus = [...Btn.querySelectorAll('A')][0],
              Plus  = [...Btn.querySelectorAll('A')][1];

          Minus.onclick = ()=>
          {

            let Now = [...Slide.querySelectorAll('.slide>.active')][0];

            Now.classList.remove('active');

            setTimeout(()=>{
              Now.previousElementSibling.classList.add('active');
            },20);

            setTimeout(()=>{

              let offset = parseInt([...Slide.querySelectorAll('.slide>.active')][0].offsetLeft),
                  nWidth = parseInt(Now.offsetWidth/2),
                  activeposition = parseInt((offset+nWidth)*-1); //-maskcenter


              Slide.classList.add('smooth');
              Slide.style.transform = 'translateX('+activeposition+'px)';
              setTimeout(()=>{
                Slide.classList.remove('smooth');
              },150);

              glass();

            },200);

          }

          Plus.onclick = ()=>
          {

            let Now = [...Slide.querySelectorAll('.slide>.active')][0];

            Now.classList.remove('active');

            setTimeout(()=>{
              Now.nextElementSibling.classList.add('active');
            },20);

            setTimeout(()=>{

              let offset = parseInt([...Slide.querySelectorAll('.slide>.active')][0].offsetLeft),
                  nWidth = parseInt(Now.offsetWidth/2),
                  activeposition = parseInt((offset+nWidth)*-1); //-maskcenter

              Slide.classList.add('smooth');
              Slide.style.transform = 'translateX('+activeposition+'px)';
              setTimeout(()=>{
                Slide.classList.remove('smooth');
              },150);

              glass();

            },200);

          }

          function glass()
          {

            let numbs = [...Slide.querySelectorAll('.slide>span')],
                numbslength = numbs.length;

            for(let i = 0; i < numbslength; i++)
            {

              numbs[i].style.opacity="0";

              if( numbs[i].className.match('active') )
              {

                I = parseInt(i);

                let htmlval = parseInt([...numbs[i].querySelectorAll('span')][0].innerHTML);
                Input.setAttribute('value',htmlval);

              }

              if(i == numbslength-1)
              {

                if(numbs[I-4]){numbs[I-4].style.opacity="0.03";}
                if(numbs[I-3]){numbs[I-3].style.opacity="0.1";}
                if(numbs[I-2]){numbs[I-2].style.opacity="0.3";}
                if(numbs[I-1]){numbs[I-1].style.opacity="0.6";}
                numbs[I].style.opacity="1";
                if(numbs[I+1]){numbs[I+1].style.opacity="0.6";}
                if(numbs[I+2]){numbs[I+2].style.opacity="0.3";}
                if(numbs[I+3]){numbs[I+3].style.opacity="0.1";}
                if(numbs[I+4]){numbs[I+4].style.opacity="0.03";}

              }

            }



          }


        }

      }



      let BtnFile = [...document.querySelectorAll('*[class*="button-file"]')]

      if(BtnFile)
      {

        let l = BtnFile.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = BtnFile[i];
          Btn.onchange = ()=>{


              //get subjects & values

              let Input   = [...Btn.querySelectorAll('input[type="file"]')][0],
                  Text    = [...Btn.querySelectorAll('P')][0],

                  maxqnt  = parseInt(Input.getAttribute("maxlength")),
                  minqnt  = parseInt(Input.getAttribute("minlength")),
                  filelimit = Input.getAttribute("size"),
                  totallimit   = Input.getAttribute("maxsize"),
                  accepted   = Input.getAttribute("accept"),
                  fileslength = Input.files.length;


              // check values //console.log("filelimit "+filelimit+"mb\ntotallimit "+totallimit+"mb\nfile: "+(Math.floor((Input.files[i].size/1000))/1024).toFixed(dot)+"mb");

              if(!minqnt){minqnt=0}

              if(minqnt)
              {
                 if(fileslength < minqnt)
                 {
                   Text.closest("[class*='button-file']").classList.add('border-error');
                   Text.innerHTML = ('&#x2716; | <b>quantity wrong: '+fileslength+' of min: '+minqnt+'</b></a>');
                   return;
                 }
              }

              if(maxqnt)
              {
                 if(fileslength > maxqnt)
                 {
                   Text.closest("[class*='button-file']").classList.add('border-error');
                   Text.innerHTML = ('&#x2716; | <b>quantity wrong: '+fileslength+' of max: '+maxqnt+'</b></a>');
                   return;
                 }
              }

              if(filelimit)
              {
                for (let i = 0; i < fileslength; i++)
                {
                  let megabyte = (Math.floor((Input.files[i].size/1000))/1024).toFixed(2);
                  if(megabyte>filelimit)
                  {
                    Text.closest("[class*='button-file']").classList.add('border-error');
                    Text.innerHTML = ('&#x2716; | <b>file overload: '+megabyte+'mb - max: '+filelimit+'mb</b></a>');
                    return;
                  }

                }
              }

              if(totallimit)
              {
                let total=0;
                for (let i = 0; i < fileslength; i++)
                {
                  let filesize = parseFloat( (Math.floor((Input.files[i].size/1000))/1024).toFixed(2) );
                  total += filesize;
                }

                if(total>totallimit)
                {
                  Text.closest("[class*='button-file']").classList.add('border-error');
                  Text.innerHTML = ('&#x2716; | <b>out of space: '+total+'mb - max: '+totallimit+'mb</b></a>');
                  return;
                }

              }

              if(accepted)
              {

                for (let i = 0; i < fileslength; i++)
                {

                  let file_extension = String( Input.files[i].name.match(/\.([^\.]+)$/)[1] );

                  let arrayofkeys = [...accepted.split(", ")].join(' '),
                      keys = arrayofkeys.split(' ');

                  for (let i = 0; i < file_extension.length; i++)
                  {

                    let key = String(keys[i]);

                    if(keys.indexOf(file_extension) === -1)
                    {
                      Text.closest("[class*='button-file']").classList.add('border-error');
                      Text.innerHTML = ('&#x2716; | <b>error: .'+file_extension+' files is not supported</b></a>');
                      return;
                    }

                  }


                }

              }


              //if check passed select the file

              Text.closest("[class*='button-file']").classList.remove('border-error');

              if(fileslength < 2)
              {
                  selected = String( Input.value.split('\\')[Input.value.split('\\').length - 1] );
                  //set it

                  Text.classList.add('active'),
                  Text.innerHTML = '&#x2714 | '+selected,
                  Input.setAttribute('value', Input.value);

                  setTimeout( () =>{
                    Text.classList.remove('active');
                  },150);

              }
              else
              {

                // make a viewer (outbox)

                //for all, generate a random id from 0 to 1000
                let FILELISTID = Math.floor(Math.random() * 999);

                //generate the empty output
                let fileviewer_empty_outbox =`
                <div class="outbox" id="filelist-`+FILELISTID+`">
                  <div class="side-center">

                      <div class="filelistbox">

                        <div>
                          <a class="close">
                            <p>File selected</p>
                          </a>
                        </div>

                        <div>
                          <!--<div class="hide-bar-y">-->
                            <div class="scroll-y">
                              <div class="filegroup grid-x">
                              </div>
                            </div>
                          <!--</div>-->
                        </div>

                      </div>

                  </div>
                </div>`;

                //print empty output & get it
                document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',fileviewer_empty_outbox);
                let Filegroup = document.getElementById("filelist-"+FILELISTID).querySelectorAll('.filegroup')[0];


                let filenames = [];
                for (let i=0; i<fileslength; i++)
                {
                  let filename = String( Input.files[i].name.split('.')[0] ),
                      filesize = String((Math.floor((Input.files[i].size/1000))/1024).toFixed(2)),
                      extens = String(Input.files[i].name.match(/\.([^\.]+)$/)[1]);

                  filenames.push('<div class="box-[50-50-50] align-left"><p class="ellipsis">'+filename+'</p></div> <div class="box-[20-20-20] align-center"><p>'+extens+'</p></div> <div class="box-[30-30-30] align-right"><p>'+filesize+'mb</p></div>')

                }

                //from array list to list of strings
                let fileslist = String(filenames.join(' '));
                Filegroup.innerHTML = fileslist;

                //update input & p & put inside
                Text.innerHTML = ('[ &#x2714 ] <b>'+fileslength+' files ready</b>&nbsp; <a target="outbox#filelist-'+FILELISTID+'">open list &#x2630</a>');
                Input.setAttribute('value', Input.value);
                Text.classList.add('active');
              }


          }

        }

      }



      let BtnRange = [...document.querySelectorAll('.button-range')];

      if(BtnRange)
      {

        let l = BtnRange.length;
        for (let i = 0; i < l; i++)
        {


            let Slider = [...BtnRange[i].querySelectorAll('.slider')][0],
                Rangeinputs = [...BtnRange[i].querySelectorAll('input')],
                Monitor = [...BtnRange[i].querySelectorAll('.monitor')][0];



            Monitor.classList.add("off");



            let rangelength = Rangeinputs.length;
            for (let i = 0; i < rangelength; i++)
            {



                let Range = Rangeinputs[i];



                let // start inputs values
                    min  = Number(Range.getAttribute('min')),
                    max  = Number(Range.getAttribute('max')),
                    val  = Number(Range.getAttribute('value')),
                    containerwidth = Math.round(Range.offsetWidth),
                    Bullet = [...Range.closest('.sliders').querySelectorAll('B')][i],
                    haveline;


                // get dot

                let dot, type = Range.getAttribute('type');
                if(type.match('float')) { dot = 2; } else { dot = 0; }



                //get steps (% and not)

                let matchpercent = ""+Range.step,
                    isPercent,
                    stepper;

                if(matchpercent.match('%'))
                {
                  isPercent = 1;
                  let stepstring = ""+Range.step,
                  stepsplit = stepstring.split('%')[0];
                  stepper = parseFloat(stepsplit);
                }
                else
                {
                  isPercent = 0;
                  stepper = parseFloat(Range.step);
                }



                //Dot on start position

                let presetdot = GetPercentage(min,max,val);
                Bullet.style.left = presetdot+"%";
                setLine();

                // on drag elements

                Bullet.ontouchstart = dragStart;
                Bullet.onmousedown = dragStart;
                Bullet.ontouchmove = dragMove;
                Bullet.ontouchend = dragEnd;


                let startX, dirX;


                function dragStart(event)
                {


                  let actualposition = Math.round(Bullet.offsetLeft);

                  if (event.type === "touchstart")
                  {

                    let touchX = (event.touches[0].clientX);
                        startX = (touchX - actualposition);

                  }
                  else
                  {

                    event.preventDefault();

                    let mouseX = (event.clientX);
                        startX =  (mouseX - actualposition);

                    document.onmousemove = dragMove;
                    document.onmouseup = dragEnd;

                  }


                }

                function dragMove(event)
                {


                  let prevBullet = [...Range.closest('.sliders').querySelectorAll('B')][i-1], prevElemPosition, prevPercentage;
                  if(prevBullet)
                  {
                    prevElemPosition = parseInt(prevBullet.offsetLeft),
                    prevPercentage = parseInt(GetPercentage(0,containerwidth,prevElemPosition));
                  }
                  else { prevPercentage=-1 }

                  let nextBullet = [...Range.closest('.sliders').querySelectorAll('B')][i+1],nextElemPosition,nextPercentage;
                  if(nextBullet)
                  {
                    nextElemPosition = parseInt(nextBullet.offsetLeft),
                    nextPercentage = parseInt(GetPercentage(0,containerwidth,nextElemPosition));
                  } else(nextPercentage=101)


                  event.preventDefault();


                  if (event.type === "touchmove") { dirX = (event.touches[0].clientX - startX); }
                  else                            { dirX = (event.clientX - startX); }


                  if (dirX > -1 && dirX < containerwidth+1)
                  {


                    let bulletpercent, newval;

                    if(!Range.step)
                    {

                      bulletpercent  = GetPercentage(0,containerwidth,dirX);
                      newval  = GetVal(min,max,bulletpercent);

                      if(bulletpercent > prevPercentage && bulletpercent < nextPercentage)
                      {
                        setdot(bulletpercent,newval);
                      }


                    }
                    else
                    {


                      if(isPercent)
                      {

                        let stepcut = Number( (containerwidth*stepper)/100 ).toFixed(dot); //is a step in px of container

                        let pass = -1;
                        for (let i = min; i < max; i++)
                        {

                          pass++;

                          let rangemid = (stepcut*pass);
                              rangemin = (rangemid)-(stepcut/2),
                              rangemax = (rangemid)+(stepcut/2)


                          if(dirX > rangemin && dirX < rangemax)
                          {

                            let actualstep = rangemin+(stepcut/2),
                                bulletpercent = GetPercentage(0,containerwidth,actualstep),
                                newval  = GetVal(min,max,bulletpercent);

                            if(bulletpercent > prevPercentage && bulletpercent < nextPercentage)
                            {
                              setdot(bulletpercent,newval);
                            }

                          }


                        }



                      }
                      else
                      {


                        bulletpercent  = GetPercentage(0,containerwidth,dirX);
                        newval  = GetVal(min,max,bulletpercent);


                        let pass = 0;
                        for (let i = min; i < max; i++)
                        {

                            pass++;
                            let valuepass = Number( ((min-stepper)+(stepper*pass)) );

                            if(valuepass > max) { return; }


                            let rangemin = (valuepass-(stepper/2))
                                rangemax = (valuepass+(stepper/2));

                            if(newval > rangemin && newval < rangemax)
                            {

                                Range.setAttribute('value', valuepass);
                                val = Range.value;

                                let newmax = max,
                                    newmin = min;

                                bulletpercent = GetPercentage(min,max,val)

                                if(bulletpercent > prevPercentage && bulletpercent < nextPercentage)
                                {
                                  setdot(bulletpercent,val);
                                }

                            }


                        }


                      }


                    }


                    function setdot(bulletpercent,newval,dot)
                    {


                      Bullet.style.left  = bulletpercent+"%";
                      Monitor.style.left = bulletpercent+"%";


                      if(dot<=0)
                      {
                        let roundval = Math.ceil(newval);
                        Monitor.innerHTML = '<p>'+roundval+'</p>';
                        Range.setAttribute('value', roundval);
                        val = Range.value;
                      }
                      else
                      {
                        Monitor.innerHTML = '<p>'+String(newval)+'</p>';
                        Range.setAttribute('value', newval);
                        val = Range.value;
                      }


                      Monitor.classList.add("active");
                      Monitor.classList.remove("off");

                    }


                    setLine();


                  }

                }

                function dragEnd(event)
                {

                  setTimeout(()=>{
                    Monitor.classList.add("off");
                    setTimeout(()=>{
                      Monitor.classList.remove("active");
                    },150)
                  },400)

                  document.onmouseup = null;
                  document.onmousemove = null;
                  return;

                }

                //sub functions...

                function GetPercentage(min,max,position)
                {
                    let percentval = Number( ((position-min)/(min-max)) * -100 ).toFixed(dot);
                    return percentval;
                }

                function GetVal(min,max,percent)
                {
                    let fromPerToVal = Number( ((min-max)*percent/100-min)*-1 ).toFixed(dot);
                    return fromPerToVal;
                }

                function setLine()
                {

                  let Lines = [...Range.closest('.sliders').querySelectorAll('input+span')],
                      lineslength = Lines.length;

                  for (let i = 0; i < lineslength; i++)
                  {

                    let prev = [...Range.closest('.sliders').querySelectorAll('B')][i-1], from,
                        actual = [...Range.closest('.sliders').querySelectorAll('B')][i], to;

                    if(prev){ from = GetPercentage(0,containerwidth,prev.offsetLeft); }
                    else { from = 0 }

                    to = GetPercentage(0,containerwidth,actual.offsetLeft);

                    let getStartPx = (GetVal(0,containerwidth,from)) ;
                        getFinishPx = (GetVal(0,containerwidth,to)) ;
                        widthDifference = getFinishPx-getStartPx;

                    Lines[i].style.width = widthDifference+"px";
                    Lines[i].style.left  = from+"%";

                  }

                  return;

                }

            }


        }
      }



      let BtnSelect = [...document.querySelectorAll('*[class*="button-select"]')];

      if(BtnSelect)
      {


        let l = BtnSelect.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = BtnSelect[i];

          //for all, generate a random id from 0 to 1000
          let SELECTID = Math.floor(Math.random() * 999);


          //set target of off canvas
          Btn.setAttribute('target','outbox#select-'+SELECTID);


          //generate the empty output
          let select_empty_outbox =`
          <div class="outbox" id="select-`+SELECTID+`">
            <div class="side-center">

                <div class="selectorbox">

                  <div>
            				<a class="close">
                      <p>Select your option</p>
                    </a>
                  </div>

                  <div>
                    <!--<div class="hide-bar-y">-->
                      <div class="scroll-y">
                        <div class="optiongroup">
                        </div>
                      </div>
                    <!--</div>-->
                  </div>

                </div>

            </div>
          </div>`;


          //print empty output & get it
          document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',select_empty_outbox);
          let Outbox = document.getElementById("select-"+SELECTID).querySelector('.optiongroup');


          //get options groups value...
          let Groups = [...Btn.querySelectorAll('OPTGROUP')];

          let l = Groups.length;
          for (let i = 0; i < l; i++)
          {

            let Group = Groups[i];

            let Labels = '<p>'+Group.getAttribute('label')+'</p>', //get all label
                Options = [...Group.querySelectorAll('option')];  //get all options


            // create a options list
            let optslist = [];
            let l = Options.length;
            for (let i = 0; i < l; i++)
            {
              optslist.push('<a data-option="'+Options[i].value+'">'+String(Options[i].value)+'</a>')
            }

            //from array list to list of strings
            let optionslist = String(optslist.join(' '));

            // print new output contents
            let output;
            if(Labels=="<p></p>")
            {
              output =
              `
              <div class="nolabel hide"></div>
              <div class="options">
                `+optionslist+`
              </div>`;
            }
            else
            {
              output =
              `<div class="label">
               `+Labels+`
              </div>
              <div class="options">
                `+optionslist+`
              </div>`;
            }


            Outbox.insertAdjacentHTML('beforeEnd',output);


          }


          // "now, do..."

          //on click into voice of relative select popup
          let AllVoice = [...Outbox.querySelectorAll('.options a')];
          let v = AllVoice.length;
          for (let i = 0; i < v; i++)
          {
            let Voice = AllVoice[i];

            Voice.addEventListener('click', () =>
            {

              //update active
              for (let i = 0; i < v; i++)
              {
                AllVoice[i].classList.remove("active");
              }

              Voice.classList.add("active");

              //get relative value
              let val = Voice.getAttribute("data-option");

              //get relative select
              let RelSel =  document.querySelectorAll('.button-select[target="outbox#select-'+SELECTID+'"]>select')[0];
              RelSel.previousElementSibling.innerHTML = val;
              RelSel.setAttribute("value",""+val);

            },true);

          }

        }


      }



      let BtnTime = [...document.querySelectorAll('*[class*="button-time"]')];

      if(BtnTime)
      {


        let l = BtnTime.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = BtnTime[i];

          //for all, generate a random id from 0 to 1000
          let TIMEPICKERID = Math.floor(Math.random() * 999);


          //set target of off canvas
          Btn.setAttribute('target','outbox#times-'+TIMEPICKERID);


          //generate the empty output
          let select_empty_outbox =`
          <div class="outbox" id="times-`+TIMEPICKERID+`">
            <div class="side-center">

                <div class="timebox">

                  <div>
                    <a class="close">
                      <p>Day time</p>
                    </a>
                  </div>

                  <div>

                    <span>

                      <div class="clock">

                        <div class="display">
                          <div>
                            <div>
                              <span class="hours"><p>12</p></span>
                              <span class="doubledot"><p>:</p></span>
                              <span class="minutes"><p>15</p></span>
                            </div>
                            <div>
                              <span class="am active"><p>AM</p></span>
                              <span class="pm off"><p>PM</p></span>
                            </div>
                          </div>
                        </div>

                        <div class="rayline-hours">
                        </div>

                        <div class="rayline-minutes">
                        </div>

                      </div>

                    </span>

                  </div>

                  <div>
                    <div class="button align-center">
                      <a class="accept">OK - CLOSE</a>
                    </div>
                  </div>

                </div>

            </div>
          </div>`;


          //print empty output & get it

          document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',select_empty_outbox);
          let Outbox = document.getElementById("times-"+TIMEPICKERID);




          let // get elems of clock

              Am = [...Outbox.querySelectorAll('.am')][0],
              Pm = [...Outbox.querySelectorAll('.pm')][0],

              Hours = [...Outbox.querySelectorAll('.hours>p')][0]
              Minutes = [...Outbox.querySelectorAll('.minutes>p')][0],

              Clock = [...Outbox.querySelectorAll('.clock')][0],
      				RayHours   = [...Outbox.querySelectorAll('.rayline-hours')][0],
      				RayMinutes   = [...Outbox.querySelectorAll('.rayline-minutes')][0],

              Accept = [...Outbox.querySelectorAll('a.accept')][0];



          // set Am or Pm

          Am.onclick = () =>
          {

            if(!Am.className.match('active'))
            {

              Am.classList.add('active'),
              Am.classList.remove('off'),
              Pm.classList.add('off'),
              Pm.classList.remove('active');


              let hours = parseInt(Hours.innerHTML);

              if(hours == 00)              { hours = "12"}
              if(hours>12)
              {
                if(hours <= 22)         { hours = "0"+(hours-12)}
                else if(hours > 22)         { hours = (hours-12)}
              }

              Hours.innerHTML = (""+hours);

            }

          }

          Pm.onclick = () =>
          {

            if(!Pm.className.match('active'))
            {
              Am.classList.add('off'),
              Am.classList.remove('active'),
              Pm.classList.add('active'),
              Pm.classList.remove('off');

              let hours = parseInt(Hours.innerHTML);

              if(hours == 12) { hours = "00"}
              else            { hours = hours+12; }

              Hours.innerHTML = (""+hours);
            }

          }



          // set start angle

          let startHoursangle = Math.atan2(-90,0) * 180 / Math.PI;
          RayHours.style.transform = 'rotate('+startHoursangle+'deg)' ;
          let startMinutesangle = Math.atan2(0,15) * 180 / Math.PI;
          RayMinutes.style.transform = 'rotate('+startMinutesangle+'deg)' ;


          //start moving

          if(is_touch_device())
          {
            RayHours.ontouchstart = clockStart;
            RayHours.ontouchend = clockStop;
            RayMinutes.ontouchstart = clockStart;
            RayMinutes.ontouchend = clockStop;

          }
          else
          {
            RayHours.onmousedown = clockStart;
            RayMinutes.onmousedown = clockStart;
          }


          let center;
          let isHours, isMinutes;


          function clockStart(event)
          {


            event.preventDefault();
            event.stopPropagation();

            let rect = Clock.getBoundingClientRect();
            center = {
                  x: rect.left + rect.width / 2,
                  y: rect.top + rect.height / 2
                };

            if(event.target == RayHours)
            {
              isHours = true;
              isMinutes = false;
            }
            else if(event.target == RayMinutes)
            {
              isHours = false;
              isMinutes = true;
            }

            if(is_touch_device()) { document.ontouchmove = clockMove; }
            else { document.onmousemove = clockMove; }

  				};

  				function clockMove(event)
          {

            let deltaX, deltaY, angle;

            if(is_touch_device())
            {
              deltaX = event.touches[0].clientX - center.x,
              deltaY = event.touches[0].clientY - center.y,
              angle = (Math.atan2(deltaY, deltaX) * 180 / Math.PI);
            }
            else
            {
              deltaX = event.pageX - center.x,
              deltaY = event.pageY - center.y,
              angle = (Math.atan2(deltaY, deltaX) * 180 / Math.PI) ;
            }

            if(isHours)
            {

              //calc percent of angle

              let min = -180, max = 180,
                  anglepercent = parseInt( ((angle-min)/(min-max)) * -100 );

              //calc percent steps

              let steppercent = [];
              for (let i = 0; i < 14; i++)
              {
                let step = parseInt( (i*100)/12 );
                steppercent.push(step)
              }

              //loop step on percent

              let sl = steppercent.length;
              for (let i = 0; i < sl; i++)
              {

                if(anglepercent > steppercent[i-1] && anglepercent < steppercent[i+1])
                {


                  let fromPertoDeg = Math.round( (min-max)*steppercent[i]/100-min )*-1; //from % to degree

                  RayHours.style.transform = 'rotate('+fromPertoDeg+'deg)' ;

                  let hours = parseInt(i-3);

                  if(Am.className.match('active'))
                  {
                    if(hours == 0)              { hours = "12"}
                    else if(hours<0 && hours<10){ hours = i+9; }
                    else if(hours <= 9)         { hours = "0"+hours}
                  }
                  else
                  {
                    if(hours == 0)              { hours = "00"}
                    else if(hours<0 && hours<10){ hours = i+(9+12); }
                    else if(hours <= 9)         { hours = (hours+12)}
                  }


                  Hours.innerHTML = (""+hours);

                }

              }
            }
            else if(isMinutes)
            {

              //calc percent of angle

              let min = -180,
                  max = 180,
                  anglepercent = parseInt( ((angle-min)/(min-max)) * -100 );


              //calc percent steps

              let steppercent = [];
              for (let i = 0; i < 62; i++)
              {
                let step = parseInt( (i*100)/60 );
                steppercent.push(step)
              }

              //loop step on percent
              let sl = steppercent.length;
              for (let i = 0; i < sl; i++)
              {

                if(anglepercent > steppercent[i-1] && anglepercent < steppercent[i+1])
                {

                  let fromPertoDeg = Math.round( (min-max)*steppercent[i]/100-min )*-1 ; //from % to degree

                  RayMinutes.style.transform = 'rotate('+fromPertoDeg+'deg)';

                  let minuts = i-15;

                  if(minuts<0)        { minuts = i+45; }

                  if(minuts == 60)    { minuts = "00"}
                  else if(minuts <= 9){ minuts = "0"+minuts}

                  Minutes.innerHTML = (""+(minuts));

                }

              }
            }


            document.onmouseup = clockStop;

  				};

  				function clockStop(event) {

            document.ontouchmove = null;
            document.onmousemove = null;
            document.onmouseup = null;

  				};


          Accept.addEventListener('click', event => {

            let selectedHours = Hours.innerText,
                selectedMinutes = Minutes.innerText;

            console.log(selectedHours);

            [...Btn.querySelectorAll('.button-time>p')][0].innerHTML = selectedHours+":"+selectedMinutes;
            [...Btn.querySelectorAll('.button-time>input')][0].setAttribute('value', ''+selectedHours+":"+selectedMinutes+'' );

          },true)

        }

      }


      let BtnDate = [...document.querySelectorAll('*[class*=button-date]')];

      if(BtnDate)
      {

        let l = BtnDate.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = BtnDate[i];

          //  1: create empty datepicker output

          //for all, generate a random id from 0 to 1000
          let DATEID = Math.floor(Math.random() * 999);

          //set target of off canvas
          Btn.setAttribute("target","outbox#datepicker-"+DATEID);

          //generate the empty output
          let datepicker_empty =`
          <div class="outbox gpuboost" id="datepicker-`+DATEID+`">

            <div class="side-center">

              <div class="datepicker">

                <div>
                  <a class="close">
                    <p>Select a date</p>
                  </a>
                </div>

                <div>

                  <div>

                    <div class="years">
                      <span class="prev">&nbsp;</span>
                      <span class="year_list"></span>
                      <span class="next">&nbsp;</span>
                    </div>

                  </div>

                  <div>

                    <div class="months">
                      <span class="prev">&nbsp;</span>
                      <span class="month_list"></span>
                      <span class="next">&nbsp;</span>
                    </div>

                  </div>

                </div>

                <div>

                  <div class="weekday_list">
                    <div class="grid-x align-center">

                    </div>
                  </div>

                </div>

                <div>

                  <div class="day_list">
                    <div class="grid-x" align="center">

                    </div>
                  </div>

                </div>

                <div>
                  <div class="button align-center">
                    <a class="accept">OK - CLOSE</a>
                  </div>
                </div>

              </div>

            </div>

          </div>`;

          //print output
          document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',datepicker_empty);



          //  2: recovers a component of output



          let //get datepiker elements
              Datepicker = [...document.querySelectorAll("#datepicker-"+DATEID)][0],
              year_list = [...Datepicker.querySelectorAll(".year_list")][0],
              month_list = [...Datepicker.querySelectorAll(".month_list")][0],
              weekday_list = [...Datepicker.querySelectorAll(".weekday_list>div")][0],
              day_list = [...Datepicker.querySelectorAll(".day_list>div")][0],
              isUTC,isEUR,alldateformat = String(Btn.className);


          // check if is UTC or EUR // not EUR.. then UTC
          Btn.className.match("EUR")?(isUTC=!1,isEUR=!0):(isUTC=!0,isEUR=!1);

          // check date format
          let dateformat,
              classes = [...alldateformat.split(' ')],
              formatkey = ["DMY","DYM","MYD","MDY","YDM","YMD"],
              fkl = formatkey.length;

          for (let i=0;i<fkl;i++)
          {

            if(!(classes.indexOf(formatkey[i]) === -1))
            {
              dateformat = ""+formatkey[i];
            }

          }




          //  3: populate for a start



          //create year list
          let years_array = [];
          for (let i = 1950; i <= 2050; i++){ years_array.push('<p>'+( i )+'</p>'); }
          years_array =  String( years_array.join(' ') );
          year_list.innerHTML =  years_array;


          //create month list
          let month_array = [], monthArray = ['January','February','March','April','May','June','July','August','September','October','November','December'];
          //let month_array = [], monthArray = ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
          for (let i = 0; i <= 11; i++){ month_array.push('<p>'+ monthArray[i] +'</p>') }
          month_array =  String( month_array.join(' ') );
          month_list.innerHTML =  month_array;


          //create weekday list
          //let weekday_array = [], dayweekArray = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
          let weekday_array;
          if(!isEUR)      { weekday_array = [], dayweekArray = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]; }
          else if(isEUR)  { weekday_array = [], dayweekArray = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]; }
          for (let i = 0; i < dayweekArray.length; i++) { weekday_array.push( '<div class="box-[14-14-14]"><p>'+ dayweekArray[i] +'</p></div>' ) }
          weekday_array = String( weekday_array.join(' ') );
          weekday_list.innerHTML =  weekday_array;



          //  4: get all dates value from UTC



          let //get current dates
              date = new Date(),
              format = date.toUTCString(),
              this_year = date.getUTCFullYear(),
              this_month = date.getUTCMonth(),
              this_day = date.getUTCDate(),
              this_week = date.getUTCDay(),
              //console.log("\nRequested for today:\nW: "+this_week+" D: "+this_day+" M: "+this_month+" Y: "+this_year+"\nin string is: "+format+"");


              //get all relative dates
              get_FirstDayOfweek = (month,year) =>
              {

                let Y = parseInt(year),
                    M = parseInt(month); //this fucking bastard start to 1

                let setDate = new Date( Date.UTC(Y,M,01) ),
                    firstDay = parseInt(setDate.getDay());
                    firstDayString = setDate.toUTCString();

                    //console.log("\ndayweek of first day:\n"+firstDay+" -> in: "+Y+"/"+M+"/01 (is not array but dec is nov)\nin string is: "+firstDayString);

                    return firstDay;

              },
              get_DaysQntOfMounth = (month,year) =>
              {

                let Y = parseInt(year),
                    M = parseInt(month+1); //this fucking bastard start to 0
                    dayQuantity = parseInt( new Date( Date.UTC(Y,M,00)).getDate() );

                    //console.log("\nQnt of day in month:\n"+dayQuantity+" -> in: "+Y+"/"+M+" ( month is array '+1' )");

                    return dayQuantity;

              }



          //  5: set contents to start and to action



          //switch years

          let Years = [...year_list.querySelectorAll("p")],
              YearPrev  = Datepicker.querySelector('.years>.prev'),
              YearNext  = Datepicker.querySelector('.years>.next'),
              yearslistlength = Years.length;

          for (let i = 0; i < yearslistlength; i++)
          {

              Years[i].classList.add("off","hide");

              if(Years[i].textContent == this_year )
              {
                Years[i].classList.remove("off","hide");
                Years[i].classList.add("active");
              }

          }

          YearPrev.onclick = () => {


            for (let i = 0; i < yearslistlength; i++)
            {

              if(Years[i].className.match("active") && Years[i-1])
              {

                Years[i].classList.replace("active","off");
                Years[i].classList.add("hide");

                Years[i-1].classList.add("active");
                Years[i-1].classList.remove("off","hide");

                let selectedday = [...Datepicker.querySelectorAll('.day.active')][0].textContent;
                set_datepiker_daystable("","",selectedday);

                return;
              }

            }


          };

          YearNext.onclick = () => {


            for (let i = 0; i < yearslistlength; i++)
            {

              if(Years[i].className.match("active") && Years[i+1])
              {
                Years[i].classList.replace("active","off");
                Years[i].classList.add("hide");

                Years[i+1].classList.add("active");
                Years[i+1].classList.remove("off","hide");

                let selectedday = [...Datepicker.querySelectorAll('.day.active')][0].textContent;
                set_datepiker_daystable("","",selectedday);

                return;
              }

            }


          };


          //switch month

          let Months = [...month_list.querySelectorAll("p")],
              MonthPrev = Datepicker.querySelector('.months>.prev'),
              MonthNext = Datepicker.querySelector('.months>.next'),
              monthslength = Months.length;

          for (let i = 0; i < monthslength; i++)
          {

              Months[i].classList.add("off","hide");

              if(i == this_month)
              {
                Months[i].classList.remove("off","hide");
                Months[i].classList.add("active");
              }

          }

          MonthPrev.onclick = () => {

            for (let i = 0; i < monthslength; i++)
            {

              if(Months[i].className.match("active") && Months[i-1])
              {

                Months[i].classList.replace("active","off");
                Months[i].classList.add("hide");

                Months[i-1].classList.add("active");
                Months[i-1].classList.remove("off","hide");

                let selectedday = [...Datepicker.querySelectorAll('.day.active')][0].textContent;
                set_datepiker_daystable("","",selectedday);

                return;

              }

            }

          }

          MonthNext.onclick = () => {

            for (let i = 0; i < monthslength; i++)
            {

              if(Months[i].className.match("active") && Months[i+1])
              {

                Months[i].classList.replace("active","off");
                Months[i].classList.add("hide");

                Months[i+1].classList.add("active");
                Months[i+1].classList.remove("off","hide");

                let selectedday = [...Datepicker.querySelectorAll('.day.active')][0].textContent;
                set_datepiker_daystable("","",selectedday);

                return;

              }

            }

          }


          //switch days

          Datepicker.addEventListener('click', event => //update date on every click
          {

            let Days = [...Datepicker.querySelectorAll('.day_list .day')],
                daylistlength = Days.length;

            for (let i = 0; i < daylistlength; i++)
            {

              Days[i].onclick = () => {


                  for (let i = 0; i < daylistlength; i++)
                  {
                    Days[i].classList.remove("active");
                    Days[i].classList.add("off");
                  }

                  event.target.classList.replace("off","active");

              }

            }

          },true);


          // after click on year or month update a days list into datepicker

          let set_datepiker_daystable = (year,month,selectedday) =>
          {


            if(!year || !month || year==="" || month==="") // do you know the selected month and year?
            {

              var year =document.querySelector('#datepicker-'+DATEID+' .year_list .active').textContent,
                  month = document.querySelector('#datepicker-'+DATEID+' .month_list .active').textContent;

                  switch (month)
                  { //translate mont to array val
                    case "January": month=0;break;
                    case "February": month=1;break;
                    case "March": month=2;break;
                    case "April": month=3;break;
                    case "May": month=4;break;
                    case "June": month=5;break;
                    case "July": month=6;break;
                    case "August": month=7;break;
                    case "September": month=8;break;
                    case "October": month=9;break;
                    case "November": month=10;break;
                    case "December": month=11;break;
                    default: console.log("error: no mouth active");
                  }

            }


            //set/update weekdays and days in "table list"


            let firstdayweek,
                dayinactualmonth,
                calendarcell,
                days_array,
                daytabulator;

            if(isEUR)
            {

              firstdayweek  = get_FirstDayOfweek(month,year)-1,
              dayinactualmonth = get_DaysQntOfMounth(month,year),
              calendarcell = 41, //start to 0

              days_array = [],
              daytabulator = parseInt(  (calendarcell-firstdayweek+1) );

              for (let i = (firstdayweek+6)*-1; i <= daytabulator; i++)
              {
                let day = i, status = "off", style="";

                if(day>=1 && day<=9) { day="0"+i }

                if(day<=0 || i>dayinactualmonth){ day = "░", style='style="opacity:0.4"', status = "off disabled" }
                else if(day == this_day && !selectedday) { status = "active", style='' }
                else if(day == selectedday) { status = "active", style='' }

                days_array.push('<div class="box-[14-14-14]" '+style+'><p class="day '+status+'">'+( day )+'</p></div>'); //dayout
              }

            }

            else
            {

              firstdayweek  = get_FirstDayOfweek(month,year),
              dayinactualmonth = get_DaysQntOfMounth(month,year),
              calendarcell = 41, //start to 0

              days_array = [],
              daytabulator = parseInt(  (calendarcell-firstdayweek+1) );

              for (let i = (firstdayweek-1)*-1; i <= daytabulator; i++)
              {
                let day = i, status = "off", style="";

                if(day>=1 && day<=9) { day="0"+i }

                if(day<=0 || i>dayinactualmonth){ day = "░", style='style="opacity:0.4"', status = "off disabled" }
                else if(day == this_day && !selectedday) { status = "active", style='' }
                else if(day == selectedday) { status = "active", style='' }

                days_array.push('<div class="box-[14-14-14]" '+style+'><p class="day '+status+'">'+( day )+'</p></div>'); //dayout

              }


            }

            days_array = String(days_array.join(' '));
            day_list.innerHTML =  days_array;



            // if line of day is empty
            if(Btn.className.match('-compact'))
            {
              (() =>{

                let FirsLineDays = [...Datepicker.querySelectorAll('.day_list .day')].slice(0,7);
                let firstline = 0;

                for (let i = 0; i <= 6; i++)
                {
                  if(FirsLineDays[i].textContent === "░") { firstline++; };
                }

                if(firstline===7)
                {
                  for (let i = 0; i <= 6; i++)
                  {
                    FirsLineDays[i].parentNode.innerHTML = "";
                  }
                }


              })();

              (() =>{

                //let LastLineDays = [...Datepicker.querySelectorAll('.day_list .day')].slice(35,42);
                let LastLineDays = [...Datepicker.querySelectorAll('.day_list .day')].slice(-7);

                let lastline = 0;

                for (let i = 0; i <= 6; i++)
                {
                  if(LastLineDays[i].textContent === "░") { lastline++; };
                }

                if(lastline===7)
                {
                  for (let i = 0; i <= 6; i++)
                  {
                    LastLineDays[i].parentNode.innerHTML = "";
                  }
                }

              })();

            }


          }

          set_datepiker_daystable(this_year,this_month); //(add start days on first click)


          //final update of datepiker and input values

          let Accept = [...Datepicker.querySelectorAll(".accept")][0];
          Accept.onclick = () => {

            let finalday = document.querySelector('#datepicker-'+DATEID+' .day_list .active').textContent;

            let activeMonth = document.querySelector('#datepicker-'+DATEID+' .month_list .active').textContent,
                finalmonth;

                switch (activeMonth)
                {
                  case "January": finalmonth="01";break;
                  case "February": finalmonth="02";break;
                  case "March": finalmonth="03";break;
                  case "April": finalmonth="04";break;
                  case "May": finalmonth="05";break;
                  case "June": finalmonth="06";break;
                  case "July": finalmonth="07";break;
                  case "August": finalmonth="08";break;
                  case "September": finalmonth="09";break;
                  case "October": finalmonth="10";break;
                  case "November": finalmonth="11";break;
                  case "December": finalmonth="12";break;
                  default: console.log("error: no mounth active");
                }

            let finalyear = document.querySelector('#datepicker-'+DATEID+' .year_list .active').textContent;

            let datevalue;
            if     (dateformat=="DMY"){ datevalue = String( finalday+"/"+finalmonth+"/"+finalyear ) }
            else if(dateformat=="DYM"){ datevalue = String( finalday+"/"+finalyear+"/"+finalmonth ) }
            else if(dateformat=="MYD"){ datevalue = String( finalmonth+"/"+finalyear+"/"+finalday ) }
            else if(dateformat=="MDY"){ datevalue = String( finalmonth+"/"+finalday+"/"+finalyear ) }
            else if(dateformat=="YDM"){ datevalue = String( finalyear+"/"+finalday+"/"+finalmonth ) }
            else                      { datevalue = String( finalyear+"/"+finalmonth+"/"+finalday ) };

            let datebtn = document.querySelector('[target="outbox#datepicker-'+DATEID+'"]'),
                dateinput = datebtn.querySelector('input');

            dateinput.setAttribute("value",(finalyear+"/"+finalmonth+"/"+finalday));
            dateinput.previousElementSibling.innerHTML = datevalue;

          };


          //active/off week
          // let weekinbox = [...weekday_list.querySelectorAll("p")];
          // for (let i = 0; i < weekinbox.length; i++)
          // {
          //
          //     weekinbox[i].classList.add("off","disabled");
          //
          //     if( i == this_week-1 )
          //     {
          //       weekinbox[i].classList.remove("off","disabled");
          //       weekinbox[i].classList.add("active");
          //     }
          //
          // }


        }

      }


      return;


  }



  ////// ontop

  const gotop = () =>
  {

    let Top = [...document.querySelectorAll(".top")][0];

    if(Top)
    {

      let Sectors = [...document.querySelectorAll('HTML, BODY, .view, .scroll-x, .scroll-y')],
          Docweb = document.documentElement,
          limit = (parseInt( document.body.clientHeight )*2)/3;

        Top.classList.add('off');

        window.addEventListener('scroll', ()=>
        {

          let docscroll = parseInt(Docweb.scrollTop);

          if(Sectors)
          {

            let l = Sectors.length;
            for (let i = 0; i < l; i++)
            {

              let Sector = Sectors[i];
              if(Sector.scrollTop > limit)
              {

                Top.classList.add('active'),
                Top.classList.remove('off');

                Top.addEventListener('click',()=>{  ontop(Sector) },true);

              }

            }

          }

          else if(!Sectors && docscroll > limit )
          {

            Top.classList.add('active'),
            Top.classList.remove('off');

            Top.addEventListener('click',()=>{ ontop() },true);

          }
          else if(docscroll < limit)
          {
            Top.classList.add('off'),
            Top.classList.remove('active');
          }

        },true);


        let ontop = (Sector) => {

          if(Sector)
          {

            Sector.scroll({
              top: 0,
              behavior: 'smooth'
            });

            deactivetop();

          }

          else
          {
            document.documentElement.scroll({
              top: 0,
              behavior: 'smooth'
            });

            deactivetop();

          }

        }

        let deactivetop = () => {

          Top.classList.add('off');
          Top.classList.remove('active');

          setTimeout(()=>{
            Top.classList.add('hide');
            Top.classList.remove('off');
          },1500)

        }


    }

    return;

  }



  ////// anchors

  const anchors = () =>
  {

    let Anchors = [...document.querySelectorAll('a[href^="#"]')];

    let l = Anchors.length;
    for (let i = 0; i < l; i++)
    {

        let Link = Anchors[i],
            target = Link.getAttribute('target');


        if(!target)
        {


          Link.parentNode.addEventListener('click', event => {

            event.preventDefault();
            event.stopPropagation();

            let href = Link.getAttribute("href").split("#")[1];

            if(href && !target)
            {

                let hrefTarget = [document.querySelector('*[name="'+href+'"]')][0];
                //
                // if(Link.closest(".view"))
                // {

                if(hrefTarget)
                {

                  let htpt = hrefTarget.offsetTop,
                      htpl = hrefTarget.offsetLeft;

                  if(htpt>htpl)
                  {
                    setTimeout(()=>{

                      hrefTarget.closest('HTML, BODY, .view, .scroll-y, .scroll-x').scrollTop = htpt;

                    },100);
                  }
                  else
                  {

                    setTimeout(()=>{

                      hrefTarget.closest('HTML, BODY, .view, .scroll-y, .scroll-x').scrollLeft = htpl;

                    },100);
                  }

                }



                // }
                // else
                // {
                //
                //   console.log(hrefTarget);
                //   console.log(hrefposition);
                //
                //   document.body.scrollTo({
                //     top: hrefposition,
                //     behavior: 'smooth'
                //   });
                // }

                //hrefTarget.focus();
              }

          },true);

        }

    }

    return;

  }



  ////// cards

  const card = () =>
  {


    let Cards = [...document.querySelectorAll('[class*="card"]')];

    let l = Cards.length;
    for (let i = 0; i < l; i++)
    {

      let Card = Cards[i];

      Card.addEventListener('click', event => {

        let Loader = [...document.querySelectorAll('.loader')][0],
            Href = Card.querySelector('a:last-child').getAttribute('href'),
            isntBlank = Card.querySelector('a:last-child').getAttribute('target') == ('_top' && '_self' );


        // event.preventDefault(),event.stopPropagation(),event.stopImmediatePropagation();

        if(isntBlank)
        {

          Loader.classList.remove('hide');
          setTimeout( function(){
            Loader.classList.add('active');
          }, 50);

          setTimeout( function(){

            if(Href==='#')
            {
               location.reload();
            }
            else
            {
              location.href = Href;
            }

          }, 300);

        }
        else
        {
          location.href = Href;
        }

      },true);

    }

    return;

  }



  ////// tabs

  const tabx = () =>
  {

    let AllTabsX = [...document.querySelectorAll(".tabs-x")];

    let l = AllTabsX.length;
    for (let i = 0; i < l; i++)
    {

      let Tab = AllTabsX[i],
          AList = [...Tab.querySelectorAll('nav>a')],  //anchorlist
          SList = [...Tab.querySelectorAll('.tabs-x>div')];   //secotrlist

      let l = AList.length;
      for (let i = 0; i < l; i++)
      {

        let A = AList[i],
            S = SList[i];

        A.classList.add('off');
        S.classList.add('off');

        AList[0].classList.replace('off','active');
        SList[0].classList.replace('off','active');

        A.onclick = () =>{

          if(!A.className.match('active'))
          {

            for (let i = 0; i < l; i++)
            {
              AList[i].classList.replace("active","off");
              SList[i].classList.replace("active","off");
            }

            A.classList.replace("off","active");
            S.classList.replace("off","active");

            return false;
          }

        }


      }

    }

    return;

  }

  const taby = () =>
  {


    let AllTabsY = [...document.querySelectorAll(".tabs-y")];

    let tabssize = AllTabsY.length;
    for (let i = 0; i < tabssize; i++)
    {

      let Tab = AllTabsY[i],
          AList = [...Tab.querySelectorAll(".tabs-y>div:nth-child(odd)")];

      let l = AList.length;
      for (let i = 0; i < l; i++)
      {

        let A = AList[i];

        A.classList.add('off');
        A.nextElementSibling.classList.add('off');

        AList[0].classList.replace('off','active');
        AList[0].nextElementSibling.style.height = A.nextElementSibling.scrollHeight+"px";
        AList[0].nextElementSibling.classList.replace('off','active');

        A.onclick = ()=>{

          for (let i = 0; i < l; i++)
          {
            AList[i].classList.add('off');
            AList[i].classList.remove('active');
            AList[i].nextElementSibling.classList.add('off');
            AList[i].nextElementSibling.classList.remove('active');
            AList[i].nextElementSibling.style.height = "0";
          }


          A.classList.replace('off','active');

          A.nextElementSibling.style.height = A.nextElementSibling.scrollHeight+"px";
          A.nextElementSibling.classList.replace('off','active');

          return false;

        }

      }


    }

    return;

  }



  ////// video

  const video = () =>
  {

    let vb = [...document.querySelectorAll("video.background")];
    for (let i = 0; i < vb.length; i++)
    {

      vb[i].parentNode.style.overflow = "hidden";
      vb[i].parentNode.style.position = "relative";

    }

    let player = [...document.querySelectorAll("video.player")];
    for (let i = 0; i < player.length; i++)
    {

      let src = player[i].getAttribute("src"),
          autoplay = player[i].getAttribute("autoplay"),
          controls = player[i].getAttribute("controls"),
          loop = player[i].getAttribute("loop"),
          classes = player[i].getAttribute("classes"),
          id = player[i].getAttribute("id");

      let isYoutu_be 	 = src && src.match(/(?:youtu)(?:\.be)\/([\w\W]+)/i),
          isyoutube 	 = src && src.match(/(?:youtube)(?:\.com)\/([\w\W]+)/i),
          isVimeo 	 = src && src.match(/(?:vimeo)(?:\.com)\/([\w\W]+)/i);


      // check player param

      let ap,ctrl,lp,videowrap;

      if(autoplay && autoplay != "false"){ ap = "autoplay=1"; }
      else{ap = "autoplay=0";}

      if(controls && controls != "false"){ ctrl = "controls=1"; }
      else{ctrl = "controls=0";}

      if(loop && loop != "false"){ lp = "loop=1"; }
      else{lp = "loop=0";}


      if(!id){id=""};
      if(!classes){classes=""};

      // youtu.be

      if (isYoutu_be && player[i].tagName == "VIDEO")
      {

        var utvID = isYoutu_be[1];

        //create new elem
        htmlcode = '<iframe id='+id+' class="'+classes+'" src="https://www.youtube.com/embed/'+utvID+'?'+ap+'&showinfo=0&'+ctrl+'&modestbranding=1&'+lp+'&nologo=1&iv_load_policy=3;" frameborder="0" allowfullscreen"></iframe>';
        videowrap = document.createElement('div');

        //wrap inside new code
        videowrap.innerHTML = htmlcode;
        player[i].parentNode.insertBefore(videowrap, player[i]);

        //unwrap, make free
        videowrap.outerHTML = videowrap.innerHTML;
        player[i].parentNode.removeChild(player[i]);

      }

      // youtube.com

      else if (isyoutube && player[i].tagName == "VIDEO")
      {

        var ytvID = isyoutube[1].split("=")[1];

        //create new elem
        htmlcode = '<iframe id='+id+' class="'+classes+'" src="https://www.youtube.com/embed/'+ytvID+'?'+ap+'&showinfo=0&'+ctrl+'&modestbranding=1&'+lp+'&nologo=1;" frameborder="0" allowfullscreen"></iframe>';
        videowrap = document.createElement('div');

        //wrap inside new code
        videowrap.innerHTML = htmlcode;
        player[i].parentNode.insertBefore(videowrap, player[i]);

        //unwrap, make free
        videowrap.outerHTML = videowrap.innerHTML;
        player[i].parentNode.removeChild(player[i]);

      }

      // videmo

      else if (isVimeo && player[i].tagName == "VIDEO")
      {

        var vvID = isVimeo[1];

        //create new elem
        htmlcode = '<iframe id='+id+' class="'+classes+'" src="https://player.vimeo.com/video/'+vvID+'?color=9c00f0&title=0&byline=0&portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
        videowrap = document.createElement('div');

        //wrap inside new code
        videowrap.innerHTML = htmlcode;
        player[i].parentNode.insertBefore(videowrap, player[i]);

        //unwrap, make free
        videowrap.outerHTML = videowrap.innerHTML;
        player[i].parentNode.removeChild(player[i]);

      }

      // html player

      else
      {

        player[i].setAttribute('controls','true');
        player[i].setAttribute('preload','true');

      }


    }

    return;

  };



  ////// fit

  const fitup = () =>
  {

    setTimeout(()=>{

      let Fits = [...document.querySelectorAll(".fit-up")];

      let l = Fits.length;
      for (let i = 0; i < l; i++) {

        let Fit = Fits[i];

        Fit.parentNode.style.position = "relative";

        let H = Fit.previousElementSibling.offsetHeight,
            W = Fit.previousElementSibling.offsetWidth;

        Fit.style.height = H+'px';
        Fit.style.width = W+'px';
        Fit.style.margin = ('-'+H+'px 0 -'+H+'px 0');

      }
    },10)

    return;

  }

  const fitheight = () =>
  {

    let Fits = [...document.querySelectorAll(".fit-height")];

    let l = Fits.length;
    for (let i = 0; i < l; i++)
    {

      let Fit = Fits[i];

      Fit.parentNode.style.position = 'relative';

      let H = Fit.parentNode.offsetHeight,
          W = Fit.parentNode.offsetWidth;

      Fit.style.width = W+'px';
      Fit.style.height = H+'px';

    }

    return;

  }



  ////// effector: parallax

  const parallax = () =>
  {


    let Parallax = [...document.querySelectorAll('*[class*="fx-parallax-"]')];

    let p = Parallax.length;
    for (let i = 0; i < p; i++)
    {


      let Box = Parallax[i];

      let scale,sensibility;
      if(Box.className.match("mask"))
      {
          scale       = Box.className.split('fx-parallax-[')[1].split('-mask]')[0].split('-')[1],
          sensibility = Box.className.split('fx-parallax-[')[1].split('-mask]')[0].split('-')[0];
      }
      else
      {
          scale = Box.className.split('fx-parallax-[')[1].split(']')[0].split('-')[1],
          sensibility = Box.className.split('fx-parallax-[')[1].split(']')[0].split('-')[0];
      }


      //get all box values
      let height            = Box.offsetHeight,
          width             = Box.offsetWidth,
          reltop            = Box.offsetTop, // positon of box into page
          relleft           = Box.offsetLeft,
          distancetotop     = Box.getBoundingClientRect().top+(height/2), // scroll positon respect the top of screen
          distancetoleft    = Box.getBoundingClientRect().left+(width/2),
          screen_h          = document.body.clientHeight,
          screen_w          = document.body.clientWidth;


      //starter box positon
      let y_start =  (distancetotop-(screen_h/2))*-1,
          x_start =  (distancetoleft-(screen_w/2))*-1;


      //for all child of box
      let counterbox = 1,
          Child = Box.children,
          l = Child.length;

      for (let i = 0; i < l; i++)
      {

        counterbox++;

        let X,Y;
        Y =  ( y_start/screen_h )*(100-(counterbox*sensibility));
        X =  ( x_start/screen_w )*(100-(counterbox*sensibility));


        Child[i].style.transformOrigin = "center";
        Child[i].style.transform = "scale("+(scale)+") translate("+0+"px,"+Y+"px)";

      }

    }

    return;

  }



  ////// spoiler

  const spoiler = () =>
  {

    let Box = [...document.querySelectorAll('.spoiler')];

    let l = Box.length;
    for (let i = 0; i < l; i++)
    {

      let ToggleButton = [...Box[i].querySelectorAll('.toggle')][0];

      ToggleButton.addEventListener('click',()=>{hideshow();},true);

      let hideshow = () =>
      {



        if(!Box[i].className.match('active'))
        {

          Box[i].classList.add('active');
          ToggleButton.classList.add('active');

          Box[i].classList.remove('off');
          ToggleButton.classList.remove('off');

        }
        else
        {

          Box[i].classList.add('off');
          ToggleButton.classList.add('off');

          Box[i].classList.remove('active');
          ToggleButton.classList.remove('active');

        }


      }


    }

    return;

  }


  ////// effector: custom engine

  const effectors = () =>
  {

    let Efxs = [...document.querySelectorAll('[class*="fx-["]')];

    let efxssize = Efxs.length;
    for (let i = 0; i < efxssize; i++)
    {

      let params = Efxs[i].className.split('fx-[')[1].split(']')[0];

      let Target,
          Trigger,
          action,
          cssin,
          timerin,
          delayin,
          cssout,
          timerout,
          delayout,
          toggle,
          hide,
          reset;

      if(params.match("on:"))
      {
          action = ""+params.split("on:")[1].split(";")[0];
      }

      if(params.match("target:"))
      {
          let targetstring = String(params.split("target:")[1].split(";")[0]);
          Target = [...document.querySelectorAll('[class*="target-'+targetstring+'"]')];
      }
      else
      {
          Target = [Efxs[i]];
      }

      if(params.match("trigger:"))
      {
          let triggerstring = String(params.split("trigger:")[1].split(";")[0]);
          Trigger = [...document.querySelectorAll('[class*="trigger-'+triggerstring+'"]')];
      }
      else
      {
          Trigger = [Efxs[i]];
      }

      if(params.match("in:"))
      {
          cssin = ""+params.split("in:")[1].split(";")[0].split(",")[0];
          timerin = ""+params.split("in:")[1].split(";")[0].split(",")[1];
          delayin = ""+params.split("in:")[1].split(";")[0].split(",")[2];

          if(!timerin) { timerin = 1; }
          if(!delayin) { delayin = 1; }

      } else { console.log='kimera debug: fx -> "in" not found!' };

      if(params.match("out:"))
      {
          cssout = ""+params.split("out:")[1].split(";")[0].split(",")[0];
          timerout = ""+params.split("out:")[1].split(";")[0].split(",")[1];
          delayout = ""+params.split("out:")[1].split(";")[0].split(",")[2];

          if(!timerout) { timerout = 1; }
          if(!delayout) { delayout = 1; }

      } else { cssout = false; }

      if(params.match("toggle:"))
      {
          toggle = ""+params.split("toggle:")[1].split(";")[0];
          if(toggle == "true"){ toggle = true; } else {toggle= false;}
      } else { toggle = true; }

      if(params.match("hide:"))
      {
          hide = ""+params.split("hide:")[1].split(";")[0];
      } else { hide = false; }

      if(params.match("reset:"))
      {
          reset = ""+params.split("reset:")[1].split(";")[0];
          if(reset == "true"){ reset = true; } else { reset = false; }
      } else { reset = false; }


      //console.log("fx:["+"\nTarget: "+Target+"\nTrigger: "+Trigger+"\naction: "+action+"\ncssin: "+cssin+"\ntimerin: "+timerin+"\ndelayin: "+delayin+"\ncssout: "+cssout+"\ntimerout: "+timerout+"\ndelayout: "+delayout+"\ntoggle: "+toggle+"\nhide: "+hide+"\nhide: "+reset+"]")


      let triggersize =Trigger.length;
      for (let trs = 0; trs < triggersize; trs++)
      {


        let targetsize =Target.length;
        for (let i = 0; i < targetsize; i++)
        {


          if(hide && !Target[i].className.match('fx-active'))
          {
            Target[i].style.opacity = 0;
          }

          switch (action)
          {

            case 'unloadDoc':
              console.log("kimera debug: fx -> unload not can be used in this version of fx. Sorry.");
            break;

            case 'loadDoc':

                setTimeout(()=>{

                  Target[i].classList.add('[fx-active]',cssin);
                  Target[i].classList.remove('[fx-off]',cssout);

                  setTimeout(()=>{

                    if(reset)
                    {
                      Target[i].classList.remove(cssin);
                    }

                  },timerin)

                },delayin);


            break;

            case "scroll":

              if( Target[i].offsetTop < screen.height && !Target[i].className.match(cssin) )
              {
                  Target[i].classList.add(cssin);
                  Target[i].classList.add("[fx-active]");
              }

              window.addEventListener("scroll", event => { makefx_scrolling(event); }, true);

              let makefx_scrolling = (event) =>
              {

                let	scrollpositionIn = parseInt( document.documentElement.scrollTop + screen.height-(screen.height/10)),
                    scrollpositionOut = parseInt( document.documentElement.scrollTop + (screen.height/10)),
                    elementposition = parseInt( Target[i].offsetTop );

                if(Target[i].className.match('fx-active'))
                {

                  if( elementposition < scrollpositionIn && elementposition > scrollpositionOut  )
                  {

                    setTimeout(()=>{

                        Target[i].classList.add(cssin);
                        Target[i].classList.remove(cssout);

                        setTimeout(()=>{

                          if(reset)
                          {
                            Target[i].classList.remove(cssin);
                          }
                          else
                          {
                            Target[i].classList.add('[fx-off]');
                            Target[i].classList.remove('[fx-active]');
                          }

                        },timerin)


                    },delayin+timerout);

                  }

                }

                if( (elementposition < scrollpositionOut || elementposition > scrollpositionIn ) && Target[i].className.match('fx-off') && toggle )
                {

                  Target[i].classList.add(cssout);
                  Target[i].classList.remove(cssin);

                  Target[i].classList.add('[fx-active]');
                  Target[i].classList.remove('[fx-off]');

                  if(reset)
                  {
                    setTimeout(()=>{
                      Target[i].classList.remove(cssout);
                    },timerout)
                  }

                }
              }

            break;

            case "hover":

              Trigger[trs].addEventListener("mouseover", event =>{ makefx_hoverin() },true);
              Trigger[trs].addEventListener("mouseleave", event =>{ makefx_hoverout() },true);

              let makefx_hoverin = () => {

                let l = Target.length;
                for (let i = 0; i < l; i++)
                {

                  if(!Target[i].className.match('fx-active') || Target[i].className.match('fx-off'))
                  {

                    setTimeout(()=>{

                      Target[i].classList.add('[fx-active]', cssin);
                      Target[i].classList.remove(cssout, '[fx-off]');

                      setTimeout(()=>{

                        if(reset === true)
                        {
                          Target[i].classList.remove(cssin);
                          Target[i].classList.remove(cssin, '[fx-active]');
                        }

                      },timerin)

                    },delayin);

                  }

                }

              };

              let makefx_hoverout = () => {

                for (let i = 0; i < Target.length; i++)
                {

                  if(Target[i].className.match('fx-active') && toggle)
                  {

                    setTimeout(()=>{

                      Target[i].classList.add(cssout,'[fx-off]');
                      Target[i].classList.remove(cssin,'[fx-active]');

                      if(reset)
                      {
                        setTimeout(()=>{
                          Target[i].classList.remove(cssout);
                        },timerout)
                      }

                    },delayout);

                  }

                }

              };


            break;

            case "click":


                Trigger[trs].addEventListener("click", event =>{ makefx_click() },true);

                let makefx_click = () => {


                  for (let i = 0; i < Target.length; i++)
                  {

                    if(!Target[i].className.match('fx-active'))
                    {

                      setTimeout(()=>{

                        Target[i].classList.add('[fx-active]',cssin);
                        Target[i].classList.remove('[fx-off]',cssout);

                        setTimeout(()=>{

                          if(reset)
                          {
                            Target[i].classList.remove('[fx-active]',cssin);
                          }

                        },timerin)

                      },delayin);


                    }

                    if(Target[i].className.match('fx-active') && toggle === true)
                    {

                      setTimeout(()=>{

                        Target[i].classList.add('[fx-off]',cssout);
                        Target[i].classList.remove('[fx-active]',cssin);

                        if(reset)
                        {
                          setTimeout(()=>{
                            Target[i].classList.remove('[fx-off]',cssout);
                          },timerout)
                        }

                      },delayout);

                    }

                  }


                };

            break;

          }

        }

      }

    }

    return;

  }



  ////// checksize

  const scrollsize = () =>
  {

    //'.checksize',
    let Oversizes = [...document.querySelectorAll('.checksize, TABLE, CODE, PRE, OUTPUT')];

    let l = Oversizes.length;
    for (let i = 0; i < l; i++)
    {

      let SizedBox =  Oversizes[i];

      let targetwidth = parseInt(SizedBox.offsetWidth),
          parentwidth = parseInt(SizedBox.parentNode.offsetWidth),
          scrollwrap;

      if( !(SizedBox.parentNode.className.match('scroll-x')) )
      {

        let t = SizedBox.tagName;
        if(t=='TABLE'||t=='CODE'||t=='PRE'||t=='OUTPUT')
        {
          let minw = parseInt(SizedBox.style.minWidth);

          if(targetwidth > parentwidth)
          {

            let ScrollableWrap = document.createElement('div');

          	SizedBox.parentNode.insertBefore(ScrollableWrap, SizedBox);
          	ScrollableWrap.appendChild(SizedBox);
            SizedBox.parentNode.classList.add('scroll-x');

          }
          else if( targetwidth <= parentwidth && SizedBox.parentNode.className.match('checksize') )
          {
            SizedBox.parentNode.outerHTML = SizedBox.parentNode.innerHTML;
          }

        }

        else
        {

          if( targetwidth > parentwidth )
          {

            //wrap it
            let ScrollableWrap = document.createElement('div');

          	SizedBox.parentNode.insertBefore(ScrollableWrap, SizedBox);
          	ScrollableWrap.appendChild(SizedBox);
            SizedBox.parentNode.classList.add('scroll-x','checksize');

          }
          else if(targetwidth <= parentwidth && SizedBox.parentNode.className.match('checksize') )
          {
            SizedBox.parentNode.outerHTML = SizedBox.parentNode.innerHTML;
          }

        }


      }


    }

    return;

  }






  ///// K launcher

    //document.readyState == 'complete' &&
    window.onunload = () => { null; loaderstart(); };
    document.addEventListener('DOMContentLoaded',
    () => { loaderstart(); nomobar(); });

    document.addEventListener('DOMContentLoaded',
      () => {
        viewportapp();
        buttons();
        absolute();
        scrollsize();
        standardscroll();
        snapscroll();
        anchors();
        card();
        tabx();
        taby();
        spoiler();
        video();
      },true);

    window.addEventListener('load',(
      eventDone( () => {
        outbox();
        parallax();
        autocrop();
        fitheight();
        fitup();
        effectors();
        flange();
        loaderout();
      })
    ),false);

    document.addEventListener('change',(
      eventDone( () => {
        outbox();
      })
    ),false);

    window.addEventListener('scroll',
    () => {
        parallax();
        eventDone( () => {
          gotop();
        })
    },true);

    window.addEventListener('resize',(
      eventDone( () => {
        fitheight();
        fitup();
        video();
        autocrop();
        flange();
        parallax();
        scrollsize();
      })
    ),false);

    window.onresize = () =>{ nomobar(); }



})();
