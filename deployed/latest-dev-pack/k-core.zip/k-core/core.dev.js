

/*
//	[ kimera framework V 2.5.0a ] [gapkit project beta 0.5.0 ]
//	Credits: Shape group - Alberto Marà & Shape group - All right reserved
//	https://github.com/ShapeGroup/kimera-frontend-framework/wiki
//	https://www.facebook.com/kimeraframework/
*/

////// Kimera

const k = ((ajaxstatus) => {

  console.time(':::: [ kimera framework V2.5.0 ]\n:::: [ wikizone ] https://git.io/fhSzk\n:::: [ k-loader ] page time ')

 ////// eventDone

  const eventDone = (F) =>
  {
     var timer;
     return (event) =>
     {
       if(timer) clearTimeout(timer);
       timer = setTimeout(F,100,event);
     };
  }



  ////// loader

  const loaderstart = () =>
  {


      if(document.documentElement.clientWidth <= 920) // fuck mobile browser bar!
      {
       document.querySelector('html').style.height = window.innerHeight + 'px';
       document.querySelector('body').style.height = window.innerHeight + 'px';
      }
      else
      {
       document.querySelector('html').style.height = '';
       document.querySelector('body').style.height = '';
      }


      if ( ajaxstatus != true || ajaxstatus == undefined )
      {

        Loader = [...document.querySelectorAll('.loader')][0];
        Loader.style.transitionTime='';
        Loader.classList.add('active');

        window.onload = () =>
        {

          document.querySelectorAll('*[class*="viewport-"]')[0].style.opacity='1';

          Loader.classList.add('off');
          Loader.classList.remove('active');

          effectors();

          setTimeout(()=>{

            Loader.classList.remove('active', 'gpuboost');
            Loader.classList.replace('off','hide');

            console.timeEnd(':::: [ kimera framework V2.5.0 ]\n:::: [ wikizone ] https://git.io/fhSzk\n:::: [ k-loader ] page time ')

          },500)

          return;

        }

      }


  }



  // Loader out

  const loaderout = () =>
  {

    let OutLinks = [...document.querySelectorAll('[target*="_self"], [target*="_top"], [target*="_inside]"')];

    let l = OutLinks.length;
    for (let i = 0; i < l; i++)
    {

      let Link = OutLinks[i];

      Link.onclick = event =>
      {

        event.preventDefault();

        let Loader = [...document.querySelectorAll('.loader')][0],
            destination = Link.getAttribute('href'),
            disabled = Link.getAttribute('disabled');

        Loader.querySelector('.spinner-box').classList.add('hide');
        Loader.classList.add('off');


        if(!disabled)
        {

          Loader.classList.remove('hide');


          setTimeout( () => {

            Loader.classList.add('gpuboost','active');
            Loader.classList.remove('off');

          }, 15); // after add gpuboost

          setTimeout( () => {

            if(destination==='#')
            {
              location.reload();
            }
            else
            {
              location.href=destination;
            }

          }, 270); // after loader fadein

        }

      }

    }

    return;

  }



  ////// viewport-app

  const viewportapp = () =>
  {


    // options

    let lockScroll  = false,
        draglimit   = parseInt((document.body.clientWidth/1.65)), // drag
        sensibility = 50; // swipe


    let AllViewportApp = [...document.querySelectorAll('.viewport-app')];

    let l = AllViewportApp.length;
    for (let i = 0; i < l; i++)
    {


      let   VPort = AllViewportApp[i];


      //set all controller elements

      let   Controller    = [...VPort.querySelectorAll('.view-controller')][0],
            ContentBox    = [...VPort.querySelectorAll('.view-group')][0],
            Section       = [...ContentBox.querySelectorAll('.view')],
            Pointers      = [...Controller.querySelectorAll('.pointer')],
            PrevView      = [...VPort.querySelectorAll('.prev-view')],
            NextView      = [...VPort.querySelectorAll('.next-view')],
            Dots          = VPort.querySelector('.dots'),
            Steps         = VPort.querySelector('.steps');


      if(Dots)
      {
        if(Dots.closest('.snap-x')||Dots.closest('.snap-y')){ Dots = null;}
      }

      //check controller elements

      let isPointed, isDots, isSteps;
      if(Pointers<=0) { isPointed=false } else { isPointed=true };
      if(!Dots) { isDots=false } else { isDots=true };
      if(!Steps) { isSteps=false } else { isSteps=true };



      ////// swipe actions

      let sectionsize = Section.length;
      for (let i = 0; i < sectionsize; i++)
      {


        ////// on first, find start viewbox by active

        if(Section[i].className.match('active'))
        {

          let start = i,
              StartPosition = Section[start].offsetLeft;

          if(isPointed)
          {
            Pointers[start].classList.add('active');
          }

          ContentBox.style.transform = 'translate('+StartPosition*-1+'px,0)';

        }



        /////// steps manager

        if( isSteps )
        {

          let StepSpan  = document.createElement('span');

          Steps.appendChild(StepSpan);

          StepSpan.classList.add('step');

          if(Section[i].className.match('active'))
          {
            let sai = i,
            steps = [...Steps.querySelectorAll('.step')];
            for (sai = 0; sai < steps.length; sai++)
            {
              steps[sai].classList.add("active");
            }
          }

        }



        /////// dots manager

        if( isDots )
        {

          let DotSpan  = document.createElement('span');

          Dots.appendChild(DotSpan);

          DotSpan.classList.add('dot');

          if(Section[i].className.match('active'))
          {
            DotSpan.classList.add('active');
          }

        }



        ////// controllers manager

        if( isPointed )
        {

          Pointers[i].onclick = event =>
          {


            ContentBox.classList.remove('smooth'); //immidiatly! native app like.

            resetActiveClasses();

            Pointers[i].classList.add('active');
            Section[i].classList.add(/*'visible',*/'active');

            event.preventDefault(/*stop all return click.*/);


            //define relative panel offset

            let RelativePanel;

            if( i >= Pointers.length-1 )
            {

              let   SWidth = parseInt( window.getComputedStyle(Section[i]).width ),
              WWidth = parseInt( window.innerWidth),
              Offset = Section[i].offsetLeft;

              RelativePanel = parseInt( (Offset)-(WWidth-SWidth) );

            }

            else
            {

              RelativePanel = Section[i].offsetLeft;

            }


            updateSteps();
            updateDots();


            //go on panel


            addSmooth();

            ContentBox.style.transform = 'translate('+RelativePanel*-1+'px,0)';

            removeSmooth();


          }

        }


        ////// content manager

        let EventTarget,
            PanelTarget,

            PrevPanel,
            NextPanel,
            PrevOffset,
            NextOffset,

            Zone,
            DragPosition,
            StartX, StartY,
            DistX, DistY, DragX, DragY,

            StartTouchPosition,
            StandardPosition,
            underScroll,

            StartTime;



        ContentBox.ontouchstart = event =>
        {

          ContentBox.classList.remove("smooth"); /*immidiatly! native app like.*/

          //set target of actions

          PanelTarget = event.target.closest('.view');
          EventTarget = event.target;

          //you can drag?

          if(
              event.target.closest('.scroll-x') || event.target.closest('.scroll-y') ||
              event.target.closest('.snap-x') || event.target.closest('.snap-y') ||
              event.target.closest('.button-range *') || event.target.className.match("nofx")
            )
          {
            PanelTarget.removeAttribute("draggable");
          }
          else
          {
            PanelTarget.setAttribute('draggable','true');
          }

          //set event starter variable

          Zone        = event.changedTouches[0],
          StartX      = Zone.pageX,
          StartY      = Zone.pageY,
          StartTime   = new Date(),

          StartTouchPosition =  parseInt( Zone.clientX ),
          PrevPanel = PanelTarget.previousElementSibling,
          NextPanel = PanelTarget.nextElementSibling,

          underScroll = false;

          //check who is the active

          if(!PanelTarget.className.match('active'))
          {
            resetActiveClasses();
            PanelTarget.classList.add('active');
            updateController();
            updateSteps();
            updateDots();
          }


          // set previous elements

          if(PrevPanel)
          {
            PrevOffset  = parseInt( PanelTarget.previousElementSibling.offsetLeft*-1 )
          }

          else
          {
            PrevOffset = PanelTarget.offsetLeft
          }


          // set next elements

          if(NextPanel)
          {
            NextOffset  = parseInt( PanelTarget.nextElementSibling.offsetLeft*-1 )
          }

          else if(NextPanel === null)
          {
            NextOffset  = parseInt( PanelTarget.offsetLeft*-1 )
          }

          else if(NextPanel === null && (parseInt(NextPanel.nextElementSibling.offsetWidth) <  parseInt(ContentBox.offsetWidth)))
          {  //note: else is last and have a small width... recalculate final scroll by pre-last
            NextOffset  = parseInt( PanelTarget.offsetLeft*-1 );
          }


        }


        ContentBox.ontouchmove = event =>
        {


          //refresh starter variable on dragging

          Zone                 = event.changedTouches[0],
          StandardPosition     = PanelTarget.offsetLeft,
          DragPosition         = parseInt( ( (StandardPosition+StartTouchPosition) ) + (Zone.pageX*-1) ),
          DragY                = Zone.pageY-StartY,
          DragX                = StandardPosition-DragPosition;


          PanelTarget.onscroll = event =>
          {
            underScroll = true;
            return;
          }

          let X = Math.abs(DragX), Y = Math.abs(DragY);
          if(PanelTarget.hasAttribute('draggable') && X>Y)
          {

            if( DragX < 0 && !NextPanel || DragX > 0 && !PrevPanel)
            {
              DragX = 0;

              addSmooth();

              ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
              PanelTarget.removeAttribute('draggable');

              removeSmooth();
            }
            else if( DragX != 0 && !underScroll )
            {
              DragY = 0;
              ContentBox.style.transform = 'translate('+DragPosition*-1+'px,0)';
            }

          }
          else
          {

            DragX = 0;

            addSmooth();

            ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
            PanelTarget.removeAttribute('draggable');

            removeSmooth();

          }

        };


        ContentBox.ontouchend = event =>
        {


          //refresh starter variable on dragging

          Zone = event.changedTouches[0],
          StandardPosition = PanelTarget.offsetLeft,
          DistX = parseInt(Zone.pageX - StartX),
          DistY = parseInt(Zone.pageY - StartY)


          //Drag Release
          let X = Math.abs(DistX), Y = Math.abs(DistY);

          let Sensibility
          if(
              event.target.closest('.scroll-x') || event.target.closest('.scroll-y') ||
              event.target.closest('.snap-x') || event.target.closest('.snap-y') ||
              event.target.closest('.button-range *') || event.target.className.match("nofx")
            )
          {
            Sensibility = 0;
            DistX = 0;
          }
          else
          {
            Sensibility = sensibility;
          }


          let SwipeRangeY = DistY <= (Sensibility*2) && DistY >= -(Sensibility*2),
              stoptime = new Date() - StartTime;
              swipemin = parseInt( Sensibility*12/(Sensibility/4) );
              swipemax = parseInt( Sensibility*82/(Sensibility/4)  ),
              timerange = stoptime >= swipemin && stoptime <= swipemax;

          if(PanelTarget.hasAttribute('draggable'))
          {

            DistY = 0;
            DistX = DistX*-1;

            if( (DistX >= (draglimit/2) && timerange) || (DistX > draglimit))
            {
              goNext();
            }
            else if( (DistX <= -(draglimit/2)&& timerange) ||  (DistX < (-draglimit)))
            {
              goPrev();
            }
            else
            {
                addSmooth();

                ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
                PanelTarget.removeAttribute('draggable');

                removeSmooth();
            }

          }


          //stop all and fuckoff.
          PanelTarget.blur();
          underScroll = false;


        };


        ////// Next\Prev manager

        if( NextView )
        {

          let nvl = NextView.length;
          for (let n = 0; n < nvl; n++)
          {

            NextView[n].onclick = event =>
            {

              event.preventDefault();
              event.stopPropagation();


              let sl = Section.length;
              for (let i = 0; i < sl; i++)
              {

                let nextindex;
                if(Section[i].className.match('active'))
                {

                  nextindex = parseInt(i+1);
                  __next(nextindex);
                  return;
                }

                function __next(nextindex)
                {

                  if(Section[nextindex] === undefined) {  return; }

                  else(nextindex>=0 && nextindex<=Section.length)
                  {

                    let offset = Section[nextindex].offsetLeft;

                    resetActiveClasses();

                    addSmooth();

                    ContentBox.style.transform = 'translate('+offset*-1+'px,0)';
                    Section[nextindex].classList.add("active");

                    removeSmooth();

                    updateController();

                  }
                }


              }

            }

          }
        }
        else{ NextView = null; }

        if( PrevView )
        {

          let pvl = PrevView.length;
          for (let p = 0; p < pvl; p++)
          {

            PrevView[p].onclick = event =>
            {

              event.preventDefault();
              event.stopPropagation();


              let sl = Section.length;
              for (let i = 0; i < sl; i++)
              {


                let previndex;
                if(Section[i].className.match('active'))
                {

                  previndex = parseInt(i-1);
                  __prev(previndex);
                  return;
                }

                function __prev(previndex)
                {

                  if(Section[previndex] === undefined) {  return; }

                  else(previndex>=0 && previndex<=Section.length)
                  {

                    let offset = Section[previndex].offsetLeft;

                    resetActiveClasses();

                    addSmooth();

                    ContentBox.style.transform = 'translate('+offset*-1+'px,0)';
                    Section[previndex].classList.add('active');

                    removeSmooth();

                    updateController();

                  }
                };


              }

            }

          }
        }
        else{ PrevView = null; }



        ////// methods...


        let addSmooth = () =>
        {
          ContentBox.classList.add('smooth');
        }

        let removeSmooth = () =>
        {
          setTimeout(()=>{
            ContentBox.classList.remove('smooth');
          },600)
        }

        let resetActiveClasses = () =>
        {

          for (let p = 0; p < Pointers.length; p++)
          {
            Pointers[p].classList.remove('active');
          }

          for (let s = 0; s < Section.length; s++)
          {
            Section[s].classList.remove('active'/*,'hidden'*/);
          }

        }


        let updateDots = () =>
        {
          if( Dots )
          {

            let dot = [...Dots.querySelectorAll('.dot')];

            for (let i = 0; i < Section.length; i++)
            {

              if(Section[i].className.match('active'))
              {
                dot[i].classList.add('active');
              }
              else
              {
                dot[i].classList.remove('active');
              }

            }

          }

        }

        let updateSteps = () =>
        {

          if( Steps )
          {
            let step = [...Steps.querySelectorAll('.step')];

            for (let i = 0; i < step.length; i++)
            {
              step[i].classList.remove("active");
            }

            for (let i = 0; i < Section.length; i++)
            {

              if(Section[i].className.match('active'))
              {
                let filled = step.fill(0,1+i);
                for (let f = 0; f < 1+i; f++) {
                  filled[f].classList.add('active');
                }
              }
            }

          }

        }

        let updateController = () =>
        {

          for (let i = 0; i < Section.length; i++)
          {

            if(Section[i].className.match('active'))
            {
              if( isPointed ) { Pointers[i].classList.add('active'); }
              //Section[i].classList.replace('hidden','visible');

            }

            else
            {
              if( isPointed ) { Pointers[i].classList.remove('active'); }
            }

          }


        }

        let goNext = () =>
        {


          addSmooth();

          PanelTarget.removeAttribute('draggable');
          PanelTarget.classList.remove('active');
          NextPanel.classList.add('active');


          // if(!NextPanel.nextElementSibling && (window.getComputedStyle(ContentBox).width > window.getComputedStyle(NextPanel).width))
          // {
          //   let   NEW = parseInt( window.getComputedStyle(NextPanel).width ),
          //         VCW = parseInt( window.innerWidth),
          //         NCO = NextPanel.offsetLeft,
          //
          //   LastPosition = parseInt( (NCO)-(VCW-NEW) );
          //
          //   //it's last and small!
          //   ContentBox.style.transform = 'translate('+(LastPosition*-1)+'px,0)';
          // }
          // else
          // {
            ContentBox.style.transform = 'translate('+NextOffset+'px,0)';
          // }


          removeSmooth();

          updateController();
          updateSteps();
          updateDots();


        }

        let goPrev = () =>
        {

          addSmooth();

          PanelTarget.removeAttribute('draggable');

          PanelTarget.classList.remove('active');
          PrevPanel.classList.add('active');


          ContentBox.style.transform = 'translate('+PrevOffset+'px,0)';

          removeSmooth();

          updateController();
          updateSteps();
          updateDots();


        }



      }


    }

  }


  ////// outbox

  const outbox = () =>
  {

    //options

    let Viewport = document.querySelector('body>*[class*="viewport-"]'),
        RelOutbox = [...document.querySelectorAll('*[target^="outbox#"]')];


    let l = RelOutbox.length;
    for (let i = 0; i < l; i++)
    {

      RelOutbox[i].onclick = event =>
      {

          event.preventDefault();

          let target = RelOutbox[i].getAttribute('target').split('#')[1],
              OutBox = [...document.querySelectorAll('#'+target)][0],
              OutBoxType = OutBox.querySelector('div').className;

          // do open...

          OutBox.classList.add('gpuboost','active');

          if( OutBoxType.match('center') )
          { addViewTransition('center'); }

          else if( OutBoxType.match('top') )
          { addViewTransition('top'); }

          else if( OutBoxType.match('left') )
          { addViewTransition('left'); }

          else if( OutBoxType.match('right') )
          { addViewTransition('right'); }

          else if( OutBoxType.match('bottom') )
          { addViewTransition('bottom'); }


          OutBox.onclick = event =>
          {

              if(event.target.className.match('close') || event.target.className.match('accept') || event.target === OutBox)
              {

                OutBox.classList.add('off');
                OutBox.classList.remove('active');

                setTimeout( () => {
                  OutBox.classList.remove('off','active','gpuboost');
                },300)

                removedViewTransition(OutBox);

                return;
              }

          }

          return;
      }


    }

    let addViewTransition  = (side) =>
    {

      Viewport.classList.add('gpuboost','vfxtransition-in','vfx'+side);

    }

    let removedViewTransition  = (OutBox, side) =>
    {

      Viewport.classList.add('vfxtransition-out'),
      Viewport.classList.remove('vfxtransition-in','vfxtop','vfxleft','vfxbottom','vfxright','vfxcenter');

      setTimeout( () => {
        OutBox.classList.remove('off','active','gpuboost'),
        Viewport.classList.remove('vfxtransition-out','gpuboost');
      },500)

    }



  };



  ////// position absolute

  const absolute = () =>
  {

      var absolute = [...document.querySelectorAll('[class*="absolute-"]')];

      let l = absolute.length;
      for (let i = 0; i < l; i++)
      {
        if(!absolute[i].parentNode.className.match('outbox') || !absolute[i].parentNode.className.match('view'))
        {
          absolute[i].parentNode.style.position = 'relative';
        }
      }

      return;
  }



  ////// standard scroll manager

  const standardscroll = () =>
  {

    var ScrolledBox = [...document.querySelectorAll('.scroll-x, .scroll-y')];

    let l = ScrolledBox.length;
    for (let i = 0; i < l; i++)
    {

      let sensibility

      if( typeof InstallTrigger !== 'undefined' )//is firefox?
      {
        sensibility = 85;
      }
      else
      {
        sensibility = 2.5;
      }

      var onwhe = -1;
      ScrolledBox[i].onwheel = event =>
      {

        event.preventDefault();
        event.stopPropagation();
        ScrolledBox[i].focus();

        onwhe++
        if(onwhe >= 1)
        {


          let velocityofscrolling;

          if(onwhe<5)
          {
            velocityofscrolling = (onwhe/2);
          }
          else {
            velocityofscrolling = (onwhe/3.5);
          }


          if(ScrolledBox[i].className.match('scroll-x'))
          {


            if(event.deltaY>0)
            {
              ScrolledBox[i].scrollLeft += velocityofscrolling*(sensibility*event.deltaY);
            }
            else if(event.deltaY<0)
            {
              ScrolledBox[i].scrollLeft -= (velocityofscrolling*(sensibility*event.deltaY))*-1;
            }
          }

          else if(ScrolledBox[i].className.match('scroll-y'))
          {


            if(event.deltaY>0)
            {
              ScrolledBox[i].scrollTop += velocityofscrolling*(sensibility*event.deltaY);

            }
            else if(event.deltaY<0)
            {
              ScrolledBox[i].scrollTop -= (velocityofscrolling*(sensibility*event.deltaY))*-1;
            }

          }

          setTimeout(()=>{
            return onwhe = 0;
          },150)

        }

      }

    }

  }



  ////// snap scroll manager

  const snapscroll = () =>
  {


    //
    // 1 set for start
    //


    (()=>{

        let AllSnaps = [...document.querySelectorAll('.snapgroup')];

        let l = AllSnaps.length;
        for (let i = 0; i < l; i++)
        {

          let Snapgroup = AllSnaps[i];

          let Firstofmask = [...Snapgroup.querySelectorAll('*:first-child')][0];
              Firstofmask.classList.add('active');


          if(Snapgroup.nextElementSibling && Snapgroup.nextElementSibling.className.match('dots'))
          {

              let GroupChilds = [...Snapgroup.querySelectorAll(".snapgroup>*")];

              let cl = GroupChilds.length;
              for (let i=0; i<cl; i++)
              {

                  let DotBox = GroupChilds[i].parentNode.nextElementSibling,
                      dot  = document.createElement('span');

                  DotBox.appendChild(dot);

                  dot.classList.add('dot');

                  let FirstDot = [...DotBox.querySelectorAll('.dot')][0];
                  FirstDot.classList.add("active");

              }

          }

        }

    })();


    //
    // 2 make dynamic
    //


    let Xsnap = [...document.querySelectorAll('.snap-x>.snapgroup')],
        Ysnap = [...document.querySelectorAll('.snap-y>.snapgroup')],
        Snap;

    let xl = Xsnap.length;
    for (let i = 0; i < xl; i++)
    {


        let Zone,
            ActiveChild, ActiveIndex,
            StandardPosition,
            StartXPosition, StartYPosition,
            LimitToNext, LimitToPrev,
            DragX;


        Xsnap[i].ontouchstart = event =>
        {


          Zone = event.changedTouches[0];
          StartXPosition = parseInt( Zone.pageX );
          StartYPosition = parseInt( Zone.pageY );


          event.preventDefault(/*stop all return click.*/);


          //get active
          let Childs = [...Xsnap[i].children];
          for (let i = 0; i < Childs.length; i++)
          {

            if(Childs[i].className.match('active'))
            {
              ActiveChild = Childs[i];
              ActiveIndex = i;
            }

          }


        }

        Xsnap[i].ontouchmove = event =>
        {


          Zone = event.changedTouches[0];
          DragXPosition = parseInt( (ActiveChild.offsetLeft+StartXPosition) + (Zone.pageX*-1) );
          DragX = parseInt( StartXPosition+(Zone.pageX*-1) );


          if(DragX > 100)
          {

            event.preventDefault(/*stop all return click.*/);

            goToNext(Xsnap[i],ActiveChild);

          }
          else if(DragX < (-100))
          {

            event.preventDefault(/*stop all return click.*/);

            goToPrev(Xsnap[i],ActiveChild);

          }
          else
          {
            Xsnap[i].style.transform = 'translate('+DragXPosition*-1+'px,0)';
          }


        }

        Xsnap[i].ontouchend = event =>
        {

          event.preventDefault(/*stop all return click.*/);

          //get active
          let Childs = [...Xsnap[i].children];
          for (let i = 0; i < Childs.length; i++)
          {

            if(Childs[i].className.match('active'))
            {
              ActiveChild = Childs[i];
              ActiveIndex = i;
            }

          }

          Xsnap[i].style.transform = 'translate('+ActiveChild.offsetLeft*-1+'px,0)';

        }

        Xsnap[i].onwheel = event =>
        {

          if(event.deltaY !=0)
          {
            Snap = Xsnap[i];
            snapto(event,Snap);

            event.stopPropagation();
            event.preventDefault();
          }

        }

    }

    let yl = Ysnap.length;
    for (let i = 0; i < yl; i++)
    {


      let Zone,
          ActiveChild, ActiveIndex,
          StandardPosition,
          StartXPosition, StartYPosition,
          LimitToNext, LimitToPrev;


      Ysnap[i].ontouchstart = event =>
      {


        Zone = event.changedTouches[0];
        StartXPosition = parseInt( Zone.pageX );
        StartYPosition = parseInt( Zone.pageY );


        event.preventDefault(/*stop all return click.*/);


        //get active
        let Childs = [...Ysnap[i].children];
        for (let i = 0; i < Childs.length; i++)
        {

          if(Childs[i].className.match('active'))
          {
            ActiveChild = Childs[i];
            ActiveIndex = i;
          }

        }


      }

      Ysnap[i].ontouchmove = event =>
      {


        Zone = event.changedTouches[0];
        DragYPosition = parseInt( (ActiveChild.offsetTop+StartYPosition) + (Zone.pageY*-1) );
        DragY = parseInt( StartYPosition+(Zone.pageY*-1) );


        if(DragY > 100)
        {

          event.preventDefault(/*stop all return click.*/);

          goToNext(Ysnap[i],ActiveChild);

        }
        else if(DragY < -100)
        {

          event.preventDefault(/*stop all return click.*/);

          goToPrev(Ysnap[i],ActiveChild);

        }
        else
        {
          Ysnap[i].style.transform = 'translate(0,'+DragYPosition*-1+'px)';
        }


      }

      Ysnap[i].ontouchend = event =>
      {

        event.preventDefault(/*stop all return click.*/);

        //get active
        let Childs = [...Ysnap[i].children];
        for (let i = 0; i < Childs.length; i++)
        {

          if(Childs[i].className.match('active'))
          {
            ActiveChild = Childs[i];
            ActiveIndex = i;
          }

        }

        Ysnap[i].style.transform = 'translate(0,'+ActiveChild.offsetTop*-1+'px)';

      }

      Ysnap[i].onwheel = event =>
      {

        if(event.deltaY !=0)
        {
          Snap = Ysnap[i];
          snapto(event,Snap);

          event.stopPropagation();
          event.preventDefault();
        }

      }

    }


    let snapto = (event,Snap) =>
    {

      //get active
      let Childs = [...Snap.querySelectorAll('.snapgroup>*')];
      for (let i = 0; i < Childs.length; i++)
      {

        if(Childs[i].className.match('active'))
        {
          ActiveChild = Childs[i];
        }

      }

      if(event.deltaY >= 1)
      {
        goToNext(Snap,ActiveChild);
      }
      else if(event.deltaY <= -1)
      {
        goToPrev(Snap,ActiveChild);
      }

    }

    let goToNext = (Snap,Activechild) =>
    {

      if(Activechild.nextElementSibling)
      {

        let nextactive = Activechild.nextElementSibling,
            nextposLeft = parseInt( nextactive.offsetLeft ),
            nextposTop = parseInt( nextactive.offsetTop );

        Snap.style.transform = 'translate('+nextposLeft*-1+'px,'+nextposTop*-1+'px)';

        Activechild.classList.remove('active');
        nextactive.classList.add('active');

        updateDots(Snap);

      }

    }

    let goToPrev = (Snap,Activechild) =>
    {

      if(Activechild.previousElementSibling)
      {

        let nextactive = Activechild.previousElementSibling,
            nextposLeft = parseInt( nextactive.offsetLeft ),
            nextposTop = parseInt( nextactive.offsetTop );

        Snap.style.transform = 'translate('+nextposLeft*-1+'px,'+nextposTop*-1+'px)';

        Activechild.classList.remove('active');
        nextactive.classList.add('active');

        updateDots(Snap);

      }

    }

    let updateDots = (Snap,ActiveIndex) =>
    {

      if(Snap.nextElementSibling)
      {

        if(Snap.nextElementSibling.className.match('dots'))
        {

          //get\set active dot
          let Dots = [...Snap.nextElementSibling.querySelectorAll(".dot")],
              Childs = [...Snap.querySelectorAll('.snapgroup>*')];

          for (let i = 0; i < Childs.length; i++)
          {

            if(Childs[i].className.match('active'))
            {
              Dots[i].classList.add('active')
            }
            else
            {
              Dots[i].classList.remove('active')
            }

          }

        }


      }

    }

  }



  ////// snap scroll manager

  const autocrop = () =>
  {
    var Croppeds = [...document.querySelectorAll('*[class*="autocrop"]')]


    let l = Croppeds.length;
    for (let i = 0; i < l; i++)
    {

      let ph = String(Croppeds[i].parentNode.offsetHeight)+"px";
      Croppeds[i].style.height = ph;

    }

  }



  ////// flange

  const flange = () =>
  {


    var Flanges = [...document.querySelectorAll('*[class*="flange"]')]


    let l = Flanges.length;
    for (let i = 0; i < l; i++)
    {


        let Flange = Flanges[i],
            Nav = Flange.closest('NAV'),
            Trigger = Flange.previousElementSibling,

            flangeoffs,navoffs,position,
            flangeheight,parentheight,
            flangewidth,parentWidth,
            isopen=false;


        Flange.parentElement.style.position = 'relative';


        if(Flange.className.match('flange-left') || Flange.className.match('flange-right'))
        {

            if(Flange.tagName == 'DIV') //equalize height
            {

              Flange.style.height = Nav.offsetHeight+'px';

              flangeoffs = (Flange.parentNode.offsetTop),
              navoffs = (Nav.offsetTop),
              positon = (navoffs-flangeoffs);

              Flange.style.top = positon+'px';

            }
            else //center it (by height)
            {

              Flange.style.top = 0;

              flangeheight = (Flange.offsetHeight)/2,
              parentheight = (Flange.parentNode.offsetHeight)/2,
              position = (flangeheight-parentheight)*-1;

              Flange.style.marginTop = position+'px';

            }

            if(Flange.className.match('flange-left'))
            {
              flangewidth = (Flange.offsetWidth)*-1;
              Flange.style.left = flangewidth+'px';
            }

        }

        if(Flange.className.match('flange-top') || Flange.className.match('flange-bottom'))
        {

          if(Flange.tagName == 'DIV') //equalize width
          {

            flangeoffs = parseInt(Flange.parentNode.offsetLeft),
            navoffs = parseInt(Nav.offsetLeft),
            position = navoffs-flangeoffs;

            Flange.style.left = position+'px';
            Flange.style.width = Nav.offsetWidth+'px';

          }
          else //center it (by width)
          {

            let flangewidth = parseInt(Flange.offsetWidth)/2,
                parentWidth = parseInt(Flange.parentNode.offsetWidth)/2,
                position = (flangewidth-parentWidth)*-1;

            Flange.style.left = position+'px';

          }


          if(Flange.className.match('flange-top'))
          {
              Flange.style.top = 0;
              flangeheight = (Flange.offsetHeight)*-1;
              Flange.style.marginTop = flangeheight+'px';
          }


          if(Flange.className.match('flange-bottom'))
          {
              Flange.style.top = 0;
              parentheight = (Flange.parentNode.offsetHeight);
              Flange.style.marginTop = (parentheight)+'px';
          }
        }

        //if not have animation motor... create a basic.
        if ( !Trigger.className.match('fx-') && !Flange.className.match('fx-') )
        {

          Trigger.addEventListener('click', event => {toggleFlange(event); }, false);
          Flange.addEventListener('mouseleave', event => {closeFlange(event); }, false);
          document.body.addEventListener('click', event => {

            if(!event.target.closest('NAV'))
            {
              closeFlange(event);
            }

            document.body.onclick = null;

          }, true);

        }


        let toggleFlange = (event) =>
        {

            if(!isopen)
            {

              for (let i = 0; i < Flanges.length; i++)
              {
                Flanges[i].classList.remove('active','off');
                Flanges[i].classList.add('off');
              }

              Flange.classList.add('active');
              Trigger.classList.add('active');

              isopen = true;

            }

            else if (isopen)
            {

              Flange.classList.add('off');
              Flange.classList.remove('active');

              Trigger.classList.add('off');
              Trigger.classList.remove('active');

              isopen = false;
            }

        }

        let closeFlange = (event) =>
        {

          Flange.classList.add('off');
          Flange.classList.remove('active');
          Trigger.classList.add('off');
          Trigger.classList.remove('active');

          setTimeout(()=>{
            Flange.classList.remove('off','active');
            Flange.previousElementSibling.classList.remove('off','active');
          },250)

          return isopen = false;
        }


    }

  };



  ////// button

  const buttons = () =>
  {

    let ico = (() => {

      let Icons = [...document.querySelectorAll('[class*="button"]>img, .icon, .icon-before, .icon-after')];

      if(Icons)
      {

        let l = Icons.length;
        for (let i = 0; i < l; i++)
        {

          let Ico = Icons[i];

          if(!Ico.parentNode.className.match('inconized'))
          {
            Ico.parentNode.classList.add('inconized');
          }

        }

      }

    })();

    let checkbtn = (() => {

      let Btns = [...document.querySelectorAll('input[type="checkbox"]')];

      if(Btns)
      {

        let l = Btns.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = Btns[i];
          Btn.onclick = event =>
          {

            if(Btn.checked===true){  Btn.setAttribute('checked',false)}
            else{  Btn.setAttribute('checked',true)}

            return;

          };

        }

      }

    })();

    let radiobtn = (() => {

      let Btns = [...document.querySelectorAll('input[type="radio"]')];

      if(Btns)
      {

        let l = Btns.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = Btns[i];
          Btn.onclick = event =>
          {

              let name = Btn.getAttribute('name'),
                  ingroups = [...document.querySelectorAll('input[type="radio"][name="+name+"]')];

              let names = ingroups.length;
              for (let i = 0; i < names; i++)
              {
                ingroups[i].checked = false;
              }

              Btn.checked = true;


              return;

          };

        }
      }

    })();

    let numberbtn = (() => {

      let Btns = [...document.querySelectorAll('*[class*="button-number"]')]

      if(Btns)
      {

        let l = Btns.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = Btns[i],

              Input = [...Btn.querySelectorAll('input[type="number"]')][0],
              Minus = [...Btn.querySelectorAll('A')][0],
              Plus  = [...Btn.querySelectorAll('A')][1],
              Text  = [...Btn.querySelectorAll('P')][0],

              val   = Input.getAttribute('value'),
              min   = Input.getAttribute('min'),
              max   = Input.getAttribute('max');


          //set all to off
          Input.classList.add('off');
          Minus.classList.add('off');
          Plus.classList.add('off');
          Text.classList.add('off');


          //on click minus
          Minus.onclick = ()=>
          {

            if( val > min ) { val-- }else { return }

            Input.value = val,
            Text.innerHTML = val;

            if(!Minus.className.match("active")) { Minus.classList.replace('off','active'); }
            if(!Text.className.match("active")) { Text.classList.replace('off','active'); }



            setTimeout( () =>{
              Text.classList.replace('active','off');
              Minus.classList.replace('active','off');
            },150);


          }


          //on click plus
          Plus.onclick = () =>
          {

            if( val < max ) { val++ } else { return }

            Input.value = val,
            Text.innerHTML = val;

            if(!Plus.className.match('active')) { Plus.classList.replace('off','active'); }
            if(!Text.className.match('active')) { Text.classList.replace('off','active'); }



            setTimeout( () =>{
              Text.classList.replace('active','off');
              Plus.classList.replace('active','off');
            },150);

          }


        }


      }

    })();

    let uploadbtn = (() => {

      let Btns = [...document.querySelectorAll('*[class*="button-file"]')]

      if(Btns)
      {

        let l = Btns.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = Btns[i];

          Btn.onchange = ()=>{


              //get subjects & values

              let Input = [...Btn.querySelectorAll('input[type="file"]')][0],
                  Text = [...Btn.getElementsByTagName('P')][0],

                  updateval = String( Input.value );
                  selected = String( Input.value.split('\\')[Input.value.split('\\').length - 1] );


              //set it

              Text.classList.add('active'),
              Text.innerHTML = '[ &#x2714 ] '+selected,
              Input.setAttribute('value',updateval);

              setTimeout( () =>{
                Text.classList.remove('active');
              },150);


          };

        }

      }

    })();

    let rangebtn = (() => {

      let Btns = [...document.querySelectorAll('.button-range')];

      if(Btns)
      {

        let l = Btns.length;
        for (var i = 0; i < l; i++)
        {

          let Slider = [...Btns[i].querySelectorAll('.slider')];

          let Bullet = [...Btns[i].querySelectorAll('.bullet')][0],
              bulletwidth = parseInt(window.getComputedStyle(Bullet).width),
              slidewidth =  parseInt(window.getComputedStyle(Slider[0]).width),
              dotwidth = bulletwidth;
              // dotwidth note:
              //  theoretically we need to recover the width of thumb. It is not possible to do it.
              //  Fortunately and mystery, it still works by considering a bulltet / 2 constant as a reference.

          Bullet.classList.add("off");
          Bullet.style.left = -bulletwidth/4+"px";

          let s = Slider.length;
          for (let i = 0; i < s; i++)
          {

            let Slide = Slider[i];

            let bulletoff;
            Slide.addEventListener( "input" , event => {

              if(!Bullet.className.match("active"))
              {
                Bullet.classList.replace("off","active");
              }

              if(Slide.nextElementSibling)
              {
                let nextvalue = parseInt(Slide.nextElementSibling.value)-1;
                if(Slide.value >= nextvalue)
                {
                  Slide.value = parseInt(nextvalue);
                }
              }

              if(Slide.previousElementSibling)
              {
                let prevvalue = parseInt(Slide.previousElementSibling.value)+1;
                if(Slide.value <= prevvalue)
                {
                  Slide.value = parseInt(prevvalue);
                }
              }


              let ratio = (Slide.value - Slide.min) / (Slide.max - Slide.min),
                  transition = parseInt( ratio * (slidewidth-dotwidth/2) );

              Bullet.style.transform = "translate("+transition+"px,0)";
              Bullet.innerHTML = "<p>"+Slide.value+"</p>";

              Slide.setAttribute("value",Slide.value);

              clearTimeout(bulletoff);
              bulletoff = setTimeout(()=>{
                Bullet.classList.replace("active","off");
              },1000)

            },true);


          }

        }

      }

    })();

    let selectbtn = (() => {

      let Btns = [...document.querySelectorAll('*[class*="button-select"]')];

      if(Btns)
      {


        let l = Btns.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = Btns[i];

          //for all, generate a random id from 0 to 100
          let SELECTID = Math.floor(Math.random() * 101);


          //set target of off canvas
          Btn.setAttribute('target','outbox#select-'+SELECTID);


          //generate the empty output
          let select_empty_outbox =`
          <div class="outbox" id="select-`+SELECTID+`">
            <div class="side-center selectorbox">

                <div>

                  <div>
            				<a class="close">
                      <p>Select your option</p>
                    </a>
                  </div>

                  <div>
                    <!--<div class="hide-bar-y">-->
                      <div class="scroll-y">
                        <div class="optiongroup">
                        </div>
                      </div>
                    <!--</div>-->
                  </div>

                </div>

            </div>
          </div>`;


          //print empty output & get it
          document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',select_empty_outbox);
          let Outbox = document.getElementById("select-"+SELECTID).querySelector('.optiongroup');


          //get options groups value...
          let Groups = [...Btn.querySelectorAll('OPTGROUP')];

          let l = Groups.length;
          for (let i = 0; i < l; i++)
          {

            let Group = Groups[i];

            let Labels = '<p>'+Group.getAttribute('label')+'</p>', //get all label
                Options = [...Group.querySelectorAll('option')];  //get all options


            // create a options list
            let optslist = [];
            let l = Options.length;
            for (let i = 0; i < l; i++)
            {
              optslist.push('<a data-option="'+Options[i].value+'">'+String(Options[i].value)+'</a>')
            }

            //from array list to list of strings
            let optionslist = String(optslist.join(' '));

            // print new output contents
            let output;
            if(Labels=="<p></p>")
            {
              output =
              `
              <div class="nolabel hide"></div>
              <div class="options">
                `+optionslist+`
              </div>`;
            }
            else
            {
              output =
              `<div class="label">
               `+Labels+`
              </div>
              <div class="options">
                `+optionslist+`
              </div>`;
            }


            Outbox.insertAdjacentHTML('beforeEnd',output);


          }


          // "now, do..."

          //on click into voice of relative select popup
          let AllVoice = [...Outbox.querySelectorAll('.options a')];
          let v = AllVoice.length;
          for (let i = 0; i < v; i++)
          {
            let Voice = AllVoice[i];

            Voice.addEventListener('click', () =>
            {

              //update active
              for (let i = 0; i < v; i++)
              {
                AllVoice[i].classList.remove("active");
              }

              Voice.classList.add("active");

              //get relative value
              let val = Voice.getAttribute("data-option");

              //get relative select
              document.querySelectorAll('.button-select[target="outbox#select-'+SELECTID+'"]')[0].value = val;


            },true);

          }

        }


      }

    })();


    let calendarbtn = (() => {

      let Btns = [...document.querySelectorAll('*[class*=button-date]')];

      if(Btns)
      {

        let l = Btns.length;
        for (let i = 0; i < l; i++)
        {

          let Btn = Btns[i];

          //  1: create empty datepicker output

          //for all, generate a random id from 0 to 100
          let DATEID = Math.floor(Math.random() * 101);

          //set target of off canvas
          Btn.setAttribute("target","outbox#datepicker-"+DATEID);

          //generate the empty output
          let datepicker_empty =`
          <div class="outbox gpuboost" id="datepicker-`+DATEID+`">

            <div class="side-center">

              <div class="datepicker">

                <div>
                  <a class="close">
                    <p>Select a date</p>
                  </a>
                </div>

                <div>

                  <div>

                    <div class="years">
                      <span class="prev">&nbsp;</span>
                      <span class="year_list"></span>
                      <span class="next">&nbsp;</span>
                    </div>

                  </div>

                  <div>

                    <div class="months">
                      <span class="prev">&nbsp;</span>
                      <span class="month_list"></span>
                      <span class="next">&nbsp;</span>
                    </div>

                  </div>

                </div>

                <div>

                  <div class="weekday_list">
                    <div class="grid-x" align="center">

                    </div>
                  </div>

                </div>

                <div>

                  <div class="day_list">
                    <div class="grid-x" align="center">

                    </div>
                  </div>

                </div>

                <div>
                  <a class="button-action accept"> OK - CLOSE </a>
                </div>

              </div>

            </div>

          </div>`;

          //print output
          document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',datepicker_empty);



          //  2: recuva a component of output



          let //get datepiker elements
              Target = [...document.querySelectorAll("#datepicker-"+DATEID)][0],
              year_list = [...Target.querySelectorAll(".year_list")][0],
              month_list = [...Target.querySelectorAll(".month_list")][0],
              weekday_list = [...Target.querySelectorAll(".weekday_list>div")][0],
              day_list = [...Target.querySelectorAll(".day_list>div")][0];



          //  3: populate for a start



          //create year list
          let years_array = [];
          for (let i = 1950; i <= 2050; i++){ years_array.push('<p>'+( i )+'</p>'); }
          years_array =  String( years_array.join(' ') );
          year_list.innerHTML =  years_array;


          //create month list
          let month_array = [], monthArray = ['January','February','March','April','May','June','July','August','September','October','November','December'];
          //let month_array = [], monthArray = ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
          for (let i = 0; i <= 11; i++){ month_array.push('<p>'+ monthArray[i] +'</p>') }
          month_array =  String( month_array.join(' ') );
          month_list.innerHTML =  month_array;


          //create weekday list
          let weekday_array = [], dayweekArray = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
          //let weekday_array = [], dayweekArray = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
          for (let i = 0; i < dayweekArray.length; i++) { weekday_array.push( '<div class="box-[14-14-14]"><p>'+ dayweekArray[i] +'</p></div>' ) }
          weekday_array = String( weekday_array.join(' ') );
          weekday_list.innerHTML =  weekday_array;



          //  4: get all dates value from UTC



          let //get current dates
              date = new Date(),
              format = date.toUTCString(),
              this_year = date.getUTCFullYear(),
              this_month = date.getUTCMonth(),
              this_day = date.getUTCDate(),
              this_week = date.getUTCDay(),
              //console.log("\nRequested for today:\nW: "+this_week+" D: "+this_day+" M: "+this_month+" Y: "+this_year+"\nin string is: "+format+"");


              //get all relative dates
              get_FirstDayOfweek = (month,year) =>
              {

                let Y = parseInt(year),
                    M = parseInt(month); //this fucking bastard start to 1

                let setDate = new Date( Date.UTC(Y,M,01) ),
                    firstDay = parseInt(setDate.getDay());
                    firstDayString = setDate.toUTCString();

                    //console.log("\ndayweek of first day:\n"+firstDay+" -> in: "+Y+"/"+M+"/01 (is not array but dec is nov)\nin string is: "+firstDayString);

                    return firstDay;

              },
              get_DaysQntOfMounth = (month,year) =>
              {

                let Y = parseInt(year),
                    M = parseInt(month+1); //this fucking bastard start to 0
                    dayQuantity = parseInt( new Date( Date.UTC(Y,M,00)).getDate() );

                    //console.log("\nQnt of day in month:\n"+dayQuantity+" -> in: "+Y+"/"+M+" ( month is array '+1' )");

                    return dayQuantity;

              }



          //  5: set contents to start and to action



          //switch years

          let years = [...year_list.querySelectorAll("p")],
              year_prev  = Target.querySelector('.years>.prev'),
              year_next  = Target.querySelector('.years>.next');

          for (let i = 0; i < years.length; i++)
          {

              years[i].classList.add("off","hide");

              if(years[i].textContent == this_year )
              {
                years[i].classList.remove("off","hide");
                years[i].classList.add("active");
              }

          }

          year_prev.addEventListener('click', event => {


            for (let i = 0; i < years.length; i++)
            {

              if(years[i].className.match("active") && years[i-1])
              {

                years[i].classList.replace("active","off");
                years[i].classList.add("hide");

                years[i-1].classList.add("active");
                years[i-1].classList.remove("off","hide");

                set_day_list();

                return; //forced to exit
              }

            }


          }, false);

          year_next.addEventListener('click', event => {


            for (let i = 0; i < years.length; i++)
            {

              if(years[i].className.match("active") && years[i+1])
              {
                years[i].classList.replace("active","off");
                years[i].classList.add("hide");

                years[i+1].classList.add("active");
                years[i+1].classList.remove("off","hide");

                set_day_list();

                return; //forced to exit
              }

            }


          }, false);


          //switch month

          let months = [...month_list.querySelectorAll("p")],
              month_prev = Target.querySelector('.months>.prev'),
              month_next = Target.querySelector('.months>.next');

          for (let i = 0; i < months.length; i++)
          {

              months[i].classList.add("off","hide");

              if(i == this_month)
              {
                months[i].classList.remove("off","hide");
                months[i].classList.add("active");
              }

          }

          month_prev.addEventListener('click', event => {



            for (let i = 0; i < months.length; i++)
            {

              if(months[i].className.match("active") && months[i-1])
              {

                months[i].classList.replace("active","off");
                months[i].classList.add("hide");

                months[i-1].classList.add("active");
                months[i-1].classList.remove("off","hide");

                set_day_list();

                return; //forced to exit
              }

            }
          }, false);

          month_next.addEventListener('click', event => {



            for (let i = 0; i < months.length; i++)
            {

              if(months[i].className.match("active") && months[i+1])
              {

                months[i].classList.replace("active","off");
                months[i].classList.add("hide");

                months[i+1].classList.add("active");
                months[i+1].classList.remove("off","hide");

                set_day_list();

                return; //forced to exit

              }

            }
          }, false);


          //switch days

          Target.addEventListener('click', event => //update date on every click
          {

            let day_list = [...Target.querySelectorAll('.day_list .day')];
            for (let i = 0; i < day_list.length; i++)
            {

              day_list[i].addEventListener('click', event =>
              {

                  for (let i = 0; i < day_list.length; i++)
                  {
                    day_list[i].classList.remove("active");
                    day_list[i].classList.add("off");
                  }

                  event.target.classList.replace("off","active");

              },true);

            }

          },true);

          let set_day_list = (year,month) =>
          {


            if(!year || !month) // ok, it's not update...
            {

              var year =document.querySelector('#datepicker-'+DATEID+' .year_list .active').textContent,
                  month = document.querySelector('#datepicker-'+DATEID+' .month_list .active').textContent;

                  switch (month)
                  { //translate mont to array val
                    case "January": month=0;break;
                    case "February": month=1;break;
                    case "March": month=2;break;
                    case "April": month=3;break;
                    case "May": month=4;break;
                    case "June": month=5;break;
                    case "July": month=6;break;
                    case "August": month=7;break;
                    case "September": month=8;break;
                    case "October": month=9;break;
                    case "November": month=10;break;
                    case "December": month=11;break;
                    default: console.log("error: no mouth active");
                  }

            }

            //set/update days in "table list"

            let firstdayweek  = get_FirstDayOfweek(month,year),
                dayinactualmonth = get_DaysQntOfMounth(month,year),
                calendarcell = 41, //start to 0

                days_array = [],
                daytabulator = parseInt(  (calendarcell-firstdayweek+1) );


            for (let i = (firstdayweek-1)*-1; i <= daytabulator; i++)
            {

                let day = i, status = "off";

                if(day<=0 || i>dayinactualmonth){ day = "--", status = "off disabled" }
                else if(day>=1 && day<=9) { day="0"+i }
                else if(day == this_day) { status = "active" }

                days_array.push('<div class="box-[14-14-14]"><p class="day  '+status+'">'+( day )+'</p></div>'); //dayout

            }

            days_array = String(days_array.join(' '));
            day_list.innerHTML =  days_array;

          }

          set_day_list(this_year,this_month); //(add start days on first click)




          let accept = [...Target.querySelectorAll(".accept")][0];
          accept.addEventListener('click', event => {

            let finalday = document.querySelector('#datepicker-'+DATEID+' .day_list .active').textContent;
            if(finalday<=9){finalday="0"+finalday};

            let activeMonth = document.querySelector('#datepicker-'+DATEID+' .month_list .active').textContent,
                finalmonth;

                switch (activeMonth)
                {
                  case "January": finalmonth="01";break;
                  case "February": finalmonth="02";break;
                  case "March": finalmonth="03";break;
                  case "April": finalmonth="04";break;
                  case "May": finalmonth="05";break;
                  case "June": finalmonth="06";break;
                  case "July": finalmonth="07";break;
                  case "August": finalmonth="08";break;
                  case "September": finalmonth="09";break;
                  case "October": finalmonth="10";break;
                  case "November": finalmonth="11";break;
                  case "December": finalmonth="12";break;
                  default: console.log("error: no mounth active");
                }

            let finalyear = document.querySelector('#datepicker-'+DATEID+' .year_list .active').textContent;

            let datevalue = String( finalday+"/"+finalmonth+"/"+finalyear );

            let dateinput = document.querySelector('[target="outbox#datepicker-'+DATEID+'"]');
            dateinput.setAttribute("value",datevalue);
            dateinput.innerHTML = "<p>"+datevalue+"</p>";

            event = event;

          },false);


          //active/off week
          // let weekinbox = [...weekday_list.querySelectorAll("p")];
          // for (let i = 0; i < weekinbox.length; i++)
          // {
          //
          //     weekinbox[i].classList.add("off","disabled");
          //
          //     if( i == this_week-1 )
          //     {
          //       weekinbox[i].classList.remove("off","disabled");
          //       weekinbox[i].classList.add("active");
          //     }
          //
          // }


        }

      }

    })();


  }



  ////// ontop

  const gotop = () =>
  {

    let Top = [...document.querySelectorAll(".top")][0];

    if(Top)
    {

      let Sectors = [...document.querySelectorAll('html, body, .view, *[class*="viewport-"]')],
          Docweb = document.documentElement,
          limit = (parseInt( document.body.clientHeight )*2)/3;

        Top.classList.add('hide','off');

        window.addEventListener('scroll', ()=>
        {

          let docscroll = parseInt(Docweb.scrollTop);

          if(Sectors)
          {

            let l = Sectors.length;
            for (let i = 0; i < l; i++)
            {

              let Sector = Sectors[i];
              if(Sector.scrollTop > limit)
              {

                Top.classList.remove('hide'),
                Top.classList.remove('off'),
                Top.classList.add('active');

                Top.addEventListener('click',()=>{  ontop(Sector) },true);

              }

            }

          }

          else if(!Sectors && docscroll > limit )
          {

            Top.classList.remove('hide'),
            Top.classList.remove('off'),
            Top.classList.add('active');

            Top.addEventListener('click',()=>{  ontop() },true);

          }

          // if(docscroll < limit)
          // {
          //   deactivetop();
          // }


        },true);


        let ontop = (Sector) => {

          if(Sector)
          {

            Sector.scroll({
              top: 0,
              behavior: 'smooth'
            });

            deactivetop();

          }

          else
          {
            document.documentElement.scroll({
              top: 0,
              behavior: 'smooth'
            });

            deactivetop();

          }

        }

        let deactivetop = () => {

          Top.classList.add('off');
          Top.classList.remove('active');

          setTimeout(()=>{
            Top.classList.add('hide');
            Top.classList.remove('off');
          },1500)

        }


    }

  }



  ////// anchors

  const anchors = () =>
  {

    let Anchors = [...document.querySelectorAll('a[href^="#"]')];

    let l = Anchors.length;
    for (let i = 0; i < l; i++)
    {

        let Link = Anchors[i],
            target = Link.getAttribute('target');


        if(!target)
        {

          Link.parentNode.addEventListener('click', event => {

            event.preventDefault();
            event.stopPropagation();

            let href = Link.getAttribute("href").split("#")[1];

            if(href && !target)
            {

                let hrefTarget = [document.querySelector('*[name="'+href+'"]')][0],
                    hrefposition = hrefTarget.offsetTop;
                //
                // if(Link.closest(".view"))
                // {

                  setTimeout(()=>{
                    Link.closest('html, body, .view, *[class*="viewport-"]').scrollTo({
                      top: hrefposition,
                      behavior: 'smooth'
                    });
                  },20);

                // }
                // else
                // {
                //
                //   console.log(hrefTarget);
                //   console.log(hrefposition);
                //
                //   document.body.scrollTo({
                //     top: hrefposition,
                //     behavior: 'smooth'
                //   });
                // }

                //hrefTarget.focus();
              }

          },true);

        }

    }

  }



  ////// cards

  const card = () =>
  {


    let Cards = [...document.querySelectorAll('[class*="card"]')];

    let l = Cards.length;
    for (let i = 0; i < l; i++)
    {

      let Card = Cards[i];

      Card.onclick = () =>{


        let Loader = [...document.querySelectorAll('.loader')][0],
            Href = Card.querySelector('a:last-child').getAttribute('href'),
            isntBlank = Card.querySelector('a:last-child').getAttribute('target') == ('_top' && '_self' );


        event.preventDefault(),event.stopPropagation(),event.stopImmediatePropagation();

        if(isntBlank)
        {

          Loader.classList.remove('hide');
          setTimeout( function(){
            Loader.classList.add('active');
          }, 50);

          setTimeout( function(){

            if(Href==='#')
            {
               location.reload();
            }
            else
            {
              location.href = Href;
            }

          }, 300);

        }
        else
        {
          location.href = Href;
        }

      }

    }

  }



  ////// tabs

  const tabx = () =>
  {

    let AllTabsX = [...document.querySelectorAll(".tabs-x")];

    let l = AllTabsX.length;
    for (let i = 0; i < l; i++)
    {

      let Tab = AllTabsX[i],
          AList = [...Tab.querySelectorAll('nav>a')],  //anchorlist
          SList = [...Tab.querySelectorAll('.tabs-x>div')];   //secotrlist

      let l = AList.length;
      for (let i = 0; i < l; i++)
      {

        let A = AList[i],
            S = SList[i];

        A.classList.add('off');
        S.classList.add('off');

        AList[0].classList.replace('off','active');
        SList[0].classList.replace('off','active');

        A.onclick = () =>{

          if(!A.className.match('active'))
          {

            for (let i = 0; i < l; i++)
            {
              AList[i].classList.replace("active","off");
              SList[i].classList.replace("active","off");
            }

            A.classList.replace("off","active");
            S.classList.replace("off","active");

            return false;
          }

        }


      }

    }

  }

  const taby = () =>
  {


    let AllTabsY = [...document.querySelectorAll(".tabs-y")];

    let tabssize = AllTabsY.length;
    for (let i = 0; i < tabssize; i++)
    {

      let Tab = AllTabsY[i],
          AList = [...Tab.querySelectorAll(".tabs-y>div:nth-child(odd)")];

      let l = AList.length;
      for (let i = 0; i < l; i++)
      {

        let A = AList[i];

        A.classList.add('off');
        A.nextElementSibling.classList.add('off');

        AList[0].classList.replace('off','active');
        AList[0].nextElementSibling.classList.replace('off','active');

        A.onclick = ()=>{

          for (let i = 0; i < l; i++)
          {
            AList[i].classList.add('off');
            AList[i].classList.remove('active');
            AList[i].nextElementSibling.classList.add('off');
            AList[i].nextElementSibling.classList.remove('active');
          }

          A.classList.replace('off','active');
          A.nextElementSibling.classList.replace('off','active');

          return false;

        }

      }


    }

  }



  ////// video

  const video = () =>
  {

    let vb = [...document.querySelectorAll("video.background")];
    for (let i = 0; i < vb.length; i++)
    {

      vb[i].parentNode.style.overflow = "hidden";
      vb[i].parentNode.style.position = "relative";

    }

    let player = [...document.querySelectorAll("video.player")];
    for (let i = 0; i < player.length; i++)
    {

      let src = player[i].getAttribute("src"),
          autoplay = player[i].getAttribute("autoplay"),
          controls = player[i].getAttribute("controls"),
          loop = player[i].getAttribute("loop"),
          classes = player[i].getAttribute("classes"),
          id = player[i].getAttribute("id");

      let isYoutu_be 	 = src && src.match(/(?:youtu)(?:\.be)\/([\w\W]+)/i),
          isyoutube 	 = src && src.match(/(?:youtube)(?:\.com)\/([\w\W]+)/i),
          isVimeo 	 = src && src.match(/(?:vimeo)(?:\.com)\/([\w\W]+)/i);


      // check player param

      let ap,ctrl,lp,videowrap;

      if(autoplay && autoplay != "false"){ ap = "autoplay=1"; }
      else{ap = "autoplay=0";}

      if(controls && controls != "false"){ ctrl = "controls=1"; }
      else{ctrl = "controls=0";}

      if(loop && loop != "false"){ lp = "loop=1"; }
      else{lp = "loop=0";}


      if(!id){id=""};
      if(!classes){classes=""};

      // youtu.be

      if (isYoutu_be && player[i].tagName == "VIDEO")
      {

        var utvID = isYoutu_be[1];

        //create new elem
        htmlcode = '<iframe id='+id+' class="'+classes+'" src="https://www.youtube.com/embed/'+utvID+'?'+ap+'&showinfo=0&'+ctrl+'&modestbranding=1&'+lp+'&nologo=1&iv_load_policy=3;" frameborder="0" allowfullscreen"></iframe>';
        videowrap = document.createElement('div');

        //wrap inside new code
        videowrap.innerHTML = htmlcode;
        player[i].parentNode.insertBefore(videowrap, player[i]);

        //unwrap, make free
        videowrap.outerHTML = videowrap.innerHTML;
        player[i].parentNode.removeChild(player[i]);

      }

      // youtube.com

      else if (isyoutube && player[i].tagName == "VIDEO")
      {

        var ytvID = isyoutube[1].split("=")[1];

        //create new elem
        htmlcode = '<iframe id='+id+' class="'+classes+'" src="https://www.youtube.com/embed/'+ytvID+'?'+ap+'&showinfo=0&'+ctrl+'&modestbranding=1&'+lp+'&nologo=1;" frameborder="0" allowfullscreen"></iframe>';
        videowrap = document.createElement('div');

        //wrap inside new code
        videowrap.innerHTML = htmlcode;
        player[i].parentNode.insertBefore(videowrap, player[i]);

        //unwrap, make free
        videowrap.outerHTML = videowrap.innerHTML;
        player[i].parentNode.removeChild(player[i]);

      }

      // videmo

      else if (isVimeo && player[i].tagName == "VIDEO")
      {

        var vvID = isVimeo[1];

        //create new elem
        htmlcode = '<iframe id='+id+' class="'+classes+'" src="https://player.vimeo.com/video/'+vvID+'?color=9c00f0&title=0&byline=0&portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
        videowrap = document.createElement('div');

        //wrap inside new code
        videowrap.innerHTML = htmlcode;
        player[i].parentNode.insertBefore(videowrap, player[i]);

        //unwrap, make free
        videowrap.outerHTML = videowrap.innerHTML;
        player[i].parentNode.removeChild(player[i]);

      }

      // html player

      else
      {

        player[i].setAttribute('controls','true');
        player[i].setAttribute('preload','true');

      }


    }

  };



  ////// fit

  const fitup = () =>
  {

      let Fits = [...document.querySelectorAll(".fit-up")];

      let l = Fits.length;
      for (let i = 0; i < l; i++) {

        let Fit = Fits[i];

        Fit.parentNode.style.position = "relative";

        let H = Fit.previousElementSibling.offsetHeight,
            W = Fit.previousElementSibling.offsetWidth;

        Fit.style.height = H+'px';
        Fit.style.width = W+'px';
        Fit.style.margin = ('-'+H+'px 0 -'+H+'px 0');

      }


  }

  const fitheight = () =>
  {

    let Fits = [...document.querySelectorAll(".fit-height")];

    let l = Fits.length;
    for (let i = 0; i < l; i++)
    {

      let Fit = Fits[i];

      Fit.parentNode.style.position = 'relative';

      let H = Fit.parentNode.offsetHeight,
          W = Fit.parentNode.offsetWidth;

      Fit.style.width = W+'px';
      Fit.style.height = H+'px';

    }

  }



  ////// effector: parallax

  const parallax = () =>
  {



    let Parallax = [...document.querySelectorAll('*[class*="fx-parallax-"]')];

    let p = Parallax.length;
    for (let i = 0; i < p; i++)
    {


      let Box = Parallax[i];

      let scale,sensibility;
      if(Box.className.match("mask"))
      {
          scale       = Box.className.split('fx-parallax-[')[1].split('-mask]')[0].split('-')[1],
          sensibility = Box.className.split('fx-parallax-[')[1].split('-mask]')[0].split('-')[0];
      }
      else
      {
          scale = Box.className.split('fx-parallax-[')[1].split(']')[0].split('-')[1],
          sensibility = Box.className.split('fx-parallax-[')[1].split(']')[0].split('-')[0];
      }


      //get all box values
      let height            = Box.offsetHeight,
          width             = Box.offsetWidth,
          reltop            = Box.offsetTop, // positon of box into page
          relleft           = Box.offsetLeft,
          distancetotop     = Box.getBoundingClientRect().top+(height/2), // scroll positon respect the top of screen
          distancetoleft    = Box.getBoundingClientRect().left+(width/2),
          screen_h          = document.body.clientHeight,
          screen_w          = document.body.clientWidth;


      //starter box positon
      let y_start =  (distancetotop-(screen_h/2))*-1,
          x_start =  (distancetoleft-(screen_w/2))*-1;


      //for all child of box
      let counterbox = 1,
          Child = Box.children,
          l = Child.length;

      for (let i = 0; i < l; i++)
      {

        counterbox++;

        let X,Y;
        Y =  ( y_start/screen_h )*(100-(counterbox*sensibility));
        X =  ( x_start/screen_w )*(100-(counterbox*sensibility));


        Child[i].style.transformOrigin = "center";
        Child[i].style.transform = "scale("+(scale)+") translate("+0+"px,"+Y+"px)";

      }

    }

  }



  ////// spoiler

  const spoiler = () =>
  {

    let Box = [...document.querySelectorAll('.spoiler')];

    let l = Box.length;
    for (let i = 0; i < l; i++)
    {

      let ToggleButton = [...Box[i].querySelectorAll('.toggle')][0];

      ToggleButton.addEventListener('click',()=>{hideshow();},true);

      let hideshow = () =>
      {



        if(!Box[i].className.match('active'))
        {

          Box[i].classList.add('active');
          ToggleButton.classList.add('active');

          Box[i].classList.remove('off');
          ToggleButton.classList.remove('off');

        }
        else
        {

          Box[i].classList.add('off');
          ToggleButton.classList.add('off');

          Box[i].classList.remove('active');
          ToggleButton.classList.remove('active');

        }


      }


    }

  }


  ////// effector: custom engine

  const effectors = () =>
  {

    let Efxs = [...document.querySelectorAll('[class*="fx-["]')];

    let efxssize = Efxs.length;
    for (let i = 0; i < efxssize; i++)
    {

      let params = Efxs[i].className.split('fx-[')[1].split(']')[0];

      let Target,
          Trigger,
          action,
          cssin,
          timerin,
          delayin,
          cssout,
          timerout,
          delayout,
          toggle,
          hide,
          reset;

      if(params.match("on:"))
      {
          action = ""+params.split("on:")[1].split(";")[0];
      }

      if(params.match("target:"))
      {
          let targetstring = String(params.split("target:")[1].split(";")[0]);
          Target = [...document.querySelectorAll('[class*="target-'+targetstring+'"]')];
      }
      else
      {
          Target = [Efxs[i]];
      }

      if(params.match("trigger:"))
      {
          let triggerstring = String(params.split("trigger:")[1].split(";")[0]);
          Trigger = [...document.querySelectorAll('[class*="trigger-'+triggerstring+'"]')];
      }
      else
      {
          Trigger = [Efxs[i]];
      }

      if(params.match("in:"))
      {
          cssin = ""+params.split("in:")[1].split(";")[0].split(",")[0];
          timerin = ""+params.split("in:")[1].split(";")[0].split(",")[1];
          delayin = ""+params.split("in:")[1].split(";")[0].split(",")[2];

          if(!timerin) { timerin = 1; }
          if(!delayin) { delayin = 1; }

      } else { console.log='kimera debug: fx -> "in" not found!' };

      if(params.match("out:"))
      {
          cssout = ""+params.split("out:")[1].split(";")[0].split(",")[0];
          timerout = ""+params.split("out:")[1].split(";")[0].split(",")[1];
          delayout = ""+params.split("out:")[1].split(";")[0].split(",")[2];

          if(!timerout) { timerout = 1; }
          if(!delayout) { delayout = 1; }

      } else { cssout = false; }

      if(params.match("toggle:"))
      {
          toggle = ""+params.split("toggle:")[1].split(";")[0];
          if(toggle == "true"){ toggle = true; } else {toggle= false;}
      } else { toggle = true; }

      if(params.match("hide:"))
      {
          hide = ""+params.split("hide:")[1].split(";")[0];
      } else { hide = false; }

      if(params.match("reset:"))
      {
          reset = ""+params.split("reset:")[1].split(";")[0];
          if(reset == "true"){ reset = true; } else { reset = false; }
      } else { reset = false; }


      //console.log("fx:["+"\nTarget: "+Target+"\nTrigger: "+Trigger+"\naction: "+action+"\ncssin: "+cssin+"\ntimerin: "+timerin+"\ndelayin: "+delayin+"\ncssout: "+cssout+"\ntimerout: "+timerout+"\ndelayout: "+delayout+"\ntoggle: "+toggle+"\nhide: "+hide+"\nhide: "+reset+"]")


      let triggersize =Trigger.length;
      for (let trs = 0; trs < triggersize; trs++)
      {


        let targetsize =Target.length;
        for (let i = 0; i < targetsize; i++)
        {


          if(hide && !Target[i].className.match('fx-active'))
          {
            Target[i].style.opacity = 0;
          }

          switch (action)
          {

            case 'unloadDoc':
              console.log("kimera debug: fx -> unload not can be used in this version of fx. Sorry.");
            break;

            case 'loadDoc':

                setTimeout(()=>{

                  Target[i].classList.add('[fx-active]',cssin);
                  Target[i].classList.remove('[fx-off]',cssout);

                  setTimeout(()=>{

                    if(reset)
                    {
                      Target[i].classList.remove(cssin);
                    }

                  },timerin)

                },delayin);


            break;

            case "scroll":

              if( Target[i].offsetTop < screen.height && !Target[i].className.match(cssin) )
              {
                  Target[i].classList.add(cssin);
                  Target[i].classList.add("[fx-active]");
              }

              window.addEventListener("scroll", event => { makefx_scrolling(event); }, true);

              let makefx_scrolling = (event) =>
              {

                let	scrollpositionIn = parseInt( document.documentElement.scrollTop + screen.height-(screen.height/10)),
                    scrollpositionOut = parseInt( document.documentElement.scrollTop + (screen.height/10)),
                    elementposition = parseInt( Target[i].offsetTop );

                if(Target[i].className.match('fx-active'))
                {

                  if( elementposition < scrollpositionIn && elementposition > scrollpositionOut  )
                  {

                    setTimeout(()=>{

                        Target[i].classList.add(cssin);
                        Target[i].classList.remove(cssout);

                        setTimeout(()=>{

                          if(reset)
                          {
                            Target[i].classList.remove(cssin);
                          }
                          else
                          {
                            Target[i].classList.add('[fx-off]');
                            Target[i].classList.remove('[fx-active]');
                          }

                        },timerin)


                    },delayin+timerout);

                  }

                }

                if( (elementposition < scrollpositionOut || elementposition > scrollpositionIn ) && Target[i].className.match('fx-off') && toggle )
                {

                  Target[i].classList.add(cssout);
                  Target[i].classList.remove(cssin);

                  Target[i].classList.add('[fx-active]');
                  Target[i].classList.remove('[fx-off]');

                  if(reset)
                  {
                    setTimeout(()=>{
                      Target[i].classList.remove(cssout);
                    },timerout)
                  }

                }
              }

            break;

            case "hover":

              Trigger[trs].addEventListener("mouseover", event =>{ makefx_hoverin() },true);
              Trigger[trs].addEventListener("mouseleave", event =>{ makefx_hoverout() },true);

              let makefx_hoverin = () => {

                let l = Target.length;
                for (let i = 0; i < l; i++)
                {

                  if(!Target[i].className.match('fx-active') || Target[i].className.match('fx-off'))
                  {

                    setTimeout(()=>{

                      Target[i].classList.add('[fx-active]', cssin);
                      Target[i].classList.remove(cssout, '[fx-off]');

                      setTimeout(()=>{

                        if(reset === true)
                        {
                          Target[i].classList.remove(cssin);
                          Target[i].classList.remove(cssin, '[fx-active]');
                        }

                      },timerin)

                    },delayin);

                  }

                }

              };

              let makefx_hoverout = () => {

                for (let i = 0; i < Target.length; i++)
                {

                  if(Target[i].className.match('fx-active') && toggle)
                  {

                    setTimeout(()=>{

                      Target[i].classList.add(cssout,'[fx-off]');
                      Target[i].classList.remove(cssin,'[fx-active]');

                      if(reset)
                      {
                        setTimeout(()=>{
                          Target[i].classList.remove(cssout);
                        },timerout)
                      }

                    },delayout);

                  }

                }

              };


            break;

            case "click":


                Trigger[trs].addEventListener("click", event =>{ makefx_click() },true);

                let makefx_click = () => {


                  for (let i = 0; i < Target.length; i++)
                  {

                    if(!Target[i].className.match('fx-active'))
                    {

                      setTimeout(()=>{

                        Target[i].classList.add('[fx-active]',cssin);
                        Target[i].classList.remove('[fx-off]',cssout);

                        setTimeout(()=>{

                          if(reset)
                          {
                            Target[i].classList.remove('[fx-active]',cssin);
                          }

                        },timerin)

                      },delayin);


                    }

                    if(Target[i].className.match('fx-active') && toggle === true)
                    {

                      setTimeout(()=>{

                        Target[i].classList.add('[fx-off]',cssout);
                        Target[i].classList.remove('[fx-active]',cssin);

                        if(reset)
                        {
                          setTimeout(()=>{
                            Target[i].classList.remove('[fx-off]',cssout);
                          },timerout)
                        }

                      },delayout);

                    }

                  }


                };

            break;

          }

        }

      }

    }

  }



  ////// checksize

  const scrollsize = () =>
  {

    //'.checksize',
    let Oversizes = [...document.querySelectorAll('.checksize, TABLE, CODE, PRE, OUTPUT')];

    let l = Oversizes.length;
    for (let i = 0; i < l; i++)
    {

      let SizedBox =  Oversizes[i];

      let targetwidth = parseInt(SizedBox.offsetWidth),
          parentwidth = parseInt(SizedBox.parentNode.offsetWidth),
          scrollwrap;

      if( !(SizedBox.parentNode.className.match('scroll-x')) )
      {

        let t = SizedBox.tagName;
        if(t=='TABLE'||t=='CODE'||t=='PRE'||t=='OUTPUT')
        {
          SizedBox.classList.add('scroll-x','checksize');
        }

        else
        {

          if( targetwidth > parentwidth )
          {
            //wrap it
            let ScrollableWrap = document.createElement('div');
          	SizedBox.parentNode.insertBefore(ScrollableWrap, SizedBox);
          	ScrollableWrap.appendChild(SizedBox);
            SizedBox.parentNode.classList.add('scroll-x','checksize');
          }
          else if(targetwidth <= parentwidth && SizedBox.parentNode.className.match('checksize') )
          {
            SizedBox.parentNode.outerHTML = SizedBox.parentNode.innerHTML;
          }

        }


      }


    }

  }






  ///// K launcher

    //document.readyState == 'complete' &&
    window.onunload = () => { null; loaderstart(); };
    document.addEventListener('DOMContentLoaded',
    () => { loaderstart(); });

    document.addEventListener('DOMContentLoaded',
    () => { viewportapp(); },true);

    document.addEventListener('DOMContentLoaded',
    () => {
      absolute();
      scrollsize();
      standardscroll();
      snapscroll();
      anchors();
      gotop();
      buttons();
      spoiler();
      card();
      tabx();
      taby();
      video();
    },false);

    window.addEventListener('load',(
      eventDone( () => {
        flange();
        fitup();
        fitheight();
        parallax();
        effectors();
        loaderout();
        outbox();
        autocrop();
      })
    ),false);

    window.addEventListener("scroll",
    () => {
        parallax();
    },true);

    window.addEventListener("resize",(
      eventDone( () => {
        flange();
        fitheight();
        fitup();
        video();
        parallax();
        autocrop();
      })
    ),false);


})();
